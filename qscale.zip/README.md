# Java Swing Work Queue Autoscaling Simulator

A standalone Java Swing application that simulates and visualizes the scheduling, worker execution, database locking semantics, and horizontal pod autoscaling of a distributed background-task processing system.

---

## Quick Start & Running Instructions

### Prerequisites
- JDK 17 or higher (Java 17, 21, or 25)
- Apache Maven 3.6+

### Build the Application
To compile, run unit tests, and build the executable JAR:
```bash
mvn clean package
```

### Launch the Application
You can launch the application in two ways:

1. **Using Java JAR (Recommended)**:
```bash
java -jar target/q-worker-1.0-SNAPSHOT.jar
```

2. **Using Maven Exec Plugin**:
```bash
mvn exec:java
```

---

## Architecture & Simulation Model

The simulator runs entirely in memory as a discrete-event simulation. Real Java concurrency is decoupled from domain logic so that the simulation executes deterministically and at accelerated speed multipliers (0.5x, 1.0x, 2.0x, 5.0x, 10.0x) without thread exhaustion or wall-clock dependence.

```
 +-----------------------------------------------------------------------------------+
 |                              INDEPENDENT POD 1                                    |
 |   Schedulers: Queue A (every X ms) | Queue B (every Y ms) | Queue C (every Z ms)  |
 |   Thread Pool: [T1] [T2] [T3] [T4] [T5] [T6] [T7] [T8]                           |
 +-----------------------------------------------------------------------------------+

 +-----------------------------------------------------------------------------------+
 |                              INDEPENDENT POD 2                                    |
 |   Schedulers: Queue A (every X ms) | Queue B (every Y ms) | Queue C (every Z ms)  |
 |   Thread Pool: [T1] [T2] [T3] [T4] [T5] [T6] [T7] [T8]                           |
 +-----------------------------------------------------------------------------------+
                                          |
                                          v (Claiming Batches)
 +-----------------------------------------------------------------------------------+
 |                       IN-MEMORY DATABASE REPOSITORY                               |
 |                       SELECT ... FOR UPDATE SKIP LOCKED                           |
 +-----------------------------------------------------------------------------------+
```

### 1. Independent Per-Pod Queue Scheduling (Sections 8 & 9)
- **No central broker**: Each active pod operates completely independently and runs its own set of queue schedulers (`PodQueueSchedulerInvocationEvent`).
- **Local Thread Allocation**: Every `scheduleIntervalMs`, a pod's queue scheduler attempts to claim an available thread **from that pod's local thread pool**.
- If a pod's thread pool is saturated, that pod drops its scheduled worker invocation.
- Adding pods scales both **thread capacity** AND **independent scheduling capacity**, accurately reproducing horizontal worker throughput gains.

### 2. In-Memory Database Queue Semantics (`FOR UPDATE SKIP LOCKED`)
Work items are stored in a thread-safe repository simulating real database queue operations:
```sql
SELECT * FROM work_queue
WHERE queue_id = ?
  AND last_update < executionStart
  AND available_for_processing = true
FOR UPDATE SKIP LOCKED
LIMIT batchSize
```
- **Dynamic `executionStart`**: When a worker finishes a batch and immediately attempts to claim another batch, its `executionStart` timestamp updates to the current simulation time (`NOW()`), ensuring workers continuously process un-locked pending items.
- **Atomic Locking**: Claimed items enter `PROCESSING` status and are locked to the specific worker.
- **Retries**: On failure, an item's `retryCount` increments and its `lastUpdate` updates to current simulation time. The item remains locked out during its `retryDelayMs`. If `maxRetries > 0` and `retryCount >= maxRetries`, the item is permanently purged.

### 3. Kubernetes / OpenShift HPA Pod Autoscaling Model (`autoscale.md`)
- **Aggregate Scale-Out**: Scale-out is based **strictly on average thread utilization across all active pods**:
  $$\text{averageUtilization} = \frac{\text{Total Busy Threads}}{\text{Total Active Capacity}} \times 100.0$$
  Triggers when $\text{averageUtilization} \ge \text{scaleOutThresholdPct}$ (default 80%) and adds **exactly one pod** per evaluation cycle. Individual busy pods do not trigger scale-out unless the fleet average crosses 80%.
- **Safe Candidate Scale-In & Projected Utilization**:
  Evaluated when active pods > `minPods` and outside the scale-down stabilization window (`scaleDownStabilizationMs`, default 30s).
  1. Finds candidate pods with $\text{podUtilization} \le \text{scaleInThresholdPct}$ (default 20%), selecting the least-utilized candidate (newest pod ID tie-breaker).
  2. Simulates removal:
     $$\text{projectedUtilization} = \frac{\text{totalBusy} - \text{candidate.busy}}{\text{totalCapacity} - \text{candidate.threads}} \times 100.0$$
  3. Scales in `engine.scaleInPod(candidate)` **only if $\text{projectedUtilization} < 80\%$**, preventing post-scale-in flapping.

---

## Main Parameters Reference

### Queue Configuration Parameters
| Parameter | Unit | Description |
| :--- | :--- | :--- |
| **`Queue Name`** | String | Human-readable identifier for the queue. |
| **`Initial Items`** | Integer | Number of work items injected at simulation start. |
| **`Arrival Mean`** | items/sec | Average rate of incoming new work items. |
| **`Arrival Variance`** | float | Statistical variance for arrival intervals. |
| **`Processing Mean`** | milliseconds| Mean worker execution time per work item. |
| **`Processing Variance`** | milliseconds| Statistical variance for item processing time. |
| **`Failure Probability`**| percentage | Chance (0% to 100%) that an item fails execution. |
| **`Retry Delay`** | milliseconds| Wait time before a failed item becomes re-eligible. |
| **`Max Retries`** | integer | Max retries before permanent purge (0 = unlimited). |
| **`Batch Size`** | integer | Max items claimed per database query by a worker. |
| **`Schedule Interval`** | milliseconds| Frequency of worker spawn attempts on each pod. |
| **`Add N items`** | action | Button to instantly inject a burst of work items. |

### Pod & Autoscaler Parameters
| Parameter | Default | Description |
| :--- | :--- | :--- |
| **`Initial Pods`** | `1` | Starting deployment pod count. |
| **`Min Pods / Max Pods`** | `1 / 10` | Minimum and maximum scaling bounds. |
| **`Threads per Pod`** | `8` | Worker thread capacity per pod. |
| **`Scale-Out Threshold`**| `80%` | Aggregate average utilization triggering scale-out. |
| **`Scale-In Threshold`** | `20%` | Per-pod utilization threshold for scale-in eligibility. |
| **`Startup Delay`** | `2000 ms` | Boot delay before new pods join the active pool. |
| **`Stabilization Window`**| `30000 ms` | Scale-down hold-off period following a scale-out. |

---

## User Interface Overview

- **Top Toolbar**: Controls for ▶ Start, ⏸ Pause, ↺ Reset, speed multiplier dropdown (0.5x to 10x), digital simulation clock, and engine status.
- **Global Dashboard & Telemetry**: Live counters for Pods, Threads, Average Utilization, Queued Items, Completed Items, Failures, Throughput, plus HPA Recommendation, Candidate Pod, Projected Utilization, and Diagnostic Reason logs.
- **Queue Controls & Backlogs**: Forms for editing queue parameters on the fly, manual burst injection, and backlog progress bars.
- **Pod & Worker Thread Visualization**: Real-time visual cards for each pod showing individual thread status (IDLE vs color-coded queue assignment).
- **Telemetry Line Chart**: Live graph tracking Queue Depth, Pod Count, and Busy Threads over time.
