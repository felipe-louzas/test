# Fix the Pod Autoscaler Algorithm

Review and replace the current `AutoscalerEvaluationEvent` implementation.

The current algorithm is incorrect because it treats **any individual overutilized pod as a reason to scale out**.

For example:

```text
3 pods
Pod 1 = 100% busy
Pod 2 = 100% busy
Pod 3 = 20% busy

Average utilization = 73.3%
```

The current implementation still scales out because at least one pod is over the scale-out threshold.

That is incorrect for the intended model.

The simulator should model a simplified version of how Kubernetes/OpenShift Horizontal Pod Autoscaling works when scaling from a **per-pod custom metric**: the autoscaler evaluates the average metric across the pods and adjusts the replica count based on that aggregate utilization. Kubernetes HPA calculates the average metric across targeted pods and derives desired replicas from the ratio between current metric and the target. It also uses stabilization/tolerance mechanisms to avoid flapping.

The simulator does not need to reproduce every detail of the real Kubernetes implementation. Keep the algorithm simple and appropriate for this POC.

---

## 1. Scale-out behavior

Scale-out must be based only on **average thread utilization across all active pods**.

Calculate:

```java
double totalCapacity = sum(pod.threadCount);
double totalBusyThreads = sum(pod.busyThreadCount);

double averageUtilization =
        totalBusyThreads / totalCapacity;
```

Do NOT use:

```java
hasOverutilizedPod
```

and do NOT scale out merely because one pod is highly utilized.

Scale out when:

```text
average thread utilization >= scaleOutThreshold
```

and:

```text
activePodCount < maxPods
```

For example, with 3 pods:

```text
Pod 1 = 100%
Pod 2 = 100%
Pod 3 = 20%

average = 73.3%
```

Do not scale out if the threshold is 80%.

With:

```text
Pod 1 = 100%
Pod 2 = 100%
Pod 3 = 60%

average = 86.7%
```

scale out.

This should be the ONLY trigger for scale-out.

---

# 2. Scale-out should add one pod per evaluation

The simulator evaluates the autoscaler periodically.

At each evaluation:

```text
if average utilization >= scaleOutThreshold
    and pod count < maxPods
then
    add exactly one pod
```

Do not create multiple pods in one evaluation.

Keep the behavior simple and observable.

---

# 3. Scale-in behavior

Scale-in is different because a specific underutilized pod can potentially be removed without affecting the overall workload significantly.

Scale-in should only be considered when:

```text
activePodCount > minPods
```

Find active pods whose utilization is less than or equal to:

```text
scaleInThreshold
```

Those are candidates for removal.

Prefer removing the **least utilized active pod**.

However, do NOT remove a pod simply because it is underutilized.

Before removing it, simulate the removal.

For candidate pod `P`:

```text
projectedBusyThreads =
    totalBusyThreads - P.busyThreadCount

projectedCapacity =
    totalCapacity - P.threadCount

projectedUtilization =
    projectedBusyThreads / projectedCapacity
```

Only scale in if:

```text
projectedUtilization < scaleOutThreshold
```

This means that removing the pod will not immediately leave the remaining pods above the scale-out target.

---

# 4. Examples of correct scale-in behavior

## Example 1 — Safe scale-in

```text
8 threads per pod

Pod 1 = 8 busy
Pod 2 = 2 busy
Pod 3 = 2 busy

total = 12 / 24 = 50%
```

Pod 2 and Pod 3 are underutilized.

Test removing Pod 2:

```text
remaining busy = 10
remaining capacity = 16

projected = 62.5%
```

Since:

```text
62.5% < 80%
```

Pod 2 can be removed.

---

## Example 2 — Unsafe scale-in

```text
8 threads per pod

Pod 1 = 8 busy
Pod 2 = 5 busy
Pod 3 = 1 busy
```

Removing Pod 3 gives:

```text
remaining busy = 13
remaining capacity = 16

projected = 81.25%
```

If scale-out threshold is 80%, do NOT remove Pod 3.

Otherwise the simulator would immediately scale back up, producing undesirable oscillation.

---

# 5. Scale-in should not use average utilization alone

Remove the current logic:

```java
if (avgPodUtil <= scaleInThreshold) {
    shouldScaleIn = true;
}
```

Do not automatically remove a pod merely because the average utilization is low.

Always use the candidate-pod test described above.

For example:

```text
Pod 1 = 20%
Pod 2 = 20%
Pod 3 = 20%
```

Removing one pod is safe because the projected utilization remains 30%.

But the decision should still be expressed through the same candidate-removal calculation rather than a separate special case.

---

# 6. Do not consider STARTING pods as available capacity for scale-in

The autoscaler should distinguish:

```text
ACTIVE
STARTING
TERMINATING
```

For the purposes of this simplified simulator:

* ACTIVE pods provide capacity and participate in utilization calculations.
* STARTING pods are not yet available.
* TERMINATING pods should not be candidates for another scale-in operation.

A pod that is STARTING because of a previous scale-out should not cause the autoscaler to believe that current capacity is already available.

---

# 7. Prevent immediate scale-out after scale-in

The fundamental rule is:

> Never remove a pod if removing it would make the remaining pod fleet cross the scale-out utilization threshold immediately.

The candidate-removal calculation is the primary mechanism for this.

Additionally, implement a simple configurable **scale-down stabilization period**.

Add a configuration property:

```text
scaleDownStabilizationMs
```

Default it to something suitable for the simulator, for example:

```text
30 seconds
```

Do not use the real Kubernetes 5-minute default unless convenient; this is a POC and the shorter value makes behavior easier to observe.

The purpose is to prevent:

```text
scale up
scale down
scale up
scale down
...
```

when utilization fluctuates around the threshold.

Kubernetes' HPA uses a downscale stabilization window, which defaults to 300 seconds, specifically to avoid this kind of oscillation.

For this simulator, a simplified implementation is sufficient:

* record the time of the most recent scale-out;
* do not perform scale-in until `scaleDownStabilizationMs` has elapsed since that scale-out.

This does not need to reproduce Kubernetes' complete recommendation-history algorithm.

---

# 8. Optional tolerance / hysteresis

Do not introduce complicated tolerance logic unless it is already present in the model.

The primary thresholds are:

```text
scaleOutThresholdPct = 80
scaleInThresholdPct = 20
```

These already provide hysteresis.

Scale out at >= 80%.

Scale in only for individual pods <= 20%, and only if removal is safe.

This is sufficient for the POC.

Kubernetes itself also has tolerance around the target metric to avoid reacting to tiny fluctuations, but reproducing that behavior is unnecessary for this simulator.

---

# 9. Suggested algorithm

Replace the current evaluation logic with behavior conceptually equivalent to:

```java
List<Pod> activePods = getActivePods();

if (activePods.isEmpty()) {
    scheduleNextEvaluation();
    return;
}

int totalCapacity = 0;
int totalBusy = 0;

for (Pod pod : activePods) {
    totalCapacity += pod.getThreadCount();
    totalBusy += pod.getBusyThreadCount();
}

double averageUtilization =
        (double) totalBusy / totalCapacity * 100.0;

// ---------------------------
// SCALE OUT
// ---------------------------

if (averageUtilization >= config.getScaleOutThresholdPct()
        && activePods.size() < config.getMaxPods()) {

    engine.scaleOutPod(timestamp);
    recordScaleOut(timestamp);

    scheduleNextEvaluation();
    return;
}

// ---------------------------
// SCALE IN
// ---------------------------

if (activePods.size() > config.getMinPods()
        && !withinScaleDownStabilizationWindow(timestamp)) {

    Pod candidate = activePods.stream()
            .filter(pod ->
                    pod.getBusyThreadCount() * 100.0
                            / pod.getThreadCount()
                            <= config.getScaleInThresholdPct())
            .min(comparingDouble(
                    pod -> (double) pod.getBusyThreadCount()
                            / pod.getThreadCount()))
            .orElse(null);

    if (candidate != null) {

        int projectedBusy =
                totalBusy - candidate.getBusyThreadCount();

        int projectedCapacity =
                totalCapacity - candidate.getThreadCount();

        double projectedUtilization =
                projectedCapacity > 0
                        ? (double) projectedBusy
                            / projectedCapacity
                            * 100.0
                        : 100.0;

        if (projectedUtilization < config.getScaleOutThresholdPct()) {
            engine.scaleInPod(candidate);
        }
    }
}

scheduleNextEvaluation();
```

Adapt the exact code to the existing model and APIs.

---

# 10. Important correction to the scale-in API

Prefer changing:

```java
engine.scaleInPod();
```

to:

```java
engine.scaleInPod(candidate);
```

so that the autoscaler explicitly chooses which pod should terminate.

The pod selected for scale-in should be the least-utilized eligible pod.

The simulation engine should then mark that exact pod as `TERMINATING`.

Do not randomly select a pod for scale-in.

---

# 11. Metrics shown in the UI

Update the autoscaler visualization so that it shows:

```text
Average utilization: 73.3%
Scale-out threshold: 80%
Scale-in threshold: 20%

Scale recommendation:
NONE
SCALE OUT
SCALE IN

Candidate pod:
Pod 3 (12.5%)

Projected utilization after removal:
76.0%
```

This is very useful for debugging the algorithm.

The user should be able to understand WHY a scale operation occurred or did not occur.

---

# 12. Autoscaler logging

Each autoscaler evaluation should optionally produce a concise log/debug entry such as:

```text
Autoscaler:
pods=3
busy=18
capacity=24
avg=75.0%
scaleOutThreshold=80%
scaleInCandidate=Pod-3 (12.5%)
projectedAfterRemoval=83.3%
action=NONE
reason=scale-in would exceed scale-out threshold
```

For a successful scale-out:

```text
Autoscaler:
pods=3
busy=21
capacity=24
avg=87.5%
action=SCALE_OUT
newPods=4
```

For a successful scale-in:

```text
Autoscaler:
pods=4
busy=8
capacity=32
avg=25.0%
candidate=Pod-4 (0.0%)
projected=26.7%
action=SCALE_IN
```

These messages are intended primarily to make the POC easy to validate.

---

# 13. Tests / acceptance scenarios

Add focused unit tests for the autoscaler.

At minimum:

### Test 1 — One busy pod does not cause scale-out

```text
3 pods
8 threads each

Pod 1 = 8 busy
Pod 2 = 8 busy
Pod 3 = 2 busy

average = 75%

threshold = 80%

expected = NO SCALE OUT
```

### Test 2 — Average utilization causes scale-out

```text
3 pods

8 / 8
8 / 8
7 / 8

average = 95.8%

expected = SCALE OUT
```

### Test 3 — Safe scale-in

```text
3 pods

8 / 8
2 / 8
2 / 8

candidate = 2/8

after removal:
10 / 16 = 62.5%

expected = SCALE IN
```

### Test 4 — Unsafe scale-in

```text
3 pods

8 / 8
5 / 8
1 / 8

candidate = 1/8

after removal:
13 / 16 = 81.25%

threshold = 80%

expected = NO SCALE IN
```

### Test 5 — Minimum pods

```text
pods = minPods

expected = never scale in
```

### Test 6 — Maximum pods

```text
pods = maxPods
average utilization > threshold

expected = never scale out
```

### Test 7 — Stabilization

Immediately after scaling out:

```text
average utilization becomes low
```

Expected:

```text
NO SCALE IN until stabilization period expires
```

---

# 14. Keep the implementation simple

This is a POC.

Do NOT attempt to reproduce the complete Kubernetes HPA controller.

The intended approximation is:

```text
                    ┌──────────────────────┐
                    │ Active Pods           │
                    │                      │
                    │ busy threads         │
                    │ / total threads      │
                    └──────────┬───────────┘
                               │
                               ▼
                    Average utilization
                               │
              ┌────────────────┴────────────────┐
              │                                 │
          >= 80%                            < 80%
              │                                 │
           SCALE OUT                    Look for pod <= 20%
                                                │
                                                ▼
                                      Simulate removing it
                                                │
                                  ┌─────────────┴─────────────┐
                                  │                           │
                         projected < 80%             projected >= 80%
                                  │                           │
                              SCALE IN                    NO ACTION
```

The critical change from the existing implementation is:

**Scale-out is an aggregate decision. Scale-in is a candidate-pod decision constrained by projected aggregate utilization.**

Do not retain `hasOverutilizedPod` as a scale-out condition.
