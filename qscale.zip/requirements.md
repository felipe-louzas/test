# Task: Build a Java Swing Work Queue Autoscaling Simulator

Create a small standalone Java Swing application that simulates and visualizes the behavior of a database-backed background-task processing system deployed across horizontally autoscaled pods.

The purpose is a **proof of concept to validate the worker scheduling and horizontal autoscaling algorithm**, not to build a production-grade simulator or capacity planning tool.

The application should be complete and runnable after one implementation pass.

## Technology and constraints

Use:

* Java 25
* Swing for the UI
* Standard Java libraries only; avoid external dependencies unless absolutely necessary
* Maven project
* Clean separation between simulation logic and Swing UI
* The simulation engine must not depend on Swing

Keep the implementation deliberately small and pragmatic. Do not introduce unnecessary frameworks, persistence, networking, Spring, PostgreSQL, Kubernetes clients, or complex architectural layers.

The simulator should run entirely in memory.

---

# 1. Core simulation model

The simulation consists of:

* one or more independent work queues;
* pods;
* a fixed-size worker thread pool in each pod;
* workers scheduled independently for each queue at fixed intervals;
* an autoscaler that creates additional pods when enough threads are busy;
* work items stored in an in-memory database-like queue.

Each pod has a configurable maximum number of worker threads.

A worker occupies exactly one thread for its entire lifetime.

A worker processes work items sequentially, one at a time.

---

# 2. Work queues

Support multiple independent queues.

Each queue should have:

* name;
* initial number of work items;
* work-item arrival configuration;
* processing-time configuration;
* failure probability;
* retry delay;
* maximum retries;
* worker batch size;
* worker scheduling interval.

The UI should allow creating/configuring at least 3 queues.

There should be a default example configuration containing a few queues.

Queues are logically independent, but workers for all queues compete for the same pod thread pools.

---

# 3. Work item generation

Every queue has an arrival process.

Configuration:

* mean arrival rate;
* variance of arrival rate;
* initial queue size.

The simulator should continuously generate new work items according to the configured arrival process.

Use a simple statistical model; do not over-engineer it.

Treat the configured mean and variance as parameters of a normal/random variation around the configured mean. Ensure generated arrival rates/times never become negative.

The exact statistical sophistication is not important. The goal is simply to allow the user to model:

* stable arrivals;
* variable arrivals;
* burstier arrivals.

Also provide an **"Add Work"** button in the UI that immediately adds a configurable number of work items to the selected queue.

The button should support a simple number field such as:

`Add N items`

---

# 4. Work-item processing time

Each queue has:

* mean processing time;
* variance of processing time.

Processing time must be sampled for each individual work item.

Use a simple normal/random distribution around the configured mean and variance.

Never generate a negative processing time; clamp to a small positive minimum.

Processing time represents the time spent by the worker regardless of success or failure.

---

# 5. Work-item failures and retries

Each queue has:

* failure probability;
* retry delay;
* maximum retries.

`maxRetries = 0` means unlimited retries.

When a worker processes an item:

1. It consumes its normal processing time.
2. The item either succeeds or fails according to the failure probability.
3. On success, remove/delete the item from the queue.
4. On failure:

    * increment its retry count;
    * update its `lastUpdate`;
    * make it unavailable until `retryDelay` has elapsed;
    * if maximum retries has been reached, permanently remove the item.

A failed item consumes the same worker processing time as a successful item.

---

# 6. Worker algorithm

This is the most important part of the simulator.

Implement the worker behavior exactly as follows.

When a scheduled worker starts:

```text
executionStart = current simulation time

while true:

    claim up to batchSize eligible work items

    eligibility:
        item.lastUpdate < executionStart
        and item is not currently locked/processing
        and item is not waiting for retry delay

    if no items were claimed:
        exit worker

    process the claimed items sequentially

    for each item:
        consume its processing time
        randomly determine success/failure
        success -> delete item
        failure -> update lastUpdate and retry state

    immediately attempt to claim another batch
```

The worker therefore:

* holds one thread continuously;
* processes batches sequentially;
* may process multiple batches during its lifetime;
* does **not** release its thread between batches;
* exits only when it finds no eligible work;
* immediately releases the thread when it exits.

Do not make a worker process multiple items concurrently.

A worker's batch is simply the maximum number of items it can claim in one database-style claim operation. Processing within the batch remains sequential.

---

# 7. Database queue semantics

Do not use a real database.

Implement an in-memory repository that simulates the relevant database semantics.

The important behavior to reproduce is equivalent to:

```sql
SELECT ...
FROM work_queue
WHERE queue_id = ?
  AND last_update < ?
  AND available_for_processing = true
FOR UPDATE SKIP LOCKED
LIMIT ?
```

Multiple workers and pods must be able to concurrently attempt to claim work.

A work item must never be processed by two workers simultaneously.

Use locking/concurrency mechanisms as necessary to simulate `FOR UPDATE SKIP LOCKED`.

The exact internal implementation is up to you, but the externally observable behavior should match the above semantics.

---

# 8. Scheduling

Each queue has a fixed scheduling interval.

Conceptually every interval:

```text
try to start a worker for this queue
```

Important semantics:

* scheduling is independent for each queue;
* a new worker can be started even if another worker for the same queue is already running;
* multiple workers for the same queue are therefore allowed;
* this is intentional;
* if the queue's workers take longer than the scheduling interval, worker executions accumulate concurrently;
* workers are limited only by available threads.

Example:

```text
schedule interval = 1 second
worker processing takes 5 seconds

t=0   worker A starts
t=1   worker B starts
t=2   worker C starts
t=3   worker D starts
t=4   worker E starts
...
```

If all threads are busy, the scheduled invocation does not create another worker.

There must not be an unbounded secondary worker queue inside the application.

---

# 9. Pod and thread-pool model

Each pod contains:

* a fixed-size thread pool;
* schedulers for every configured queue.

Configuration:

```text
threads per pod
```

A worker occupies exactly one thread while alive.

Track:

* total threads;
* busy threads;
* available threads.

A worker should start only when a pod has an available thread.

Different queues compete for the same available threads.

The initial deployment must contain at least one pod.

---

# 10. Autoscaling simulation

Simulate OpenShift horizontal autoscaling conceptually.

Do not integrate with OpenShift.

The autoscaler observes the percentage of busy worker threads across the deployment.

Configuration:

* minimum pods;
* maximum pods;
* scale-out threshold;
* scale-in threshold;
* autoscaler evaluation interval;
* pod startup delay.

Recommended default behavior:

* scale out when average/busy-thread utilization is >= 80%;
* scale in when utilization is <= 20%;
* never go below minimum pods;
* never exceed maximum pods.

When scaling out:

```text
current pods -> current pods + 1
```

The new pod becomes available after the configured startup delay.

When scaling in, remove one pod only when it has no active workers.

Do not terminate a pod containing active workers.

Keep autoscaling intentionally simple. No need to reproduce all real Kubernetes/HPA stabilization behavior.

The important purpose is to demonstrate:

```text
more busy threads
    ->
more pods
    ->
more threads
    ->
more workers
    ->
higher throughput
```

---

# 11. Simulation clock

Use a simulation clock rather than making the entire application depend on real-time sleeps.

The simulation should advance continuously and support a configurable simulation speed.

At minimum provide:

* Start
* Pause
* Reset

Recommended speed controls:

* 0.5x
* 1x
* 2x
* 5x
* 10x

The simulation should be able to run significantly faster than wall-clock time.

Avoid `Thread.sleep()` as the mechanism for modeling work-item processing.

Represent processing as scheduled simulation events instead.

For example:

```text
worker starts item at simulation time 1000ms
processing time = 750ms
item completes at simulation time 1750ms
```

This is important because the application should remain responsive while simulating many workers.

---

# 12. Event-driven simulation

Implement the simulation using a simple event scheduler.

Events may include:

* work item arrival;
* queue scheduler invocation;
* worker start;
* work-item completion;
* retry availability;
* autoscaler evaluation;
* pod startup.

The simulation engine should advance from event to event.

Do not create one Java thread per simulated worker.

The only real application thread needed for the simulation is the simulation/UI execution mechanism.

---

# 13. Swing UI

Create a simple desktop UI optimized for observing behavior, not configuration complexity.

Recommended layout:

## Top toolbar

Buttons:

* Start
* Pause
* Reset

Simulation speed selector.

Display current simulation time.

## Queue configuration panel

Show one row per queue.

Columns/fields:

* Queue name
* Queue size
* Arrival mean
* Arrival variance
* Processing mean
* Processing variance
* Failure %
* Retry delay
* Max retries
* Batch size
* Schedule interval
* Add N items button

Allow editing the configuration before or while the simulation is running.

Keep the UI simple; a table plus editable fields is sufficient.

## Pod/worker visualization

Show each simulated pod.

For every pod display:

```text
Pod 1
Threads: 8
Busy: 7
Idle: 1
```

Then show individual thread state if practical:

```text
T1  Queue A
T2  Queue A
T3  Queue B
T4  idle
...
```

Use simple colors or labels to distinguish:

* idle;
* processing Queue A;
* processing Queue B;
* etc.

The visualization should make it immediately obvious when:

* workers accumulate;
* all threads become busy;
* another pod appears;
* queue backlog decreases;
* workers finish and threads become free.

---

# 14. Queue visualization

For each queue display at least:

* current pending work-item count;
* workers currently processing that queue;
* oldest pending item age;
* arrival rate;
* completion rate.

A simple horizontal backlog bar is sufficient.

The user should be able to visually see a queue growing or shrinking.

---

# 15. Global metrics

Display a small dashboard with:

* number of pods;
* total threads;
* busy threads;
* thread utilization %;
* total queued items;
* total completed items;
* total failed attempts;
* throughput/items per second;
* oldest queued item age.

These metrics should update continuously.

Do not build complex historical analytics or reporting.

---

# 16. Basic chart

Include one simple real-time line chart showing:

* total queue depth over time;
* number of pods over time.

It is acceptable to implement this as a lightweight custom Swing drawing component instead of using a charting library.

A second line for busy threads is useful if it can be added without significantly increasing complexity.

---

# 17. Default scenario

Start the application with a useful demonstration configuration.

For example:

```text
Pod configuration:
    initial pods = 1
    max pods = 10
    threads per pod = 8
    scale-out threshold = 80%
    scale-in threshold = 20%
    autoscaler interval = 1 second
    pod startup delay = 2 seconds

Queue A:
    initial items = 100
    arrival mean = 2 items/sec
    arrival variance = 0.5
    processing mean = 500 ms
    processing variance = 100 ms
    failure probability = 2%
    retry delay = 2 seconds
    max retries = 0
    batch size = 10
    scheduling interval = 1 second

Queue B:
    initial items = 30
    arrival mean = 0.5 items/sec
    processing mean = 1000 ms
    processing variance = 200 ms
    failure probability = 5%
    retry delay = 3 seconds
    max retries = 3
    batch size = 5
    scheduling interval = 2 seconds
```

The exact defaults are not important as long as the application starts with a configuration that visibly demonstrates worker accumulation and autoscaling.

---

# 18. Simulation correctness requirements

The implementation must satisfy these invariants:

1. A work item can never be processed by two workers simultaneously.
2. A worker occupies exactly one thread while running.
3. A worker can process multiple batches.
4. A worker exits immediately after a batch claim finds no eligible items.
5. A new worker for the same queue may start before an existing worker finishes.
6. Workers for different queues compete for the same pod thread pool.
7. Scheduler invocations cannot create more workers than available threads.
8. Failed items become eligible again only after their retry delay.
9. `lastUpdate < executionStart` must be respected when claiming a batch.
10. Successful work items disappear from the queue.
11. `maxRetries = 0` means unlimited retries.
12. Autoscaling adds pods when configured thread utilization is reached.
13. Autoscaling never exceeds the configured maximum pod count.
14. Pods are not terminated while they contain active workers.
15. Adding work manually must immediately affect the simulation.

---

# 19. Code organization

Use a simple structure similar to:

```text
src/main/java/...

simulation/
    SimulationEngine
    SimulationClock
    SimulationEvent
    EventScheduler

domain/
    WorkItem
    WorkQueue
    Worker
    Pod
    ThreadState
    QueueConfiguration
    PodConfiguration
    AutoscalerConfiguration

engine/
    QueueScheduler
    WorkerEngine
    WorkQueueRepository
    Autoscaler
    WorkItemGenerator
    MetricsCollector

ui/
    MainFrame
    QueuePanel
    PodPanel
    MetricsPanel
    QueueChartPanel
```

The exact package/class structure may be adjusted if a simpler design is better.

Prioritize clarity and correctness over abstraction.

---

# 20. Important implementation guidance

Do not implement a real Java `ExecutorService` for every simulated worker.

Simulated workers are domain objects managed by the simulation engine.

Real Java concurrency should only be used where necessary to keep the Swing application responsive.

The simulator must be deterministic enough that resetting the simulation with the same random seed produces the same behavior.

Use a configurable random seed and provide a default seed.

---

# 21. Acceptance criteria

Consider the implementation complete when all of the following work:

### Scenario A — Worker overlap

Configure:

```text
1 pod
4 threads
1 queue
batch size = 10
schedule interval = 1 sec
processing time = 5 sec
```

The UI should visibly show multiple workers of the same queue running simultaneously.

### Scenario B — Thread saturation

With processing slower than scheduling, the pod's threads should become busy until the maximum thread count is reached.

No more workers should start once all threads are occupied.

### Scenario C — Horizontal scaling

When the thread utilization crosses the autoscaling threshold, another pod should appear after the configured startup delay.

The new pod should provide additional worker threads and allow additional workers to execute.

### Scenario D — Worker self-draining

When processing time becomes short relative to the scheduling interval, workers should finish and exit rather than remaining permanently alive.

### Scenario E — Retries

Configure a high failure probability.

Failed items should remain in the queue, become available only after the retry delay, and eventually disappear after the configured maximum number of retries.

### Scenario F — Manual burst

While the simulation is running, press "Add N items".

The queue should immediately grow and the resulting worker/pod behavior should be observable.

### Scenario G — Multiple queues

Configure two queues with different scheduling intervals and processing times.

Both queues should operate independently while sharing pod thread capacity.

---

# 22. Deliverable

Produce the complete Maven project, including:

* all Java source files;
* `pom.xml`;
* application entry point;
* Swing UI;
* simulation engine;
* default configuration;
* README with:

    * how to run;
    * explanation of the simulation model;
    * explanation of autoscaling behavior;
    * description of the main parameters.

The project must compile and run with:

```bash
mvn clean package
```

and provide a straightforward way to launch the Swing application.

Do not leave TODOs for core functionality.

Do not implement production-grade features that are outside this specification.

The priority order is:

1. Correct worker scheduling semantics.
2. Correct queue/claim semantics.
3. Correct thread utilization and autoscaling behavior.
4. Useful real-time visualization.
5. Simple, understandable code.
