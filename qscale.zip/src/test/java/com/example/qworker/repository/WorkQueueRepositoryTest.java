package com.example.qworker.repository;

import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.model.WorkItem;
import com.example.qworker.model.WorkItemStatus;
import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class WorkQueueRepositoryTest {
    private WorkQueueRepository repository;
    private QueueConfiguration config;

    @Before
    public void setUp() {
        repository = new WorkQueueRepository();
        config = new QueueConfiguration(
                "q1", "Queue 1", 0, 1.0, 0.0,
                500.0, 0.0, 0.0, 2000, 2, 5, 1000
        );
    }

    @Test
    public void testAddAndClaimBatch() {
        repository.addWorkItems("q1", 10, 100);
        assertEquals(10, repository.getPendingCount("q1"));

        // Worker starts execution at T=200
        List<WorkItem> batch = repository.claimBatch("q1", 200, 5, 200, 2000, "worker-1");
        assertEquals(5, batch.size());
        assertEquals(5, repository.getPendingCount("q1"));

        for (WorkItem item : batch) {
            assertEquals(WorkItemStatus.PROCESSING, item.getStatus());
            assertEquals("worker-1", item.getLockedByWorkerId());
        }
    }

    @Test
    public void testExecutionStartFilter() {
        // Items added at T=100
        repository.addWorkItems("q1", 5, 100);

        // Worker executionStart is T=50 (BEFORE items were created/updated)
        List<WorkItem> batch = repository.claimBatch("q1", 50, 5, 100, 2000, "worker-1");
        assertTrue("Worker with executionStart=50 should skip items with lastUpdate=100", batch.isEmpty());

        // Worker executionStart is T=150 (AFTER items were created/updated)
        List<WorkItem> batch2 = repository.claimBatch("q1", 150, 5, 150, 2000, "worker-1");
        assertEquals(5, batch2.size());
    }

    @Test
    public void testSkipLockedSemantics() {
        repository.addWorkItems("q1", 10, 100);

        // Worker 1 claims 5 items
        List<WorkItem> batch1 = repository.claimBatch("q1", 200, 5, 200, 2000, "worker-1");
        assertEquals(5, batch1.size());

        // Worker 2 claims next batch
        List<WorkItem> batch2 = repository.claimBatch("q1", 200, 5, 200, 2000, "worker-2");
        assertEquals(5, batch2.size());

        // Both workers claimed disjoint sets of items
        for (WorkItem item1 : batch1) {
            for (WorkItem item2 : batch2) {
                assertNotEquals(item1.getId(), item2.getId());
            }
        }

        // Worker 3 attempts claim -> empty
        List<WorkItem> batch3 = repository.claimBatch("q1", 200, 5, 200, 2000, "worker-3");
        assertTrue(batch3.isEmpty());
    }

    @Test
    public void testFailureAndRetryDelay() {
        repository.addWorkItems("q1", 1, 100);

        List<WorkItem> batch = repository.claimBatch("q1", 200, 1, 200, 2000, "worker-1");
        assertEquals(1, batch.size());
        long itemId = batch.get(0).getId();

        // Complete with failure at T=250. Retry delay is 2000ms.
        boolean permFail = repository.completeItemFailure(itemId, 250, config);
        assertFalse(permFail);
        assertEquals(1, repository.getPendingCount("q1"));

        // Attempt claim at T=1000 (only 750ms after lastUpdate=250) -> should be unavailable!
        List<WorkItem> retryClaim1 = repository.claimBatch("q1", 3000, 1, 1000, 2000, "worker-2");
        assertTrue("Item should be locked out during retry delay", retryClaim1.isEmpty());

        // Attempt claim at T=2300 (2050ms after lastUpdate=250) -> should be available!
        List<WorkItem> retryClaim2 = repository.claimBatch("q1", 3000, 1, 2300, 2000, "worker-2");
        assertEquals(1, retryClaim2.size());
        assertEquals(itemId, retryClaim2.get(0).getId());
    }

    @Test
    public void testMaxRetriesEnforcement() {
        repository.addWorkItems("q1", 1, 100);
        WorkItem item = repository.claimBatch("q1", 200, 1, 200, 2000, "worker-1").get(0);

        // First failure
        assertFalse(repository.completeItemFailure(item.getId(), 250, config));

        // Claim again after delay
        WorkItem itemRetry = repository.claimBatch("q1", 3000, 1, 3000, 2000, "worker-2").get(0);

        // Second failure (maxRetries = 2) -> permanently fails!
        assertTrue(repository.completeItemFailure(itemRetry.getId(), 3500, config));
        assertEquals(0, repository.getTotalItemsCount("q1"));
    }
}
