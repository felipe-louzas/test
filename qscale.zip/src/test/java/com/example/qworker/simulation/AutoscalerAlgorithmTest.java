package com.example.qworker.simulation;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodConfiguration;
import com.example.qworker.model.PodState;
import com.example.qworker.model.PodThread;
import com.example.qworker.simulation.event.AutoscalerEvaluationEvent;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class AutoscalerAlgorithmTest {
    private SimulationEngine engine;
    private PodConfiguration config;

    @Before
    public void setUp() {
        // Pod config: min=1, max=5, threads=8, scaleOut=80%, scaleInTarget=50%, eval=1000ms, startup=2000ms, scaleOutStab=5000ms, scaleInStab=10000ms
        config = new PodConfiguration(1, 1, 5, 8, 80.0, 50.0, 1000, 2000, 5000L, 10000L);
        engine = new SimulationEngine(config, 100L);
    }

    @Test
    public void testScaleOutRequires5SecondsAbove80Percent() {
        // 3 pods: 8/8, 8/8, 7/8 -> 23/24 = 95.8% >= 80%
        engine.reset();
        engine.setPodConfiguration(config);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.advanceToTime(2000); // Become ACTIVE

        List<Pod> pods = engine.getPods();
        assignBusy(pods.get(0), 8);
        assignBusy(pods.get(1), 8);
        assignBusy(pods.get(2), 7);

        // At T=3000 (1st evaluation tick, 0s high): state = SCALE_OUT_WAITING
        new AutoscalerEvaluationEvent(3000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(0, engine.getStartingPodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_OUT_WAITING, engine.getAutoscalerStatus().getRecommendation());

        // At T=6000 (3s high): state = SCALE_OUT_WAITING
        new AutoscalerEvaluationEvent(6000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(0, engine.getStartingPodCount());

        // At T=8000 (5s high): state = SCALE_OUT (Pod added)
        new AutoscalerEvaluationEvent(8000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(1, engine.getStartingPodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_OUT, engine.getAutoscalerStatus().getRecommendation());
    }

    @Test
    public void testScaleInRequires10SecondsBelow50PercentProjected() {
        // 3 pods: 4/8, 1/8, 1/8 -> Total busy = 6. Projected after removing candidate (1/8): 5/16 = 31.25% < 50%
        engine.reset();
        engine.setPodConfiguration(config);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.advanceToTime(2000);

        List<Pod> pods = engine.getPods();
        assignBusy(pods.get(0), 4);
        assignBusy(pods.get(1), 1);
        assignBusy(pods.get(2), 1);

        // At T=3000 (1st tick, 0s low): state = SCALE_IN_WAITING
        new AutoscalerEvaluationEvent(3000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_IN_WAITING, engine.getAutoscalerStatus().getRecommendation());

        // At T=8000 (5s low < 10s): state = SCALE_IN_WAITING
        new AutoscalerEvaluationEvent(8000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_IN_WAITING, engine.getAutoscalerStatus().getRecommendation());

        // At T=13000 (10s low): state = SCALE_IN (candidate removed)
        new AutoscalerEvaluationEvent(13000).process(engine);
        assertEquals(2, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_IN, engine.getAutoscalerStatus().getRecommendation());
    }

    @Test
    public void testScaleInIgnoresIndividualPodUtilization() {
        // Pod 1 = 4/8 (50%), Pod 2 = 3/8 (37.5%), Pod 3 = 3/8 (37.5%).
        // Note: Neither Pod 2 nor Pod 3 is <= 20%.
        // Total busy = 10. Projected after candidate removal: 7/16 = 43.75% < 50%.
        engine.reset();
        engine.setPodConfiguration(config);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.advanceToTime(2000);

        List<Pod> pods = engine.getPods();
        assignBusy(pods.get(0), 4);
        assignBusy(pods.get(1), 3);
        assignBusy(pods.get(2), 3);

        // At T=3000 (1st tick): projected = 43.75% < 50%, candidate Pod 3 selected even though utilization (37.5%) > 20%!
        new AutoscalerEvaluationEvent(3000).process(engine);
        assertEquals(3, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_IN_WAITING, engine.getAutoscalerStatus().getRecommendation());

        // At T=13000 (10s low): Candidate Pod 3 scaled in!
        new AutoscalerEvaluationEvent(13000).process(engine);
        assertEquals(2, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.SCALE_IN, engine.getAutoscalerStatus().getRecommendation());
    }

    @Test
    public void testMinimumPodsConstraint() {
        // 1 pod (minPods = 1). 0 busy threads.
        engine.reset();
        engine.setPodConfiguration(config);
        engine.scaleOutPod(0);
        engine.advanceToTime(2000);

        new AutoscalerEvaluationEvent(50000).process(engine);

        // Should NEVER scale in below minPods
        assertEquals(1, engine.getActivePodCount());
        assertEquals(AutoscalerStatus.Recommendation.NONE, engine.getAutoscalerStatus().getRecommendation());
    }

    @Test
    public void testMaximumPodsConstraint() {
        // 5 pods (maxPods = 5). All 100% busy.
        engine.reset();
        engine.setPodConfiguration(config);
        for (int i = 0; i < 5; i++) {
            engine.scaleOutPod(0);
        }
        engine.advanceToTime(2000);

        List<Pod> pods = engine.getPods();
        for (Pod p : pods) {
            assignBusy(p, 8);
        }

        new AutoscalerEvaluationEvent(10000).process(engine);

        // Should NEVER scale out beyond maxPods
        assertEquals(5, engine.getActivePodCount());
        assertEquals(0, engine.getStartingPodCount());
        assertEquals(AutoscalerStatus.Recommendation.NONE, engine.getAutoscalerStatus().getRecommendation());
    }

    private void assignBusy(Pod pod, int busyCount) {
        List<PodThread> threads = pod.getThreads();
        for (int i = 0; i < threads.size(); i++) {
            if (i < busyCount) {
                threads.get(i).assignWorker("q", "w-" + i);
            } else {
                threads.get(i).release();
            }
        }
    }
}
