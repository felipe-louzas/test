package com.example.qworker.simulation;

import com.example.qworker.model.PodConfiguration;
import com.example.qworker.model.QueueConfiguration;
import org.junit.Before;
import org.junit.Test;

import static org.junit.Assert.*;

public class WorkItemArrivalTest {
    private SimulationEngine engine;
    private QueueConfiguration config;

    @Before
    public void setUp() {
        PodConfiguration podConfig = new PodConfiguration(1, 1, 5, 8, 80.0, 50.0, 1000, 2000);
        engine = new SimulationEngine(podConfig, 100L);

        // Queue with initial arrival mean = 0
        config = new QueueConfiguration(
                "q-dynamic", "Dynamic Arrival Queue", 0, 0.0, 0.0,
                500.0, 0.0, 0.0, 1000, 0, 5, 1000
        );
        engine.addQueueConfiguration(config);
        engine.initializeDefaultSimulation();
    }

    @Test
    public void testArrivalResumesAfterRateIncreasesFromZero() {
        // Advance time with rate = 0
        engine.advanceToTime(5000);
        assertEquals(0, engine.getMetricsCollector().getTotalSuccesses());
        assertEquals(0, engine.getRepository().getTotalItemsCount());

        // Update arrival mean from 0 to 2 items/sec
        config.setArrivalMean(2.0);

        // Advance time by another 5000ms
        engine.advanceToTime(10000);

        // Work items should now arrive and be processed!
        assertTrue("Work items should arrive after arrival mean increases from 0",
                engine.getMetricsCollector().getTotalSuccesses() + engine.getRepository().getTotalItemsCount() > 0);
    }

    @Test
    public void testHighArrivalRateAccurateGeneration() {
        PodConfiguration podConfig = new PodConfiguration(1, 1, 5, 8, 80.0, 50.0, 1000, 2000);
        SimulationEngine cleanEngine = new SimulationEngine(podConfig, 42L);

        // Queue with arrival mean = 200 items/second
        QueueConfiguration qHigh = new QueueConfiguration(
                "q-high", "High Rate Queue", 0, 200.0, 0.0,
                500.0, 0.0, 0.0, 1000, 0, 10, 1000
        );
        cleanEngine.addQueueConfiguration(qHigh);
        cleanEngine.initializeDefaultSimulation();

        // Advance virtual time by 5 seconds (5000ms)
        cleanEngine.advanceToTime(5000);

        // Expected items over 5s at 200 items/sec = ~1000 items (not 100 items from 50ms clamping!)
        int totalProcessedAndPending = (int) (cleanEngine.getMetricsCollector().getTotalSuccesses() + cleanEngine.getRepository().getTotalItemsCount());
        assertTrue("High rate arrival (200 items/sec over 5s) should generate ~1000 items, got: " + totalProcessedAndPending,
                totalProcessedAndPending >= 900 && totalProcessedAndPending <= 1100);
    }
}
