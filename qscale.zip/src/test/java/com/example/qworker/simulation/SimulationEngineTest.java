package com.example.qworker.simulation;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodConfiguration;
import com.example.qworker.model.QueueConfiguration;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

import static org.junit.Assert.*;

public class SimulationEngineTest {
    private SimulationEngine engine;
    private PodConfiguration podConfig;

    @Before
    public void setUp() {
        // Fast stabilization windows (0ms) for fast unit test execution
        podConfig = new PodConfiguration(
                1, 1, 5, 4, 80.0, 50.0, 1000, 1000, 0L, 0L
        );
        engine = new SimulationEngine(podConfig, 42L);

        QueueConfiguration queueA = new QueueConfiguration(
                "q-a", "Queue A", 20, 0.0, 0.0,
                200.0, 0.0, 0.0, 1000, 0, 5, 500
        );
        engine.addQueueConfiguration(queueA);
        engine.initializeDefaultSimulation();
    }

    @Test
    public void testEngineInitialization() {
        assertEquals(1, engine.getActivePodCount());
        assertEquals(4, engine.getTotalThreadCount());
        assertEquals(20, engine.getRepository().getPendingCount("q-a"));
    }

    @Test
    public void testSimulationAdvancementAndQueueDrain() {
        for (int i = 0; i < 20; i++) {
            engine.advanceToTime(engine.getCurrentSimTimeMs() + 500);
        }

        assertEquals(0, engine.getRepository().getPendingCount("q-a"));
        assertEquals(20, engine.getMetricsCollector().getTotalSuccesses());
        assertEquals(0, engine.getBusyThreadCount());
    }

    @Test
    public void testAutoscalingScaleOutAndScaleIn() {
        // Create heavy queue to trigger scale out
        engine.addQueueConfiguration(new QueueConfiguration(
                "q-heavy", "Heavy Queue", 200, 0.0, 0.0,
                2000.0, 0.0, 0.0, 1000, 0, 5, 200
        ));
        engine.initializeDefaultSimulation();

        // Advance virtual time to trigger thread saturation and autoscaler evaluation
        engine.advanceToTime(1500);
        assertTrue("Pods should scale out beyond 1 pod",
                engine.getActivePodCount() + engine.getStartingPodCount() > 1);

        engine.advanceToTime(3000);
        int activePodsBefore = engine.getActivePodCount();
        assertTrue(activePodsBefore > 1);

        // Now drain repository and advance time for scale in
        engine.getRepository().clear();
        engine.advanceToTime(25000);

        // Autoscaler should scale in back down to minPods (1 pod)
        assertEquals("Autoscaler should scale in back down to minPods (1)",
                1, engine.getActivePodCount());
    }

    @Test
    public void testOpenShiftScaleInNewestPodSelection() {
        // Clear background queues to test manual scale-in selection deterministically
        engine.reset();
        engine.setPodConfiguration(podConfig);
        // Create 3 active pods manually
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.scaleOutPod(0);
        engine.advanceToTime(1000); // Become active

        assertEquals(3, engine.getActivePodCount());
        List<Pod> pods = engine.getPods();
        assertEquals(1, pods.get(0).getPodId());
        assertEquals(2, pods.get(1).getPodId());
        assertEquals(3, pods.get(2).getPodId());

        // Scale in candidate pod 3 (newest pod)
        engine.scaleInPod(pods.get(2));

        // Pod 3 (newest pod) should be terminated/removed!
        List<Pod> remaining = engine.getPods();
        assertEquals(2, remaining.size());
        assertEquals(1, remaining.get(0).getPodId());
        assertEquals(2, remaining.get(1).getPodId());
    }

    @Test
    public void testDeterministicReset() {
        engine.advanceToTime(2000);
        long successesRun1 = engine.getMetricsCollector().getTotalSuccesses();

        engine.reset();
        engine.initializeDefaultSimulation();
        engine.advanceToTime(2000);
        long successesRun2 = engine.getMetricsCollector().getTotalSuccesses();

        assertEquals(successesRun1, successesRun2);
    }

    @Test
    public void testMinBatchSizeWorkerRelease() {
        SimulationEngine cleanEngine = new SimulationEngine(podConfig, 42L);
        QueueConfiguration qMin = new QueueConfiguration(
                "q-min", "Min Batch Queue", 3, 0.0, 0.0,
                100.0, 0.0, 0.0, 1000, 0, 10, 5, 1000 // minBatchSize = 5
        );
        cleanEngine.addQueueConfiguration(qMin);
        cleanEngine.initializeDefaultSimulation();

        // Worker claims 3 items (3 < minBatchSize 5). At T=300 (after 300ms execution), all 3 items complete and worker releases thread.
        cleanEngine.advanceToTime(500);
        assertEquals(0, cleanEngine.getBusyThreadCount());
        assertEquals(3, cleanEngine.getMetricsCollector().getSuccesses("q-min"));
    }
}
