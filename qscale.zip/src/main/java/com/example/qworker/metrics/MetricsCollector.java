package com.example.qworker.metrics;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class MetricsCollector {
    private final Map<String, AtomicLong> arrivalsMap = new ConcurrentHashMap<>();
    private final Map<String, AtomicLong> successesMap = new ConcurrentHashMap<>();
    private final Map<String, AtomicLong> failuresMap = new ConcurrentHashMap<>();
    private final Map<String, AtomicLong> permFailuresMap = new ConcurrentHashMap<>();

    private final AtomicLong totalSuccesses = new AtomicLong(0);
    private final AtomicLong totalFailures = new AtomicLong(0);
    private final AtomicLong totalPermFailures = new AtomicLong(0);

    private final List<DataPoint> timeSeries = Collections.synchronizedList(new ArrayList<>());
    private static final int MAX_TIME_SERIES_POINTS = 300;

    public void reset() {
        arrivalsMap.clear();
        successesMap.clear();
        failuresMap.clear();
        permFailuresMap.clear();
        totalSuccesses.set(0);
        totalFailures.set(0);
        totalPermFailures.set(0);
        timeSeries.clear();
    }

    public void recordArrival(String queueId) {
        arrivalsMap.computeIfAbsent(queueId, k -> new AtomicLong(0)).incrementAndGet();
    }

    public void recordSuccess(String queueId) {
        successesMap.computeIfAbsent(queueId, k -> new AtomicLong(0)).incrementAndGet();
        totalSuccesses.incrementAndGet();
    }

    public void recordFailure(String queueId, boolean permFailed) {
        failuresMap.computeIfAbsent(queueId, k -> new AtomicLong(0)).incrementAndGet();
        totalFailures.incrementAndGet();
        if (permFailed) {
            permFailuresMap.computeIfAbsent(queueId, k -> new AtomicLong(0)).incrementAndGet();
            totalPermFailures.incrementAndGet();
        }
    }

    public long getSuccesses(String queueId) {
        AtomicLong count = successesMap.get(queueId);
        return count != null ? count.get() : 0;
    }

    public long getFailures(String queueId) {
        AtomicLong count = failuresMap.get(queueId);
        return count != null ? count.get() : 0;
    }

    public long getTotalSuccesses() {
        return totalSuccesses.get();
    }

    public long getTotalFailures() {
        return totalFailures.get();
    }

    public long getTotalPermFailures() {
        return totalPermFailures.get();
    }

    public double getThroughput(String queueId, long currentSimTimeMs) {
        if (currentSimTimeMs <= 0) return 0.0;
        long successes = getSuccesses(queueId);
        return (double) successes / (currentSimTimeMs / 1000.0);
    }

    public double getTotalThroughput(long currentSimTimeMs) {
        if (currentSimTimeMs <= 0) return 0.0;
        return (double) totalSuccesses.get() / (currentSimTimeMs / 1000.0);
    }

    public void addTimeSeriesPoint(long timestampMs, int totalQueueDepth, int busyThreads, int podCount) {
        synchronized (timeSeries) {
            timeSeries.add(new DataPoint(timestampMs, totalQueueDepth, busyThreads, podCount));
            if (timeSeries.size() > MAX_TIME_SERIES_POINTS) {
                timeSeries.remove(0);
            }
        }
    }

    public List<DataPoint> getTimeSeriesData() {
        synchronized (timeSeries) {
            return new ArrayList<>(timeSeries);
        }
    }
}
