package com.example.qworker.metrics;

public class DataPoint {
    private final long timestampMs;
    private final int totalQueueDepth;
    private final int busyThreads;
    private final int podCount;

    public DataPoint(long timestampMs, int totalQueueDepth, int busyThreads, int podCount) {
        this.timestampMs = timestampMs;
        this.totalQueueDepth = totalQueueDepth;
        this.busyThreads = busyThreads;
        this.podCount = podCount;
    }

    public long getTimestampMs() {
        return timestampMs;
    }

    public int getTotalQueueDepth() {
        return totalQueueDepth;
    }

    public int getBusyThreads() {
        return busyThreads;
    }

    public int getPodCount() {
        return podCount;
    }
}
