package com.example.qworker.simulation.event;

import com.example.qworker.simulation.SimulationEngine;

import java.util.concurrent.atomic.AtomicLong;

public abstract class SimulationEvent implements Comparable<SimulationEvent> {
    private static final AtomicLong EVENT_ID_GEN = new AtomicLong(0);

    private final long timestampMs;
    private final long eventId;

    public SimulationEvent(long timestampMs) {
        this.timestampMs = timestampMs;
        this.eventId = EVENT_ID_GEN.getAndIncrement();
    }

    public long getTimestampMs() {
        return timestampMs;
    }

    public long getEventId() {
        return eventId;
    }

    public abstract void process(SimulationEngine engine);

    @Override
    public int compareTo(SimulationEvent o) {
        int cmp = Long.compare(this.timestampMs, o.timestampMs);
        if (cmp != 0) {
            return cmp;
        }
        return Long.compare(this.eventId, o.eventId);
    }
}
