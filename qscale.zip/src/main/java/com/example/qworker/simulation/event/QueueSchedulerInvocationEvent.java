package com.example.qworker.simulation.event;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodState;
import com.example.qworker.simulation.SimulationEngine;

/**
 * Legacy/convenience event that triggers per-pod queue scheduling for a queue across all active pods.
 */
public class QueueSchedulerInvocationEvent extends SimulationEvent {
    private final String queueId;

    public QueueSchedulerInvocationEvent(long timestampMs, String queueId) {
        super(timestampMs);
        this.queueId = queueId;
    }

    public String getQueueId() {
        return queueId;
    }

    @Override
    public void process(SimulationEngine engine) {
        for (Pod pod : engine.getPods()) {
            if (pod.getState() == PodState.ACTIVE) {
                engine.scheduleEvent(new PodQueueSchedulerInvocationEvent(getTimestampMs(), pod.getPodId(), queueId));
            }
        }
    }
}
