package com.example.qworker.simulation.event;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodState;
import com.example.qworker.model.PodThread;
import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.simulation.SimulationEngine;

public class PodQueueSchedulerInvocationEvent extends SimulationEvent {
    private final int podId;
    private final String queueId;

    public PodQueueSchedulerInvocationEvent(long timestampMs, int podId, String queueId) {
        super(timestampMs);
        this.podId = podId;
        this.queueId = queueId;
    }

    public int getPodId() {
        return podId;
    }

    public String getQueueId() {
        return queueId;
    }

    @Override
    public void process(SimulationEngine engine) {
        Pod pod = engine.getPodById(podId);
        if (pod == null || pod.getState() != PodState.ACTIVE) {
            return;
        }

        QueueConfiguration config = engine.getQueueConfiguration(queueId);
        if (config == null) {
            return;
        }

        // Try to claim an available thread on THIS POD
        PodThread thread = pod.findAvailableThread();
        if (thread != null) {
            String workerId = "w-" + engine.nextWorkerId();
            thread.assignWorker(queueId, workerId);
            engine.scheduleEvent(new WorkerBatchStartEvent(getTimestampMs(), queueId, workerId, thread));
        }

        // Schedule next invocation on THIS POD for THIS QUEUE
        long interval = Math.max(100, config.getScheduleIntervalMs());
        engine.scheduleEvent(new PodQueueSchedulerInvocationEvent(getTimestampMs() + interval, podId, queueId));
    }
}
