package com.example.qworker.simulation.event;

import com.example.qworker.model.PodThread;
import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.model.WorkItem;
import com.example.qworker.simulation.SimulationEngine;

import java.util.List;

public class WorkerBatchStartEvent extends SimulationEvent {
    private final String queueId;
    private final String workerId;
    private final PodThread thread;

    public WorkerBatchStartEvent(long timestampMs, String queueId, String workerId, PodThread thread) {
        super(timestampMs);
        this.queueId = queueId;
        this.workerId = workerId;
        this.thread = thread;
    }

    @Override
    public void process(SimulationEngine engine) {
        QueueConfiguration config = engine.getQueueConfiguration(queueId);
        if (config == null) {
            engine.releaseThread(thread);
            return;
        }

        // When a batch claim is attempted, executionStart updates to the current simulation time (getTimestampMs())
        long executionStartMs = getTimestampMs();

        List<WorkItem> claimed = engine.getRepository().claimBatch(
                queueId, executionStartMs, config.getBatchSize(), getTimestampMs(), config.getRetryDelayMs(), workerId
        );

        if (claimed.isEmpty()) {
            // Worker exits ONLY when all work items are locked, in retry delay, or queue is empty
            engine.releaseThread(thread);
        } else {
            // Process claimed items sequentially starting at index 0
            WorkItem firstItem = claimed.get(0);
            thread.setCurrentItemId(firstItem.getId());

            double procTime = engine.sampleNormal(config.getProcessingMeanMs(), Math.sqrt(config.getProcessingVarianceMs()));
            long procDuration = Math.max(10, Math.round(procTime));

            engine.scheduleEvent(new WorkItemCompletionEvent(
                    getTimestampMs() + procDuration, queueId, workerId, thread, claimed, 0
            ));
        }
    }
}
