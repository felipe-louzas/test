package com.example.qworker.simulation.event;

import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.simulation.SimulationEngine;

public class WorkItemArrivalEvent extends SimulationEvent {
    private final String queueId;

    public WorkItemArrivalEvent(long timestampMs, String queueId) {
        super(timestampMs);
        this.queueId = queueId;
    }

    public String getQueueId() {
        return queueId;
    }

    @Override
    public void process(SimulationEngine engine) {
        QueueConfiguration config = engine.getQueueConfiguration(queueId);
        if (config == null) {
            return;
        }

        long nextIntervalMs = 1000; // Default check interval if rate <= 0

        double arrivalMean = config.getArrivalMean();
        if (arrivalMean > 0.0) {
            double stdev = Math.sqrt(Math.max(0.0, config.getArrivalVariance()));
            double sampledRate = engine.sampleNormal(arrivalMean, stdev);

            if (sampledRate > 0.0) {
                int itemsToGenerate;
                if (sampledRate <= 1000.0) {
                    itemsToGenerate = 1;
                    nextIntervalMs = Math.max(1, Math.round(1000.0 / sampledRate));
                } else {
                    itemsToGenerate = (int) Math.round(sampledRate / 1000.0);
                    nextIntervalMs = 1;
                }

                // Add generated work items
                engine.getRepository().addWorkItems(queueId, itemsToGenerate, getTimestampMs());
                for (int i = 0; i < itemsToGenerate; i++) {
                    engine.getMetricsCollector().recordArrival(queueId);
                }
            }
        }

        // ALWAYS schedule the next arrival event so the arrival generator loop never dies
        engine.scheduleEvent(new WorkItemArrivalEvent(getTimestampMs() + nextIntervalMs, queueId));
    }
}
