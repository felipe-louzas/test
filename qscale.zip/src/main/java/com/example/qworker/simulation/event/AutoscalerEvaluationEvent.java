package com.example.qworker.simulation.event;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodConfiguration;
import com.example.qworker.model.PodState;
import com.example.qworker.simulation.AutoscalerStatus;
import com.example.qworker.simulation.SimulationEngine;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class AutoscalerEvaluationEvent extends SimulationEvent {

    public AutoscalerEvaluationEvent(long timestampMs) {
        super(timestampMs);
    }

    @Override
    public void process(SimulationEngine engine) {
        PodConfiguration config = engine.getPodConfiguration();
        if (config == null) {
            return;
        }

        List<Pod> activePods = new ArrayList<>();
        for (Pod pod : engine.getPods()) {
            if (pod.getState() == PodState.ACTIVE) {
                activePods.add(pod);
            }
        }

        if (activePods.isEmpty()) {
            engine.setHighUtilizationStartTimeMs(-1);
            engine.setLowUtilizationStartTimeMs(-1);
            engine.setAutoscalerStatus(new AutoscalerStatus(0.0, AutoscalerStatus.Recommendation.NONE, "None", 0.0, "No active pods"));
            scheduleNextEvaluation(engine, config);
            return;
        }

        int totalCapacity = 0;
        int totalBusy = 0;

        for (Pod pod : activePods) {
            totalCapacity += pod.getThreadCount();
            totalBusy += pod.getBusyThreadCount();
        }

        double averageUtilization = totalCapacity > 0 ? ((double) totalBusy / totalCapacity) * 100.0 : 0.0;

        // ---------------------------
        // 1. SCALE OUT EVALUATION (>= 80% for 5s)
        // ---------------------------
        if (averageUtilization >= config.getScaleOutThresholdPct()) {
            engine.setLowUtilizationStartTimeMs(-1); // Reset scale-in timer

            if (activePods.size() < config.getMaxPods()) {
                long highStart = engine.getHighUtilizationStartTimeMs();
                if (highStart < 0) {
                    highStart = getTimestampMs();
                    engine.setHighUtilizationStartTimeMs(highStart);
                }

                long durationHigh = getTimestampMs() - highStart;
                long requiredHigh = config.getScaleOutStabilizationMs(); // default 5000ms (5s)

                if (durationHigh >= requiredHigh) {
                    engine.scaleOutPod(getTimestampMs());
                    engine.setLastScaleOutTimeMs(getTimestampMs());
                    engine.setHighUtilizationStartTimeMs(-1);

                    String reason = String.format("Utilization (%.1f%% >= %.1f%%) sustained for %.1fs (>= %.1fs) -> SCALE OUT",
                            averageUtilization, config.getScaleOutThresholdPct(), durationHigh / 1000.0, requiredHigh / 1000.0);
                    engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.SCALE_OUT, "None", 0.0, reason));
                } else {
                    String reason = String.format("Utilization (%.1f%% >= %.1f%%) for %.1fs / %.1fs needed to scale out",
                            averageUtilization, config.getScaleOutThresholdPct(), durationHigh / 1000.0, requiredHigh / 1000.0);
                    engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.SCALE_OUT_WAITING, "None", 0.0, reason));
                }
            } else {
                engine.setHighUtilizationStartTimeMs(-1);
                String reason = String.format("Utilization (%.1f%%) >= %.1f%%, but maxPods (%d) reached",
                        averageUtilization, config.getScaleOutThresholdPct(), config.getMaxPods());
                engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.NONE, "None", 0.0, reason));
            }

            scheduleNextEvaluation(engine, config);
            return;
        }

        // Reset scale-out timer if utilization drops below threshold
        engine.setHighUtilizationStartTimeMs(-1);

        // ---------------------------
        // 2. SCALE IN EVALUATION (Projected < 50% for 10s)
        // ---------------------------
        if (activePods.size() > config.getMinPods()) {
            // Pick candidate pod (fewest busy threads first, tie-break newest podId)
            Comparator<Pod> candidateComparator = Comparator
                    .comparingInt(Pod::getBusyThreadCount)
                    .thenComparing((p1, p2) -> Integer.compare(p2.getPodId(), p1.getPodId()));

            Pod candidate = activePods.stream()
                    .min(candidateComparator)
                    .orElse(null);

            if (candidate != null) {
                int projectedBusy = totalBusy - candidate.getBusyThreadCount();
                int projectedCapacity = totalCapacity - candidate.getThreadCount();
                double projectedUtilization = projectedCapacity > 0 ? ((double) projectedBusy / projectedCapacity) * 100.0 : 100.0;

                double candidateUtil = ((double) candidate.getBusyThreadCount() / candidate.getThreadCount()) * 100.0;
                String candidateStr = String.format("Pod %d (%.1f%%)", candidate.getPodId(), candidateUtil);

                double scaleInProjectedTargetPct = config.getScaleInThresholdPct(); // Default 50.0%

                if (projectedUtilization < scaleInProjectedTargetPct) {
                    long lowStart = engine.getLowUtilizationStartTimeMs();
                    if (lowStart < 0) {
                        lowStart = getTimestampMs();
                        engine.setLowUtilizationStartTimeMs(lowStart);
                    }

                    long durationLow = getTimestampMs() - lowStart;
                    long requiredLow = config.getScaleInStabilizationMs(); // default 10000ms (10s)

                    if (durationLow >= requiredLow) {
                        String reason = String.format("Projected util (%.1f%% < %.1f%%) sustained for %.1fs (>= %.1fs) -> SCALE IN candidate Pod %d",
                                projectedUtilization, scaleInProjectedTargetPct, durationLow / 1000.0, requiredLow / 1000.0, candidate.getPodId());
                        engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.SCALE_IN, candidateStr, projectedUtilization, reason));
                        engine.scaleInPod(candidate);
                        engine.setLowUtilizationStartTimeMs(-1);
                    } else {
                        String reason = String.format("Projected util (%.1f%% < %.1f%%) for %.1fs / %.1fs needed to scale in Pod %d",
                                projectedUtilization, scaleInProjectedTargetPct, durationLow / 1000.0, requiredLow / 1000.0, candidate.getPodId());
                        engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.SCALE_IN_WAITING, candidateStr, projectedUtilization, reason));
                    }
                } else {
                    engine.setLowUtilizationStartTimeMs(-1);
                    String reason = String.format("Candidate Pod %d projected utilization (%.1f%%) >= target (%.1f%%)",
                            candidate.getPodId(), projectedUtilization, scaleInProjectedTargetPct);
                    engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.NONE, candidateStr, projectedUtilization, reason));
                }

                scheduleNextEvaluation(engine, config);
                return;
            }
        }

        engine.setLowUtilizationStartTimeMs(-1);
        String reason = String.format("Fleet at minPods (%d)", config.getMinPods());
        engine.setAutoscalerStatus(new AutoscalerStatus(averageUtilization, AutoscalerStatus.Recommendation.NONE, "None", 0.0, reason));
        scheduleNextEvaluation(engine, config);
    }

    private void scheduleNextEvaluation(SimulationEngine engine, PodConfiguration config) {
        long interval = Math.max(100, config.getAutoscalerIntervalMs());
        engine.scheduleEvent(new AutoscalerEvaluationEvent(getTimestampMs() + interval));
    }
}
