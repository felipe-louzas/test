package com.example.qworker.simulation.event;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodState;
import com.example.qworker.simulation.SimulationEngine;

public class PodStartupCompletedEvent extends SimulationEvent {
    private final int podId;

    public PodStartupCompletedEvent(long timestampMs, int podId) {
        super(timestampMs);
        this.podId = podId;
    }

    public int getPodId() {
        return podId;
    }

    @Override
    public void process(SimulationEngine engine) {
        Pod pod = engine.getPodById(podId);
        if (pod != null && pod.getState() == PodState.STARTING) {
            pod.setState(PodState.ACTIVE);
            // Launch per-pod queue schedulers for all configured queues
            engine.startQueueSchedulersForPod(getTimestampMs(), podId);
        }
    }
}
