package com.example.qworker.simulation;

import com.example.qworker.metrics.MetricsCollector;
import com.example.qworker.model.*;
import com.example.qworker.repository.WorkQueueRepository;
import com.example.qworker.simulation.event.*;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

public class SimulationEngine {
    private final PriorityQueue<SimulationEvent> eventQueue = new PriorityQueue<>();
    private final WorkQueueRepository repository = new WorkQueueRepository();
    private final MetricsCollector metricsCollector = new MetricsCollector();

    private final Map<String, QueueConfiguration> queueConfigs = new ConcurrentHashMap<>();
    private volatile PodConfiguration podConfig;
    private final List<Pod> pods = new CopyOnWriteArrayList<>();

    private final AtomicInteger podIdGen = new AtomicInteger(1);
    private final AtomicInteger workerIdGen = new AtomicInteger(1);

    private long currentSimTimeMs = 0;
    private long lastTimeSeriesSampleSimTimeMs = 0;
    private long lastScaleOutTimeMs = -100000L; // Default far in past
    private long highUtilizationStartTimeMs = -1L;
    private long lowUtilizationStartTimeMs = -1L;
    private long randomSeed = 12345L;
    private Random random = new Random(randomSeed);

    private volatile AutoscalerStatus autoscalerStatus = new AutoscalerStatus(0.0, AutoscalerStatus.Recommendation.NONE, "None", 0.0, "Initialized");

    private volatile boolean running = false;
    private volatile double speedMultiplier = 1.0;

    private ScheduledExecutorService executor;
    private final List<Runnable> stateListeners = new CopyOnWriteArrayList<>();

    public SimulationEngine(PodConfiguration podConfig, long randomSeed) {
        this.podConfig = podConfig;
        this.randomSeed = randomSeed;
        this.random = new Random(randomSeed);
    }

    public synchronized void setRandomSeed(long seed) {
        this.randomSeed = seed;
        this.random = new Random(seed);
    }

    public long getRandomSeed() {
        return randomSeed;
    }

    public Random getRandom() {
        return random;
    }

    public WorkQueueRepository getRepository() {
        return repository;
    }

    public MetricsCollector getMetricsCollector() {
        return metricsCollector;
    }

    public synchronized long getCurrentSimTimeMs() {
        return currentSimTimeMs;
    }

    public double getSpeedMultiplier() {
        return speedMultiplier;
    }

    public void setSpeedMultiplier(double speedMultiplier) {
        this.speedMultiplier = speedMultiplier;
    }

    public boolean isRunning() {
        return running;
    }

    public PodConfiguration getPodConfiguration() {
        return podConfig;
    }

    public void setPodConfiguration(PodConfiguration podConfig) {
        this.podConfig = podConfig;
    }

    public long getLastScaleOutTimeMs() {
        return lastScaleOutTimeMs;
    }

    public void setLastScaleOutTimeMs(long lastScaleOutTimeMs) {
        this.lastScaleOutTimeMs = lastScaleOutTimeMs;
    }

    public long getHighUtilizationStartTimeMs() {
        return highUtilizationStartTimeMs;
    }

    public void setHighUtilizationStartTimeMs(long highUtilizationStartTimeMs) {
        this.highUtilizationStartTimeMs = highUtilizationStartTimeMs;
    }

    public long getLowUtilizationStartTimeMs() {
        return lowUtilizationStartTimeMs;
    }

    public void setLowUtilizationStartTimeMs(long lowUtilizationStartTimeMs) {
        this.lowUtilizationStartTimeMs = lowUtilizationStartTimeMs;
    }

    public boolean withinScaleDownStabilizationWindow(long currentTimeMs) {
        if (lastScaleOutTimeMs < 0) return false;
        long window = podConfig != null ? podConfig.getScaleInStabilizationMs() : 10000L;
        return (currentTimeMs - lastScaleOutTimeMs) < window;
    }

    public AutoscalerStatus getAutoscalerStatus() {
        return autoscalerStatus;
    }

    public void setAutoscalerStatus(AutoscalerStatus autoscalerStatus) {
        this.autoscalerStatus = autoscalerStatus;
    }

    public QueueConfiguration getQueueConfiguration(String queueId) {
        return queueConfigs.get(queueId);
    }

    public Collection<QueueConfiguration> getQueueConfigurations() {
        return queueConfigs.values();
    }

    public synchronized void addQueueConfiguration(QueueConfiguration config) {
        queueConfigs.put(config.getId(), config);
        // Start arrival process loop for this queue
        scheduleEvent(new WorkItemArrivalEvent(currentSimTimeMs, config.getId()));
        // Start schedulers for this new queue on all currently active pods
        for (Pod pod : pods) {
            if (pod.getState() == PodState.ACTIVE) {
                scheduleEvent(new PodQueueSchedulerInvocationEvent(currentSimTimeMs, pod.getPodId(), config.getId()));
            }
        }
    }

    public List<Pod> getPods() {
        return Collections.unmodifiableList(new ArrayList<>(pods));
    }

    public Pod getPodById(int podId) {
        for (Pod p : pods) {
            if (p.getPodId() == podId) {
                return p;
            }
        }
        return null;
    }

    public int nextPodId() {
        return podIdGen.getAndIncrement();
    }

    public int nextWorkerId() {
        return workerIdGen.getAndIncrement();
    }

    public synchronized void scheduleEvent(SimulationEvent event) {
        eventQueue.add(event);
    }

    public double sampleNormal(double mean, double stdev) {
        if (stdev <= 0) return Math.max(1.0, mean);
        double val = mean + random.nextGaussian() * stdev;
        return Math.max(1.0, val);
    }

    public synchronized void startQueueSchedulersForPod(long timestampMs, int podId) {
        for (QueueConfiguration qConfig : queueConfigs.values()) {
            scheduleEvent(new PodQueueSchedulerInvocationEvent(timestampMs, podId, qConfig.getId()));
        }
    }

    public synchronized void initializeDefaultSimulation() {
        reset();

        // Initialize pods
        for (int i = 0; i < podConfig.getInitialPods(); i++) {
            int pId = podIdGen.getAndIncrement();
            Pod pod = new Pod(pId, podConfig.getThreadsPerPod(), PodState.ACTIVE, 0, 0);
            pods.add(pod);
            // Launch per-pod queue schedulers
            startQueueSchedulersForPod(0, pId);
        }

        // Initialize queues and arrival processes
        for (QueueConfiguration qConfig : queueConfigs.values()) {
            if (qConfig.getInitialItems() > 0) {
                repository.addWorkItems(qConfig.getId(), qConfig.getInitialItems(), 0);
            }
            // Always schedule arrival process loop for every queue
            scheduleEvent(new WorkItemArrivalEvent(0, qConfig.getId()));
        }

        // Schedule initial autoscaler evaluation
        scheduleEvent(new AutoscalerEvaluationEvent(podConfig.getAutoscalerIntervalMs()));

        // Sample initial time-series point
        metricsCollector.addTimeSeriesPoint(0, repository.getTotalPendingCount(), getBusyThreadCount(), getActivePodCount());
        notifyStateListeners();
    }

    public synchronized void start() {
        if (running) return;
        running = true;

        executor = Executors.newSingleThreadScheduledExecutor();
        final long tickIntervalRealMs = 20; // 50 Hz tick rate

        executor.scheduleAtFixedRate(() -> {
            try {
                if (!running) return;

                long deltaSimMs;
                synchronized (this) {
                    deltaSimMs = Math.round(tickIntervalRealMs * speedMultiplier);
                    long targetSimTimeMs = currentSimTimeMs + deltaSimMs;

                    advanceToTime(targetSimTimeMs);
                }

                notifyStateListeners();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }, 0, tickIntervalRealMs, TimeUnit.MILLISECONDS);
    }

    public synchronized void pause() {
        running = false;
        if (executor != null) {
            executor.shutdown();
            executor = null;
        }
        notifyStateListeners();
    }

    public synchronized void reset() {
        pause();
        currentSimTimeMs = 0;
        lastTimeSeriesSampleSimTimeMs = 0;
        lastScaleOutTimeMs = -100000L;
        highUtilizationStartTimeMs = -1L;
        lowUtilizationStartTimeMs = -1L;
        eventQueue.clear();
        repository.clear();
        metricsCollector.reset();
        pods.clear();
        podIdGen.set(1);
        workerIdGen.set(1);
        autoscalerStatus = new AutoscalerStatus(0.0, AutoscalerStatus.Recommendation.NONE, "None", 0.0, "Reset");
        random = new Random(randomSeed);
        notifyStateListeners();
    }

    public synchronized void advanceToTime(long targetSimTimeMs) {
        while (!eventQueue.isEmpty() && eventQueue.peek().getTimestampMs() <= targetSimTimeMs) {
            SimulationEvent event = eventQueue.poll();
            currentSimTimeMs = event.getTimestampMs();
            event.process(this);
        }
        currentSimTimeMs = targetSimTimeMs;

        // Sample time series every 500ms of virtual simulation time
        if (currentSimTimeMs - lastTimeSeriesSampleSimTimeMs >= 500) {
            lastTimeSeriesSampleSimTimeMs = currentSimTimeMs;
            metricsCollector.addTimeSeriesPoint(
                    currentSimTimeMs,
                    repository.getTotalPendingCount(),
                    getBusyThreadCount(),
                    getActivePodCount()
            );
        }
    }

    public synchronized void addWorkItemsManual(String queueId, int count) {
        if (count <= 0) return;
        repository.addWorkItems(queueId, count, currentSimTimeMs);
        notifyStateListeners();
    }

    public synchronized void releaseThread(PodThread thread) {
        if (thread == null) return;
        thread.release();

        // Check if thread belongs to a pod that is TERMINATING
        for (Pod pod : pods) {
            if (pod.getThreads().contains(thread)) {
                if (pod.getState() == PodState.TERMINATING && !pod.hasActiveWorkers()) {
                    pod.setState(PodState.TERMINATED);
                    pods.remove(pod);
                }
                break;
            }
        }
    }

    public synchronized void scaleOutPod(long currentTimeMs) {
        int newPodId = nextPodId();
        Pod newPod = new Pod(newPodId, podConfig.getThreadsPerPod(), PodState.STARTING, currentTimeMs, currentTimeMs + podConfig.getPodStartupDelayMs());
        pods.add(newPod);
        scheduleEvent(new PodStartupCompletedEvent(currentTimeMs + podConfig.getPodStartupDelayMs(), newPodId));
    }

    public synchronized void scaleInPod(Pod candidatePod) {
        if (candidatePod == null) return;
        if (candidatePod.getState() == PodState.ACTIVE) {
            candidatePod.setState(PodState.TERMINATING);
            if (!candidatePod.hasActiveWorkers()) {
                candidatePod.setState(PodState.TERMINATED);
                pods.remove(candidatePod);
            }
        }
    }

    public int getActivePodCount() {
        int count = 0;
        for (Pod p : pods) {
            if (p.getState() == PodState.ACTIVE) {
                count++;
            }
        }
        return count;
    }

    public int getStartingPodCount() {
        int count = 0;
        for (Pod p : pods) {
            if (p.getState() == PodState.STARTING) {
                count++;
            }
        }
        return count;
    }

    public int getTotalThreadCount() {
        int count = 0;
        for (Pod p : pods) {
            if (p.getState() == PodState.ACTIVE) {
                count += p.getThreadCount();
            }
        }
        return count;
    }

    public int getBusyThreadCount() {
        int count = 0;
        for (Pod p : pods) {
            if (p.getState() == PodState.ACTIVE || p.getState() == PodState.TERMINATING) {
                count += p.getBusyThreadCount();
            }
        }
        return count;
    }

    public int getActiveWorkerCountForQueue(String queueId) {
        int count = 0;
        for (Pod p : pods) {
            for (PodThread t : p.getThreads()) {
                if (!t.isIdle() && queueId.equals(t.getCurrentQueueId())) {
                    count++;
                }
            }
        }
        return count;
    }

    public void addStateListener(Runnable listener) {
        stateListeners.add(listener);
    }

    public void removeStateListener(Runnable listener) {
        stateListeners.remove(listener);
    }

    public void notifyStateListeners() {
        for (Runnable listener : stateListeners) {
            try {
                listener.run();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
