package com.example.qworker.simulation.event;

import com.example.qworker.model.PodThread;
import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.model.WorkItem;
import com.example.qworker.simulation.SimulationEngine;

import java.util.List;

public class WorkItemCompletionEvent extends SimulationEvent {
    private final String queueId;
    private final String workerId;
    private final PodThread thread;
    private final List<WorkItem> batchItems;
    private final int itemIndex;

    public WorkItemCompletionEvent(long timestampMs, String queueId, String workerId, PodThread thread,
                                  List<WorkItem> batchItems, int itemIndex) {
        super(timestampMs);
        this.queueId = queueId;
        this.workerId = workerId;
        this.thread = thread;
        this.batchItems = batchItems;
        this.itemIndex = itemIndex;
    }

    @Override
    public void process(SimulationEngine engine) {
        QueueConfiguration config = engine.getQueueConfiguration(queueId);
        if (config == null) {
            engine.releaseThread(thread);
            return;
        }

        WorkItem currentItem = batchItems.get(itemIndex);
        boolean success = engine.getRandom().nextDouble() >= config.getFailureProbability();

        if (success) {
            engine.getRepository().completeItemSuccess(currentItem.getId());
            engine.getMetricsCollector().recordSuccess(queueId);
        } else {
            boolean permFailed = engine.getRepository().completeItemFailure(currentItem.getId(), getTimestampMs(), config);
            engine.getMetricsCollector().recordFailure(queueId, permFailed);
        }

        if (itemIndex + 1 < batchItems.size()) {
            // Process next item in batch sequentially
            WorkItem nextItem = batchItems.get(itemIndex + 1);
            thread.setCurrentItemId(nextItem.getId());

            double procTime = engine.sampleNormal(config.getProcessingMeanMs(), Math.sqrt(config.getProcessingVarianceMs()));
            long procDuration = Math.max(10, Math.round(procTime));

            engine.scheduleEvent(new WorkItemCompletionEvent(
                    getTimestampMs() + procDuration, queueId, workerId, thread, batchItems, itemIndex + 1
            ));
        } else {
            // Batch complete. Check if claimed batch size met minimum lock count requirement
            thread.setCurrentItemId(null);
            if (batchItems.size() < config.getMinBatchSize()) {
                // If returned item count was below minimum lock count, release thread!
                engine.releaseThread(thread);
            } else {
                // Immediately attempt to claim another batch!
                engine.scheduleEvent(new WorkerBatchStartEvent(getTimestampMs(), queueId, workerId, thread));
            }
        }
    }
}
