package com.example.qworker.simulation;

public class AutoscalerStatus {
    public enum Recommendation {
        NONE,
        SCALE_OUT_WAITING,
        SCALE_OUT,
        SCALE_IN_WAITING,
        SCALE_IN
    }

    private final double averageUtilization;
    private final Recommendation recommendation;
    private final String candidatePodName;
    private final double projectedUtilization;
    private final String reason;

    public AutoscalerStatus(double averageUtilization, Recommendation recommendation,
                            String candidatePodName, double projectedUtilization, String reason) {
        this.averageUtilization = averageUtilization;
        this.recommendation = recommendation;
        this.candidatePodName = candidatePodName != null ? candidatePodName : "None";
        this.projectedUtilization = projectedUtilization;
        this.reason = reason != null ? reason : "";
    }

    public double getAverageUtilization() {
        return averageUtilization;
    }

    public Recommendation getRecommendation() {
        return recommendation;
    }

    public String getCandidatePodName() {
        return candidatePodName;
    }

    public double getProjectedUtilization() {
        return projectedUtilization;
    }

    public String getReason() {
        return reason;
    }
}
