package com.example.qworker;

import com.example.qworker.model.PodConfiguration;
import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.simulation.SimulationEngine;
import com.example.qworker.ui.MainFrame;

import javax.swing.*;

public class Main {
    public static void main(String[] args) {
        // Set System Look & Feel if available
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {
        }

        // Configure default pod autoscaler settings (Section 17 & New Stabilization Rules)
        PodConfiguration podConfig = new PodConfiguration(
                1,      // initial pods
                1,      // min pods
                10,     // max pods
                8,      // threads per pod
                80.0,   // scale-out threshold %
                70.0,   // scale-in projected threshold %
                1000,   // autoscaler interval ms
                2000,   // pod startup delay ms
                5000L,  // 5s scale-out stabilization
                10000L  // 10s scale-in stabilization
        );

        SimulationEngine engine = new SimulationEngine(podConfig, 12345L);

        // Queue A
        QueueConfiguration queueA = new QueueConfiguration(
                "queue-a", "Queue A", 100, 2.0, 0.5,
                500.0, 100.0, 0.02, 2000, 0, 10, 1000
        );

        // Queue B
        QueueConfiguration queueB = new QueueConfiguration(
                "queue-b", "Queue B", 30, 0.5, 0.1,
                1000.0, 2000.0, 0.05, 3000, 3, 5, 2000
        );

        // Queue C
        QueueConfiguration queueC = new QueueConfiguration(
                "queue-c", "Queue C", 0, 1.0, 0.2,
                300.0, 50.0, 0.0, 1000, 0, 8, 1500
        );

        engine.addQueueConfiguration(queueA);
        engine.addQueueConfiguration(queueB);
        engine.addQueueConfiguration(queueC);

        engine.initializeDefaultSimulation();

        // Launch Swing GUI on Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            MainFrame frame = new MainFrame(engine);
            frame.setVisible(true);
        });
    }
}
