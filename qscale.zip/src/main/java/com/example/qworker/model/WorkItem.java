package com.example.qworker.model;

public class WorkItem {
    private final long id;
    private final String queueId;
    private final long createdAt;
    private long lastUpdate;
    private int retryCount;
    private String lockedByWorkerId;
    private WorkItemStatus status;

    public WorkItem(long id, String queueId, long createdAt) {
        this.id = id;
        this.queueId = queueId;
        this.createdAt = createdAt;
        this.lastUpdate = createdAt;
        this.retryCount = 0;
        this.lockedByWorkerId = null;
        this.status = WorkItemStatus.PENDING;
    }

    public long getId() {
        return id;
    }

    public String getQueueId() {
        return queueId;
    }

    public long getCreatedAt() {
        return createdAt;
    }

    public long getLastUpdate() {
        return lastUpdate;
    }

    public void setLastUpdate(long lastUpdate) {
        this.lastUpdate = lastUpdate;
    }

    public int getRetryCount() {
        return retryCount;
    }

    public void incrementRetryCount() {
        this.retryCount++;
    }

    public String getLockedByWorkerId() {
        return lockedByWorkerId;
    }

    public void setLockedByWorkerId(String lockedByWorkerId) {
        this.lockedByWorkerId = lockedByWorkerId;
    }

    public WorkItemStatus getStatus() {
        return status;
    }

    public void setStatus(WorkItemStatus status) {
        this.status = status;
    }
}
