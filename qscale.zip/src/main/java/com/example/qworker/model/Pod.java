package com.example.qworker.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Pod {
    private final int podId;
    private volatile PodState state;
    private final int threadCount;
    private final List<PodThread> threads;
    private final long startupTimeMs;
    private final long readyTimeMs;

    public Pod(int podId, int threadCount, PodState initialState, long startupTimeMs, long readyTimeMs) {
        this.podId = podId;
        this.threadCount = threadCount;
        this.state = initialState;
        this.startupTimeMs = startupTimeMs;
        this.readyTimeMs = readyTimeMs;

        List<PodThread> threadList = new ArrayList<>();
        for (int i = 1; i <= threadCount; i++) {
            threadList.add(new PodThread(i));
        }
        this.threads = Collections.unmodifiableList(threadList);
    }

    public int getPodId() { return podId; }

    public PodState getState() { return state; }
    public void setState(PodState state) { this.state = state; }

    public int getThreadCount() { return threadCount; }

    public List<PodThread> getThreads() { return threads; }

    public long getStartupTimeMs() { return startupTimeMs; }
    public long getReadyTimeMs() { return readyTimeMs; }

    public int getBusyThreadCount() {
        int count = 0;
        for (PodThread t : threads) {
            if (!t.isIdle()) {
                count++;
            }
        }
        return count;
    }

    public int getIdleThreadCount() {
        return threadCount - getBusyThreadCount();
    }

    public synchronized PodThread findAvailableThread() {
        if (state != PodState.ACTIVE) {
            return null;
        }
        for (PodThread t : threads) {
            if (t.isIdle()) {
                return t;
            }
        }
        return null;
    }

    public boolean hasActiveWorkers() {
        return getBusyThreadCount() > 0;
    }
}
