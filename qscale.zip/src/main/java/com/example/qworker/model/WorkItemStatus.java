package com.example.qworker.model;

public enum WorkItemStatus {
    PENDING,
    PROCESSING
}
