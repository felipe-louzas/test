package com.example.qworker.model;

public class PodConfiguration {
    private volatile int initialPods;
    private volatile int minPods;
    private volatile int maxPods;
    private volatile int threadsPerPod;
    private volatile double scaleOutThresholdPct;
    private volatile double scaleInThresholdPct; // Target projected utilization threshold for scale-in (e.g. 50%)
    private volatile long autoscalerIntervalMs;
    private volatile long podStartupDelayMs;
    private volatile long scaleOutStabilizationMs; // Duration required above 80% to scale out (e.g. 5000ms)
    private volatile long scaleInStabilizationMs;  // Duration required below 50% projected to scale in (e.g. 10000ms)

    public PodConfiguration(int initialPods, int minPods, int maxPods, int threadsPerPod,
                            double scaleOutThresholdPct, double scaleInThresholdPct,
                            long autoscalerIntervalMs, long podStartupDelayMs) {
        this(initialPods, minPods, maxPods, threadsPerPod, scaleOutThresholdPct, scaleInThresholdPct, autoscalerIntervalMs, podStartupDelayMs, 5000L, 10000L);
    }

    public PodConfiguration(int initialPods, int minPods, int maxPods, int threadsPerPod,
                            double scaleOutThresholdPct, double scaleInThresholdPct,
                            long autoscalerIntervalMs, long podStartupDelayMs,
                            long scaleOutStabilizationMs, long scaleInStabilizationMs) {
        this.initialPods = initialPods;
        this.minPods = minPods;
        this.maxPods = maxPods;
        this.threadsPerPod = threadsPerPod;
        this.scaleOutThresholdPct = scaleOutThresholdPct;
        this.scaleInThresholdPct = scaleInThresholdPct;
        this.autoscalerIntervalMs = autoscalerIntervalMs;
        this.podStartupDelayMs = podStartupDelayMs;
        this.scaleOutStabilizationMs = scaleOutStabilizationMs;
        this.scaleInStabilizationMs = scaleInStabilizationMs;
    }

    public int getInitialPods() { return initialPods; }
    public void setInitialPods(int initialPods) { this.initialPods = initialPods; }

    public int getMinPods() { return minPods; }
    public void setMinPods(int minPods) { this.minPods = minPods; }

    public int getMaxPods() { return maxPods; }
    public void setMaxPods(int maxPods) { this.maxPods = maxPods; }

    public int getThreadsPerPod() { return threadsPerPod; }
    public void setThreadsPerPod(int threadsPerPod) { this.threadsPerPod = threadsPerPod; }

    public double getScaleOutThresholdPct() { return scaleOutThresholdPct; }
    public void setScaleOutThresholdPct(double scaleOutThresholdPct) { this.scaleOutThresholdPct = scaleOutThresholdPct; }

    public double getScaleInThresholdPct() { return scaleInThresholdPct; }
    public void setScaleInThresholdPct(double scaleInThresholdPct) { this.scaleInThresholdPct = scaleInThresholdPct; }

    public long getAutoscalerIntervalMs() { return autoscalerIntervalMs; }
    public void setAutoscalerIntervalMs(long autoscalerIntervalMs) { this.autoscalerIntervalMs = autoscalerIntervalMs; }

    public long getPodStartupDelayMs() { return podStartupDelayMs; }
    public void setPodStartupDelayMs(long podStartupDelayMs) { this.podStartupDelayMs = podStartupDelayMs; }

    public long getScaleOutStabilizationMs() { return scaleOutStabilizationMs; }
    public void setScaleOutStabilizationMs(long scaleOutStabilizationMs) { this.scaleOutStabilizationMs = scaleOutStabilizationMs; }

    public long getScaleInStabilizationMs() { return scaleInStabilizationMs; }
    public void setScaleInStabilizationMs(long scaleInStabilizationMs) { this.scaleInStabilizationMs = scaleInStabilizationMs; }
}
