package com.example.qworker.model;

public class PodThread {
    private final int threadId;
    private ThreadStatus status;
    private String currentQueueId;
    private String currentWorkerId;
    private Long currentItemId;

    public PodThread(int threadId) {
        this.threadId = threadId;
        this.status = ThreadStatus.IDLE;
        this.currentQueueId = null;
        this.currentWorkerId = null;
        this.currentItemId = null;
    }

    public int getThreadId() {
        return threadId;
    }

    public synchronized ThreadStatus getStatus() {
        return status;
    }

    public synchronized boolean isIdle() {
        return status == ThreadStatus.IDLE;
    }

    public synchronized String getCurrentQueueId() {
        return currentQueueId;
    }

    public synchronized String getCurrentWorkerId() {
        return currentWorkerId;
    }

    public synchronized Long getCurrentItemId() {
        return currentItemId;
    }

    public synchronized void assignWorker(String queueId, String workerId) {
        this.status = ThreadStatus.BUSY;
        this.currentQueueId = queueId;
        this.currentWorkerId = workerId;
        this.currentItemId = null;
    }

    public synchronized void setCurrentItemId(Long itemIndex) {
        this.currentItemId = itemIndex;
    }

    public synchronized void release() {
        this.status = ThreadStatus.IDLE;
        this.currentQueueId = null;
        this.currentWorkerId = null;
        this.currentItemId = null;
    }
}
