package com.example.qworker.model;

public class QueueConfiguration {
    private final String id;
    private volatile String name;
    private volatile int initialItems;
    private volatile double arrivalMean;       // items per second
    private volatile double arrivalVariance;
    private volatile double processingMeanMs;  // milliseconds
    private volatile double processingVarianceMs;
    private volatile double failureProbability; // 0.0 to 1.0
    private volatile long retryDelayMs;       // milliseconds
    private volatile int maxRetries;           // 0 = unlimited
    private volatile int batchSize;            // max batch size
    private volatile int minBatchSize;         // min lock count to continue worker loop (default 1)
    private volatile long scheduleIntervalMs;  // milliseconds

    public QueueConfiguration(String id, String name, int initialItems, double arrivalMean, double arrivalVariance,
                              double processingMeanMs, double processingVarianceMs, double failureProbability,
                              long retryDelayMs, int maxRetries, int batchSize, long scheduleIntervalMs) {
        this(id, name, initialItems, arrivalMean, arrivalVariance, processingMeanMs, processingVarianceMs,
                failureProbability, retryDelayMs, maxRetries, batchSize, 1, scheduleIntervalMs);
    }

    public QueueConfiguration(String id, String name, int initialItems, double arrivalMean, double arrivalVariance,
                              double processingMeanMs, double processingVarianceMs, double failureProbability,
                              long retryDelayMs, int maxRetries, int batchSize, int minBatchSize, long scheduleIntervalMs) {
        this.id = id;
        this.name = name;
        this.initialItems = initialItems;
        this.arrivalMean = arrivalMean;
        this.arrivalVariance = arrivalVariance;
        this.processingMeanMs = processingMeanMs;
        this.processingVarianceMs = processingVarianceMs;
        this.failureProbability = failureProbability;
        this.retryDelayMs = retryDelayMs;
        this.maxRetries = maxRetries;
        this.batchSize = batchSize;
        this.minBatchSize = minBatchSize > 0 ? minBatchSize : 1;
        this.scheduleIntervalMs = scheduleIntervalMs;
    }

    public String getId() { return id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getInitialItems() { return initialItems; }
    public void setInitialItems(int initialItems) { this.initialItems = initialItems; }

    public double getArrivalMean() { return arrivalMean; }
    public void setArrivalMean(double arrivalMean) { this.arrivalMean = arrivalMean; }

    public double getArrivalVariance() { return arrivalVariance; }
    public void setArrivalVariance(double arrivalVariance) { this.arrivalVariance = arrivalVariance; }

    public double getProcessingMeanMs() { return processingMeanMs; }
    public void setProcessingMeanMs(double processingMeanMs) { this.processingMeanMs = processingMeanMs; }

    public double getProcessingVarianceMs() { return processingVarianceMs; }
    public void setProcessingVarianceMs(double processingVarianceMs) { this.processingVarianceMs = processingVarianceMs; }

    public double getFailureProbability() { return failureProbability; }
    public void setFailureProbability(double failureProbability) { this.failureProbability = failureProbability; }

    public long getRetryDelayMs() { return retryDelayMs; }
    public void setRetryDelayMs(long retryDelayMs) { this.retryDelayMs = retryDelayMs; }

    public int getMaxRetries() { return maxRetries; }
    public void setMaxRetries(int maxRetries) { this.maxRetries = maxRetries; }

    public int getBatchSize() { return batchSize; }
    public void setBatchSize(int batchSize) { this.batchSize = batchSize; }

    public int getMinBatchSize() { return minBatchSize; }
    public void setMinBatchSize(int minBatchSize) { this.minBatchSize = Math.max(1, minBatchSize); }

    public long getScheduleIntervalMs() { return scheduleIntervalMs; }
    public void setScheduleIntervalMs(long scheduleIntervalMs) { this.scheduleIntervalMs = scheduleIntervalMs; }
}
