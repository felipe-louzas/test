package com.example.qworker.model;

public enum ThreadStatus {
    IDLE,
    BUSY
}
