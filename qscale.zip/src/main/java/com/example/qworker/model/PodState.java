package com.example.qworker.model;

public enum PodState {
    STARTING,
    ACTIVE,
    TERMINATING,
    TERMINATED
}
