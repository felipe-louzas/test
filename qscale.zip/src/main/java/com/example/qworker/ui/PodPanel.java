package com.example.qworker.ui;

import com.example.qworker.model.Pod;
import com.example.qworker.model.PodState;
import com.example.qworker.model.PodThread;
import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class PodPanel extends JPanel {
    private final SimulationEngine engine;
    private final JPanel podGridPanel;

    private static final Color COLOR_IDLE = new Color(220, 224, 230);

    private static final Color[] QUEUE_COLORS = new Color[]{
            new Color(41, 128, 185), // Queue A - Blue
            new Color(230, 126, 34), // Queue B - Orange
            new Color(142, 68, 173), // Queue C - Purple
            new Color(39, 174, 96),  // Queue D - Green
            new Color(231, 76, 60)   // Queue E - Red
    };

    public PodPanel(SimulationEngine engine) {
        this.engine = engine;
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Pod & Worker Thread Visualization", TitledBorder.LEFT, TitledBorder.TOP, new Font("SansSerif", Font.BOLD, 13)));
        setLayout(new BorderLayout());

        podGridPanel = new JPanel(new WrapLayout(FlowLayout.LEFT, 12, 12));

        JScrollPane scroll = new JScrollPane(podGridPanel);
        scroll.setBorder(null);
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        scroll.getVerticalScrollBar().setUnitIncrement(16);

        add(scroll, BorderLayout.CENTER);
    }

    public void updatePods() {
        podGridPanel.removeAll();

        List<Pod> pods = engine.getPods();
        Map<String, Color> queueColorMap = buildQueueColorMap();

        for (Pod pod : pods) {
            podGridPanel.add(createPodCard(pod, queueColorMap));
        }

        podGridPanel.revalidate();
        podGridPanel.repaint();
    }

    private Map<String, Color> buildQueueColorMap() {
        Map<String, Color> map = new HashMap<>();
        int idx = 0;
        for (var config : engine.getQueueConfigurations()) {
            map.put(config.getId(), QUEUE_COLORS[idx % QUEUE_COLORS.length]);
            idx++;
        }
        return map;
    }

    private JPanel createPodCard(Pod pod, Map<String, Color> queueColorMap) {
        JPanel card = new JPanel(new BorderLayout(6, 6));
        card.setPreferredSize(new Dimension(240, 220));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(getBorderColor(pod.getState()), 2, true),
                BorderFactory.createEmptyBorder(8, 8, 8, 8)
        ));
        card.setBackground(Color.WHITE);

        // Pod Header
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JLabel lblTitle = new JLabel("Pod " + pod.getPodId());
        lblTitle.setFont(new Font("SansSerif", Font.BOLD, 14));

        JLabel lblState = new JLabel(" [" + pod.getState() + "] ");
        lblState.setFont(new Font("SansSerif", Font.BOLD, 11));
        lblState.setOpaque(true);
        lblState.setBackground(getStateColor(pod.getState()));
        lblState.setForeground(Color.WHITE);

        header.add(lblTitle, BorderLayout.WEST);
        header.add(lblState, BorderLayout.EAST);

        // Threads Summary
        JLabel lblThreadsSummary = new JLabel(String.format("Threads: %d | Busy: %d | Idle: %d",
                pod.getThreadCount(), pod.getBusyThreadCount(), pod.getIdleThreadCount()));
        lblThreadsSummary.setFont(new Font("SansSerif", Font.PLAIN, 11));

        JPanel topContainer = new JPanel(new GridLayout(2, 1, 2, 2));
        topContainer.setOpaque(false);
        topContainer.add(header);
        topContainer.add(lblThreadsSummary);

        card.add(topContainer, BorderLayout.NORTH);

        // Threads Grid
        if (pod.getState() == PodState.STARTING) {
            JPanel startingPanel = new JPanel(new GridBagLayout());
            startingPanel.setOpaque(false);
            long remainingMs = Math.max(0, pod.getReadyTimeMs() - engine.getCurrentSimTimeMs());
            JLabel lblBoot = new JLabel(String.format("⚡ Booting... (%.1fs)", remainingMs / 1000.0));
            lblBoot.setFont(new Font("SansSerif", Font.BOLD, 12));
            lblBoot.setForeground(new Color(200, 120, 0));
            startingPanel.add(lblBoot);
            card.add(startingPanel, BorderLayout.CENTER);
        } else {
            JPanel threadsGrid = new JPanel(new GridLayout(4, 2, 6, 6));
            threadsGrid.setOpaque(false);

            for (PodThread thread : pod.getThreads()) {
                threadsGrid.add(createThreadBadge(thread, queueColorMap));
            }
            card.add(threadsGrid, BorderLayout.CENTER);
        }

        return card;
    }

    private JPanel createThreadBadge(PodThread thread, Map<String, Color> queueColorMap) {
        JPanel badge = new JPanel(new BorderLayout(4, 2));
        badge.setBorder(BorderFactory.createEmptyBorder(4, 6, 4, 6));

        if (thread.isIdle()) {
            badge.setBackground(COLOR_IDLE);
            JLabel lblId = new JLabel("T" + thread.getThreadId());
            lblId.setFont(new Font("SansSerif", Font.BOLD, 10));
            lblId.setForeground(Color.GRAY);

            JLabel lblState = new JLabel("idle");
            lblState.setFont(new Font("SansSerif", Font.PLAIN, 10));
            lblState.setForeground(Color.DARK_GRAY);

            badge.add(lblId, BorderLayout.WEST);
            badge.add(lblState, BorderLayout.EAST);
        } else {
            String queueId = thread.getCurrentQueueId();
            Color bgColor = queueColorMap.getOrDefault(queueId, Color.BLUE);
            badge.setBackground(bgColor);

            JLabel lblId = new JLabel("T" + thread.getThreadId());
            lblId.setFont(new Font("SansSerif", Font.BOLD, 10));
            lblId.setForeground(Color.WHITE);

            String qName = queueId != null ? queueId.toUpperCase() : "BUSY";
            JLabel lblState = new JLabel(qName);
            lblState.setFont(new Font("SansSerif", Font.BOLD, 10));
            lblState.setForeground(Color.WHITE);

            badge.add(lblId, BorderLayout.WEST);
            badge.add(lblState, BorderLayout.EAST);
        }

        return badge;
    }

    private Color getBorderColor(PodState state) {
        switch (state) {
            case ACTIVE: return new Color(40, 167, 69);
            case STARTING: return new Color(255, 193, 7);
            case TERMINATING: return new Color(220, 53, 69);
            default: return Color.GRAY;
        }
    }

    private Color getStateColor(PodState state) {
        switch (state) {
            case ACTIVE: return new Color(40, 167, 69);
            case STARTING: return new Color(255, 193, 7);
            case TERMINATING: return new Color(220, 53, 69);
            default: return Color.GRAY;
        }
    }

    /**
     * FlowLayout subclass that fully supports wrapping components in a JScrollPane.
     */
    private static class WrapLayout extends FlowLayout {
        public WrapLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            return layoutSize(target, true);
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            Dimension minimum = layoutSize(target, false);
            minimum.width -= (getHgap() + 1);
            return minimum;
        }

        private Dimension layoutSize(Container target, boolean preferred) {
            synchronized (target.getTreeLock()) {
                int targetWidth = target.getWidth();
                Container container = target;

                while (container.getSize().width == 0 && container.getParent() != null) {
                    container = container.getParent();
                }

                int containerWidth = container.getSize().width;
                if (containerWidth == 0) {
                    containerWidth = Integer.MAX_VALUE;
                }

                int hgap = getHgap();
                int vgap = getVgap();
                Insets insets = target.getInsets();
                int maxwidth = containerWidth - (insets.left + insets.right + hgap * 2);

                int nmembers = target.getComponentCount();
                int x = 0;
                int y = insets.top + vgap;
                int rowHeight = 0;

                for (int i = 0; i < nmembers; i++) {
                    Component m = target.getComponent(i);
                    if (m.isVisible()) {
                        Dimension d = preferred ? m.getPreferredSize() : m.getMinimumSize();
                        if ((x == 0) || ((x + d.width) <= maxwidth)) {
                            if (x > 0) {
                                x += hgap;
                            }
                            x += d.width;
                            rowHeight = Math.max(rowHeight, d.height);
                        } else {
                            x = d.width;
                            y += vgap + rowHeight;
                            rowHeight = d.height;
                        }
                    }
                }
                return new Dimension(containerWidth, y + rowHeight + vgap + insets.bottom);
            }
        }
    }
}
