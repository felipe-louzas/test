package com.example.qworker.ui;

import com.example.qworker.simulation.AutoscalerStatus;
import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;

public class GlobalMetricsPanel extends JPanel {
    private final SimulationEngine engine;

    private final JLabel lblPods = createValueLabel();
    private final JLabel lblThreads = createValueLabel();
    private final JLabel lblUtilization = createValueLabel();
    private final JLabel lblQueued = createValueLabel();
    private final JLabel lblCompleted = createValueLabel();
    private final JLabel lblFailures = createValueLabel();
    private final JLabel lblThroughput = createValueLabel();
    private final JLabel lblOldestAge = createValueLabel();

    private final JLabel lblRecommendation = createValueLabel();
    private final JLabel lblCandidatePod = createValueLabel();
    private final JLabel lblProjectedUtil = createValueLabel();
    private final JLabel lblAutoscalerReason = createValueLabel();

    public GlobalMetricsPanel(SimulationEngine engine) {
        this.engine = engine;
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Global Dashboard & Autoscaler Telemetry", TitledBorder.LEFT, TitledBorder.TOP, new Font("SansSerif", Font.BOLD, 13)));
        setLayout(new GridLayout(3, 4, 10, 6));

        add(createCard("Pods (Active / Starting)", lblPods));
        add(createCard("Threads (Busy / Total)", lblThreads));
        add(createCard("Avg Thread Utilization", lblUtilization));
        add(createCard("Queued Items", lblQueued));

        add(createCard("Completed Items", lblCompleted));
        add(createCard("Failed Attempts", lblFailures));
        add(createCard("Overall Throughput", lblThroughput));
        add(createCard("Oldest Queued Age", lblOldestAge));

        add(createCard("HPA Recommendation", lblRecommendation));
        add(createCard("Scale-In Candidate", lblCandidatePod));
        add(createCard("Projected Util. After Removal", lblProjectedUtil));
        add(createCard("Autoscaler Diagnostics", lblAutoscalerReason));
    }

    private JPanel createCard(String title, JLabel valueLabel) {
        JPanel card = new JPanel(new BorderLayout(2, 2));
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(210, 210, 210), 1),
                BorderFactory.createEmptyBorder(4, 8, 4, 8)
        ));
        card.setBackground(new Color(248, 249, 250));

        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        titleLabel.setForeground(new Color(100, 100, 100));

        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        return card;
    }

    private JLabel createValueLabel() {
        JLabel label = new JLabel("-");
        label.setFont(new Font("SansSerif", Font.BOLD, 13));
        label.setForeground(new Color(30, 30, 30));
        return label;
    }

    public void updateMetrics() {
        int activePods = engine.getActivePodCount();
        int startingPods = engine.getStartingPodCount();
        int busyThreads = engine.getBusyThreadCount();
        int totalThreads = engine.getTotalThreadCount();

        int totalItems = engine.getRepository().getTotalItemsCount();
        int unassignedItems = engine.getRepository().getTotalPendingCount();

        long completed = engine.getMetricsCollector().getTotalSuccesses();
        long failures = engine.getMetricsCollector().getTotalFailures();
        long permFailures = engine.getMetricsCollector().getTotalPermFailures();
        double throughput = engine.getMetricsCollector().getTotalThroughput(engine.getCurrentSimTimeMs());
        long oldestAgeMs = engine.getRepository().getOldestItemAgeOverallMs(engine.getCurrentSimTimeMs());

        AutoscalerStatus status = engine.getAutoscalerStatus();

        lblPods.setText(String.format("%d Active (%d starting)", activePods, startingPods));
        lblThreads.setText(String.format("%d / %d Busy", busyThreads, totalThreads));
        lblUtilization.setText(String.format("%.1f %%", status.getAverageUtilization()));
        lblQueued.setText(String.format("%d (%d unassigned)", totalItems, unassignedItems));

        lblCompleted.setText(String.valueOf(completed));
        lblFailures.setText(String.format("%d (%d perm)", failures, permFailures));
        lblThroughput.setText(String.format("%.2f / sec", throughput));

        double oldestSec = oldestAgeMs / 1000.0;
        lblOldestAge.setText(String.format("%.1f s", oldestSec));

        lblRecommendation.setText(status.getRecommendation().name());
        if (status.getRecommendation() == AutoscalerStatus.Recommendation.SCALE_OUT) {
            lblRecommendation.setForeground(new Color(40, 167, 69));
        } else if (status.getRecommendation() == AutoscalerStatus.Recommendation.SCALE_OUT_WAITING) {
            lblRecommendation.setForeground(new Color(255, 152, 0));
        } else if (status.getRecommendation() == AutoscalerStatus.Recommendation.SCALE_IN) {
            lblRecommendation.setForeground(new Color(220, 53, 69));
        } else if (status.getRecommendation() == AutoscalerStatus.Recommendation.SCALE_IN_WAITING) {
            lblRecommendation.setForeground(new Color(33, 150, 243));
        } else {
            lblRecommendation.setForeground(Color.DARK_GRAY);
        }

        lblCandidatePod.setText(status.getCandidatePodName());
        lblProjectedUtil.setText(status.getRecommendation() == AutoscalerStatus.Recommendation.SCALE_IN || !status.getCandidatePodName().equals("None") ? String.format("%.1f %%", status.getProjectedUtilization()) : "N/A");
        lblAutoscalerReason.setText(status.getReason());
        lblAutoscalerReason.setToolTipText(status.getReason());
    }
}
