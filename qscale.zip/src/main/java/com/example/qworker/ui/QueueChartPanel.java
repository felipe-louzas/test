package com.example.qworker.ui;

import com.example.qworker.metrics.DataPoint;
import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.List;

public class QueueChartPanel extends JPanel {
    private final SimulationEngine engine;

    private static final Color COLOR_BG = new Color(250, 250, 252);
    private static final Color COLOR_GRID = new Color(225, 225, 230);
    private static final Color COLOR_QUEUE_DEPTH = new Color(41, 128, 185); // Blue
    private static final Color COLOR_POD_COUNT = new Color(39, 174, 96);    // Green
    private static final Color COLOR_BUSY_THREADS = new Color(230, 126, 34); // Orange

    public QueueChartPanel(SimulationEngine engine) {
        this.engine = engine;
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Real-Time Telemetry (Queue Depth / Pods / Busy Threads)", TitledBorder.LEFT, TitledBorder.TOP, new Font("SansSerif", Font.BOLD, 13)));
        setBackground(COLOR_BG);
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        int paddingLeft = 45;
        int paddingRight = 20;
        int paddingTop = 30;
        int paddingBottom = 35;

        int chartWidth = width - paddingLeft - paddingRight;
        int chartHeight = height - paddingTop - paddingBottom;

        if (chartWidth <= 0 || chartHeight <= 0) {
            g2.dispose();
            return;
        }

        // Background & Grid
        g2.setColor(Color.WHITE);
        g2.fillRect(paddingLeft, paddingTop, chartWidth, chartHeight);
        g2.setColor(COLOR_GRID);
        g2.drawRect(paddingLeft, paddingTop, chartWidth, chartHeight);

        List<DataPoint> data = engine.getMetricsCollector().getTimeSeriesData();

        // Draw Legend
        drawLegend(g2, paddingLeft + 10, paddingTop - 12);

        if (data.isEmpty()) {
            g2.setColor(Color.GRAY);
            g2.drawString("No simulation data available...", paddingLeft + 20, paddingTop + 40);
            g2.dispose();
            return;
        }

        // Determine Y Max
        int maxVal = 10;
        for (DataPoint dp : data) {
            maxVal = Math.max(maxVal, dp.getTotalQueueDepth());
            maxVal = Math.max(maxVal, dp.getBusyThreads());
            maxVal = Math.max(maxVal, dp.getPodCount() * 8); // Scale pod count visually
        }
        maxVal = (int) Math.ceil(maxVal * 1.15); // Add margin

        // Draw Horizontal Grid Lines
        int numGridLines = 4;
        g2.setFont(new Font("SansSerif", Font.PLAIN, 10));
        g2.setColor(new Color(180, 180, 180));
        for (int i = 0; i <= numGridLines; i++) {
            int y = paddingTop + chartHeight - (i * chartHeight / numGridLines);
            g2.setColor(COLOR_GRID);
            g2.drawLine(paddingLeft, y, paddingLeft + chartWidth, y);

            int val = (maxVal * i) / numGridLines;
            g2.setColor(Color.DARK_GRAY);
            g2.drawString(String.valueOf(val), 8, y + 4);
        }

        int n = data.size();
        if (n < 2) {
            g2.dispose();
            return;
        }

        // Draw Lines for Queue Depth, Pod Count, Busy Threads
        PathPoints queuePath = new PathPoints(n);
        PathPoints busyThreadsPath = new PathPoints(n);
        PathPoints podCountPath = new PathPoints(n);

        for (int i = 0; i < n; i++) {
            DataPoint dp = data.get(i);
            int x = paddingLeft + (i * chartWidth / (n - 1));

            int yQueue = paddingTop + chartHeight - (dp.getTotalQueueDepth() * chartHeight / maxVal);
            int yBusy = paddingTop + chartHeight - (dp.getBusyThreads() * chartHeight / maxVal);
            int yPods = paddingTop + chartHeight - ((dp.getPodCount() * 8) * chartHeight / maxVal);

            queuePath.add(x, yQueue);
            busyThreadsPath.add(x, yBusy);
            podCountPath.add(x, yPods);
        }

        g2.setStroke(new BasicStroke(2.0f));

        // Queue Depth Line
        g2.setColor(COLOR_QUEUE_DEPTH);
        g2.drawPolyline(queuePath.xs, queuePath.ys, n);

        // Busy Threads Line
        g2.setColor(COLOR_BUSY_THREADS);
        g2.drawPolyline(busyThreadsPath.xs, busyThreadsPath.ys, n);

        // Pod Count Line
        g2.setColor(COLOR_POD_COUNT);
        g2.drawPolyline(podCountPath.xs, podCountPath.ys, n);

        g2.dispose();
    }

    private void drawLegend(Graphics2D g2, int x, int y) {
        g2.setFont(new Font("SansSerif", Font.BOLD, 11));

        drawLegendItem(g2, x, y, COLOR_QUEUE_DEPTH, "Total Queue Depth");
        drawLegendItem(g2, x + 150, y, COLOR_BUSY_THREADS, "Busy Threads");
        drawLegendItem(g2, x + 280, y, COLOR_POD_COUNT, "Pods (scaled x8)");
    }

    private void drawLegendItem(Graphics2D g2, int x, int y, Color color, String label) {
        g2.setColor(color);
        g2.fillRect(x, y - 8, 12, 10);
        g2.setColor(Color.BLACK);
        g2.drawString(label, x + 16, y);
    }

    private static class PathPoints {
        int[] xs;
        int[] ys;
        int idx = 0;

        PathPoints(int size) {
            xs = new int[size];
            ys = new int[size];
        }

        void add(int x, int y) {
            xs[idx] = x;
            ys[idx] = y;
            idx++;
        }
    }
}
