package com.example.qworker.ui;

import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class QueueConfigPanel extends JPanel {
    private final SimulationEngine engine;
    private final JPanel queueContainer;

    public QueueConfigPanel(SimulationEngine engine) {
        this.engine = engine;
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Queue Configurations & Controls", TitledBorder.LEFT, TitledBorder.TOP, new Font("SansSerif", Font.BOLD, 13)));
        setLayout(new BorderLayout());

        queueContainer = new JPanel();
        queueContainer.setLayout(new BoxLayout(queueContainer, BoxLayout.Y_AXIS));

        JScrollPane scrollPane = new JScrollPane(queueContainer);
        scrollPane.setBorder(null);
        add(scrollPane, BorderLayout.CENTER);

        rebuildQueuePanels();
    }

    public void rebuildQueuePanels() {
        queueContainer.removeAll();
        for (QueueConfiguration config : engine.getQueueConfigurations()) {
            queueContainer.add(createSingleQueueRow(config));
            queueContainer.add(Box.createVerticalStrut(10));
        }
        queueContainer.revalidate();
        queueContainer.repaint();
    }

    private JPanel createSingleQueueRow(QueueConfiguration config) {
        JPanel row = new JPanel();
        row.setLayout(new BorderLayout(8, 8));
        row.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(200, 200, 200), 1),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        row.setBackground(new Color(252, 252, 253));

        // Header Panel with Queue Name, Pending Items, and Burst Button
        JPanel headerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 2));
        headerPanel.setOpaque(false);

        JLabel lblName = new JLabel(config.getName() + " (" + config.getId() + ")");
        lblName.setFont(new Font("SansSerif", Font.BOLD, 14));
        lblName.setForeground(new Color(0, 102, 204));
        headerPanel.add(lblName);

        JTextField txtBurstCount = new JTextField("50", 4);
        JButton btnAddBurst = new JButton("Add N items");
        btnAddBurst.setBackground(new Color(0, 123, 255));
        btnAddBurst.setForeground(Color.WHITE);
        btnAddBurst.addActionListener(e -> {
            try {
                int count = Integer.parseInt(txtBurstCount.getText().trim());
                engine.addWorkItemsManual(config.getId(), count);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Please enter a valid integer count.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
            }
        });

        headerPanel.add(new JLabel("Burst:"));
        headerPanel.add(txtBurstCount);
        headerPanel.add(btnAddBurst);

        row.add(headerPanel, BorderLayout.NORTH);

        // Fields Panel (Grid of Config Inputs)
        JPanel fieldsPanel = new JPanel(new GridLayout(2, 6, 8, 4));
        fieldsPanel.setOpaque(false);

        JTextField txtArrMean = createNumberField(String.valueOf(config.getArrivalMean()));
        JTextField txtArrVar = createNumberField(String.valueOf(config.getArrivalVariance()));
        JTextField txtProcMean = createNumberField(String.valueOf((int) config.getProcessingMeanMs()));
        JTextField txtProcVar = createNumberField(String.valueOf((int) config.getProcessingVarianceMs()));
        JTextField txtFailProb = createNumberField(String.valueOf((int) (config.getFailureProbability() * 100)));
        JTextField txtRetryDelay = createNumberField(String.valueOf((int) config.getRetryDelayMs()));

        JTextField txtMaxRetries = createNumberField(String.valueOf(config.getMaxRetries()));
        JTextField txtBatchSize = createNumberField(String.valueOf(config.getBatchSize()));
        JTextField txtMinBatchSize = createNumberField(String.valueOf(config.getMinBatchSize()));
        JTextField txtSchedInterval = createNumberField(String.valueOf((int) config.getScheduleIntervalMs()));

        JButton btnApply = new JButton("Apply Config");
        btnApply.addActionListener(e -> {
            try {
                config.setArrivalMean(Double.parseDouble(txtArrMean.getText().trim()));
                config.setArrivalVariance(Double.parseDouble(txtArrVar.getText().trim()));
                config.setProcessingMeanMs(Double.parseDouble(txtProcMean.getText().trim()));
                config.setProcessingVarianceMs(Double.parseDouble(txtProcVar.getText().trim()));
                config.setFailureProbability(Double.parseDouble(txtFailProb.getText().trim()) / 100.0);
                config.setRetryDelayMs(Long.parseLong(txtRetryDelay.getText().trim()));
                config.setMaxRetries(Integer.parseInt(txtMaxRetries.getText().trim()));
                config.setBatchSize(Integer.parseInt(txtBatchSize.getText().trim()));
                config.setMinBatchSize(Integer.parseInt(txtMinBatchSize.getText().trim()));
                config.setScheduleIntervalMs(Long.parseLong(txtSchedInterval.getText().trim()));

                JOptionPane.showMessageDialog(this, "Configuration updated for " + config.getName(), "Updated", JOptionPane.INFORMATION_MESSAGE);
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Failed to apply configuration: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        fieldsPanel.add(createLabeledField("Arr Mean (it/s):", txtArrMean));
        fieldsPanel.add(createLabeledField("Arr Var:", txtArrVar));
        fieldsPanel.add(createLabeledField("Proc Mean (ms):", txtProcMean));
        fieldsPanel.add(createLabeledField("Proc Var (ms):", txtProcVar));
        fieldsPanel.add(createLabeledField("Fail %:", txtFailProb));
        fieldsPanel.add(createLabeledField("Retry Delay (ms):", txtRetryDelay));

        fieldsPanel.add(createLabeledField("Max Retries (0=unl):", txtMaxRetries));
        fieldsPanel.add(createLabeledField("Max Batch Size:", txtBatchSize));
        fieldsPanel.add(createLabeledField("Min Lock Count:", txtMinBatchSize));
        fieldsPanel.add(createLabeledField("Sched Int (ms):", txtSchedInterval));
        fieldsPanel.add(new JPanel()); // Spacer
        fieldsPanel.add(btnApply);

        row.add(fieldsPanel, BorderLayout.CENTER);
        return row;
    }

    private JPanel createLabeledField(String labelText, JTextField textField) {
        JPanel p = new JPanel(new BorderLayout(2, 2));
        p.setOpaque(false);
        JLabel l = new JLabel(labelText);
        l.setFont(new Font("SansSerif", Font.PLAIN, 10));
        p.add(l, BorderLayout.NORTH);
        p.add(textField, BorderLayout.CENTER);
        return p;
    }

    private JTextField createNumberField(String initialValue) {
        JTextField field = new JTextField(initialValue);
        field.setFont(new Font("SansSerif", Font.PLAIN, 11));
        return field;
    }
}
