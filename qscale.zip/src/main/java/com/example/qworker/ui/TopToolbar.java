package com.example.qworker.ui;

import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import java.awt.*;

public class TopToolbar extends JToolBar {
    private final SimulationEngine engine;
    private final JButton btnStart;
    private final JButton btnPause;
    private final JButton btnReset;
    private final JComboBox<String> speedCombo;
    private final JLabel lblSimTime;
    private final JLabel lblStatus;

    public TopToolbar(SimulationEngine engine) {
        this.engine = engine;
        setFloatable(false);
        setLayout(new FlowLayout(FlowLayout.LEFT, 12, 6));

        btnStart = new JButton("▶ Start");
        btnStart.setFont(btnStart.getFont().deriveFont(Font.BOLD));
        btnStart.setBackground(new Color(40, 167, 69));
        btnStart.setForeground(Color.WHITE);

        btnPause = new JButton("⏸ Pause");
        btnPause.setBackground(new Color(255, 193, 7));
        btnPause.setForeground(Color.BLACK);
        btnPause.setEnabled(false);

        btnReset = new JButton("↺ Reset");
        btnReset.setBackground(new Color(220, 53, 69));
        btnReset.setForeground(Color.WHITE);

        speedCombo = new JComboBox<>(new String[]{"0.5x", "1.0x", "2.0x", "5.0x", "10.0x"});
        speedCombo.setSelectedIndex(1); // Default 1.0x

        lblSimTime = new JLabel("Sim Time: 00:00.000");
        lblSimTime.setFont(new Font(Font.MONOSPACED, Font.BOLD, 14));

        lblStatus = new JLabel("STOPPED");
        lblStatus.setOpaque(true);
        lblStatus.setBackground(Color.LIGHT_GRAY);
        lblStatus.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));

        btnStart.addActionListener(e -> {
            engine.start();
            updateButtonStates();
        });

        btnPause.addActionListener(e -> {
            engine.pause();
            updateButtonStates();
        });

        btnReset.addActionListener(e -> {
            engine.reset();
            engine.initializeDefaultSimulation();
            updateButtonStates();
        });

        speedCombo.addActionListener(e -> {
            String selected = (String) speedCombo.getSelectedItem();
            if (selected != null) {
                double speed = Double.parseDouble(selected.replace("x", ""));
                engine.setSpeedMultiplier(speed);
            }
        });

        add(btnStart);
        add(btnPause);
        add(btnReset);
        add(new JToolBar.Separator());
        add(new JLabel("Speed:"));
        add(speedCombo);
        add(new JToolBar.Separator());
        add(lblSimTime);
        add(new JToolBar.Separator());
        add(lblStatus);
    }

    public void updateState() {
        updateButtonStates();
        long simTimeMs = engine.getCurrentSimTimeMs();
        long minutes = (simTimeMs / 60000);
        long seconds = (simTimeMs % 60000) / 1000;
        long millis = simTimeMs % 1000;
        lblSimTime.setText(String.format("Sim Time: %02d:%02d.%03d", minutes, seconds, millis));
    }

    private void updateButtonStates() {
        boolean isRunning = engine.isRunning();
        btnStart.setEnabled(!isRunning);
        btnPause.setEnabled(isRunning);

        if (isRunning) {
            lblStatus.setText("RUNNING");
            lblStatus.setBackground(new Color(40, 167, 69));
            lblStatus.setForeground(Color.WHITE);
        } else {
            lblStatus.setText("PAUSED");
            lblStatus.setBackground(new Color(255, 193, 7));
            lblStatus.setForeground(Color.BLACK);
        }
    }
}
