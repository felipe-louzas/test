package com.example.qworker.ui;

import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.Map;

public class QueueMetricsPanel extends JPanel {
    private final SimulationEngine engine;
    private final JPanel container;
    private final Map<String, QueueRowComponents> rowMap = new HashMap<>();

    private static class QueueRowComponents {
        JLabel lblBreakdown;
        JLabel lblWorkers;
        JLabel lblOldestAge;
        JLabel lblThroughput;
        JProgressBar backlogBar;
    }

    public QueueMetricsPanel(SimulationEngine engine) {
        this.engine = engine;
        setBorder(BorderFactory.createTitledBorder(BorderFactory.createEtchedBorder(), "Queue Backlogs & Active Workers", TitledBorder.LEFT, TitledBorder.TOP, new Font("SansSerif", Font.BOLD, 13)));
        setLayout(new BorderLayout());

        container = new JPanel();
        container.setLayout(new BoxLayout(container, BoxLayout.Y_AXIS));

        JScrollPane scroll = new JScrollPane(container);
        scroll.setBorder(null);
        add(scroll, BorderLayout.CENTER);

        rebuildRows();
    }

    public void rebuildRows() {
        container.removeAll();
        rowMap.clear();

        for (QueueConfiguration config : engine.getQueueConfigurations()) {
            JPanel row = new JPanel(new BorderLayout(8, 4));
            row.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createMatteBorder(0, 0, 1, 0, new Color(220, 220, 220)),
                    BorderFactory.createEmptyBorder(6, 8, 6, 8)
            ));

            JLabel lblName = new JLabel(config.getName());
            lblName.setFont(new Font("SansSerif", Font.BOLD, 12));
            lblName.setPreferredSize(new Dimension(100, 24));

            QueueRowComponents comps = new QueueRowComponents();
            comps.lblBreakdown = new JLabel("0 unassigned / 0 locked");
            comps.lblBreakdown.setFont(new Font("SansSerif", Font.PLAIN, 11));
            comps.lblBreakdown.setPreferredSize(new Dimension(170, 24));

            comps.lblWorkers = new JLabel("0 workers");
            comps.lblWorkers.setFont(new Font("SansSerif", Font.BOLD, 11));
            comps.lblWorkers.setForeground(new Color(0, 102, 204));
            comps.lblWorkers.setPreferredSize(new Dimension(80, 24));

            comps.lblOldestAge = new JLabel("Age: 0s");
            comps.lblOldestAge.setFont(new Font("SansSerif", Font.PLAIN, 11));
            comps.lblOldestAge.setPreferredSize(new Dimension(80, 24));

            comps.lblThroughput = new JLabel("0.0/s");
            comps.lblThroughput.setFont(new Font("SansSerif", Font.PLAIN, 11));
            comps.lblThroughput.setPreferredSize(new Dimension(60, 24));

            comps.backlogBar = new JProgressBar(0, 200);
            comps.backlogBar.setStringPainted(true);
            comps.backlogBar.setForeground(new Color(51, 153, 255));

            JPanel infoPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            infoPanel.setOpaque(false);
            infoPanel.add(comps.lblBreakdown);
            infoPanel.add(comps.lblWorkers);
            infoPanel.add(comps.lblOldestAge);
            infoPanel.add(comps.lblThroughput);

            row.add(lblName, BorderLayout.WEST);
            row.add(comps.backlogBar, BorderLayout.CENTER);
            row.add(infoPanel, BorderLayout.EAST);

            container.add(row);
            rowMap.put(config.getId(), comps);
        }

        container.revalidate();
        container.repaint();
    }

    public void updateMetrics() {
        long currentSimTimeMs = engine.getCurrentSimTimeMs();

        for (QueueConfiguration config : engine.getQueueConfigurations()) {
            QueueRowComponents comps = rowMap.get(config.getId());
            if (comps == null) continue;

            int unassigned = engine.getRepository().getUnassignedCount(config.getId());
            int locked = engine.getRepository().getProcessingCount(config.getId());
            int total = unassigned + locked;

            int workers = engine.getActiveWorkerCountForQueue(config.getId());
            long oldestAgeMs = engine.getRepository().getOldestItemAgeMs(config.getId(), currentSimTimeMs);
            double tp = engine.getMetricsCollector().getThroughput(config.getId(), currentSimTimeMs);

            comps.lblBreakdown.setText(String.format("%d unassigned | %d locked", unassigned, locked));
            comps.lblWorkers.setText(workers + " workers");
            comps.lblOldestAge.setText(String.format("Age: %.1fs", oldestAgeMs / 1000.0));
            comps.lblThroughput.setText(String.format("%.1f/s", tp));

            comps.backlogBar.setValue(Math.min(200, total));
            comps.backlogBar.setString(String.format("%d total (%d unassigned, %d locked)", total, unassigned, locked));
        }
    }
}
