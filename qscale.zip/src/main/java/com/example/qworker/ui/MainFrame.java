package com.example.qworker.ui;

import com.example.qworker.simulation.SimulationEngine;

import javax.swing.*;
import java.awt.*;

public class MainFrame extends JFrame {
    private final SimulationEngine engine;

    private final TopToolbar topToolbar;
    private final GlobalMetricsPanel globalMetricsPanel;
    private final QueueConfigPanel queueConfigPanel;
    private final QueueMetricsPanel queueMetricsPanel;
    private final PodPanel podPanel;
    private final QueueChartPanel chartPanel;

    private final Timer refreshTimer;

    public MainFrame(SimulationEngine engine) {
        super("Work Queue Autoscaling Simulator");
        this.engine = engine;

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1280, 850);
        setMinimumSize(new Dimension(1024, 720));
        setLocationRelativeTo(null);

        // Instantiate components
        topToolbar = new TopToolbar(engine);
        globalMetricsPanel = new GlobalMetricsPanel(engine);
        queueConfigPanel = new QueueConfigPanel(engine);
        queueMetricsPanel = new QueueMetricsPanel(engine);
        podPanel = new PodPanel(engine);
        chartPanel = new QueueChartPanel(engine);

        // Layout Construction
        setLayout(new BorderLayout());

        add(topToolbar, BorderLayout.NORTH);

        // Left Container: Queue Config (Top) + Queue Backlogs (Bottom)
        JSplitPane leftSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, queueConfigPanel, queueMetricsPanel);
        leftSplit.setResizeWeight(0.55);
        leftSplit.setDividerLocation(300);

        // Center Split: Left (Queues) vs Right (Pods)
        JSplitPane centerSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, leftSplit, podPanel);
        centerSplit.setResizeWeight(0.48);
        centerSplit.setDividerLocation(580);

        // Bottom Split: Center (Queues & Pods) vs Bottom (Chart)
        JSplitPane mainSplit = new JSplitPane(JSplitPane.VERTICAL_SPLIT, centerSplit, chartPanel);
        mainSplit.setResizeWeight(0.70);
        mainSplit.setDividerLocation(520);

        // Main Center Panel with Global Dashboard on top
        JPanel centerPanel = new JPanel(new BorderLayout(6, 6));
        centerPanel.setBorder(BorderFactory.createEmptyBorder(6, 6, 6, 6));
        centerPanel.add(globalMetricsPanel, BorderLayout.NORTH);
        centerPanel.add(mainSplit, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);

        // Refresh Timer (~30 FPS UI Update)
        refreshTimer = new Timer(33, e -> updateUIComponents());
        refreshTimer.start();
    }

    private void updateUIComponents() {
        topToolbar.updateState();
        globalMetricsPanel.updateMetrics();
        queueMetricsPanel.updateMetrics();
        podPanel.updatePods();
        chartPanel.repaint();
    }

    @Override
    public void dispose() {
        if (refreshTimer != null) {
            refreshTimer.stop();
        }
        engine.pause();
        super.dispose();
    }
}
