package com.example.qworker.repository;

import com.example.qworker.model.QueueConfiguration;
import com.example.qworker.model.WorkItem;
import com.example.qworker.model.WorkItemStatus;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicLong;

public class WorkQueueRepository {
    private final Map<Long, WorkItem> items = new ConcurrentHashMap<>();
    private final AtomicLong idGenerator = new AtomicLong(1);

    public synchronized void clear() {
        items.clear();
        idGenerator.set(1);
    }

    public synchronized void addWorkItems(String queueId, int count, long currentTimeMs) {
        long initialLastUpdateMs = (currentTimeMs == 0) ? -1 : (currentTimeMs - 1);
        for (int i = 0; i < count; i++) {
            long id = idGenerator.getAndIncrement();
            WorkItem item = new WorkItem(id, queueId, currentTimeMs);
            item.setLastUpdate(initialLastUpdateMs);
            items.put(id, item);
        }
    }

    /**
     * Simulates SELECT ... WHERE queue_id = ? AND last_update < executionStart
     * AND available_for_processing = true FOR UPDATE SKIP LOCKED LIMIT batchSize
     */
    public synchronized List<WorkItem> claimBatch(String queueId, long executionStartMs, int batchSize,
                                                  long currentTimeMs, long retryDelayMs, String workerId) {
        List<WorkItem> claimed = new ArrayList<>();
        if (batchSize <= 0) {
            return claimed;
        }

        List<WorkItem> candidates = new ArrayList<>();
        for (WorkItem item : items.values()) {
            if (!item.getQueueId().equals(queueId)) {
                continue;
            }
            // SKIP LOCKED: Must be PENDING (not locked / processing)
            if (item.getStatus() != WorkItemStatus.PENDING) {
                continue;
            }
            // item.lastUpdate < executionStart (per spec)
            if (item.getLastUpdate() >= executionStartMs) {
                continue;
            }
            // If item failed previously (retryCount > 0), check retry delay:
            // available only after retryDelay has elapsed since lastUpdate
            if (item.getRetryCount() > 0) {
                if (currentTimeMs < item.getLastUpdate() + retryDelayMs) {
                    continue;
                }
            }
            candidates.add(item);
        }

        // Sort candidates by creation time / id for FIFO ordering
        candidates.sort(Comparator.comparingLong(WorkItem::getCreatedAt).thenComparingLong(WorkItem::getId));

        for (WorkItem item : candidates) {
            if (claimed.size() >= batchSize) {
                break;
            }
            item.setStatus(WorkItemStatus.PROCESSING);
            item.setLockedByWorkerId(workerId);
            claimed.add(item);
        }

        return claimed;
    }

    public synchronized void completeItemSuccess(long itemId) {
        items.remove(itemId);
    }

    /**
     * @return true if permanently failed (exceeded maxRetries), false if updated for retry
     */
    public synchronized boolean completeItemFailure(long itemId, long currentTimeMs, QueueConfiguration config) {
        WorkItem item = items.get(itemId);
        if (item == null) {
            return false;
        }
        item.incrementRetryCount();
        item.setLastUpdate(currentTimeMs);
        item.setLockedByWorkerId(null);

        int maxRetries = config.getMaxRetries(); // 0 = unlimited retries
        if (maxRetries > 0 && item.getRetryCount() >= maxRetries) {
            items.remove(itemId);
            return true;
        } else {
            item.setStatus(WorkItemStatus.PENDING);
            return false;
        }
    }

    public synchronized int getPendingCount(String queueId) {
        return getUnassignedCount(queueId);
    }

    public synchronized int getUnassignedCount(String queueId) {
        int count = 0;
        for (WorkItem item : items.values()) {
            if (item.getQueueId().equals(queueId) && item.getStatus() == WorkItemStatus.PENDING) {
                count++;
            }
        }
        return count;
    }

    public synchronized int getProcessingCount(String queueId) {
        int count = 0;
        for (WorkItem item : items.values()) {
            if (item.getQueueId().equals(queueId) && item.getStatus() == WorkItemStatus.PROCESSING) {
                count++;
            }
        }
        return count;
    }

    public synchronized int getTotalPendingCount() {
        return items.size();
    }

    public synchronized int getTotalItemsCount(String queueId) {
        int count = 0;
        for (WorkItem item : items.values()) {
            if (item.getQueueId().equals(queueId)) {
                count++;
            }
        }
        return count;
    }

    public synchronized int getTotalItemsCount() {
        return items.size();
    }

    public synchronized long getOldestItemAgeMs(String queueId, long currentSimTimeMs) {
        long oldestAge = 0;
        for (WorkItem item : items.values()) {
            if (item.getQueueId().equals(queueId) && item.getStatus() == WorkItemStatus.PENDING) {
                long age = currentSimTimeMs - item.getCreatedAt();
                if (age > oldestAge) {
                    oldestAge = age;
                }
            }
        }
        return Math.max(0, oldestAge);
    }

    public synchronized long getOldestItemAgeOverallMs(long currentSimTimeMs) {
        long oldestAge = 0;
        for (WorkItem item : items.values()) {
            if (item.getStatus() == WorkItemStatus.PENDING) {
                long age = currentSimTimeMs - item.getCreatedAt();
                if (age > oldestAge) {
                    oldestAge = age;
                }
            }
        }
        return Math.max(0, oldestAge);
    }
}
