package com.example.common.report.engine

import com.example.common.report.api.ReportTemplate
import com.example.common.report.api.core.ReportEngineOptions
import com.example.common.report.api.core.RowMapper
import com.example.common.report.api.layout.*
import com.example.common.report.api.measure.Measure
import com.example.common.report.api.section.*
import com.example.common.report.api.style.CellStyle
import com.example.common.report.api.style.ColorValue
import com.example.common.report.api.style.StandardFonts
import com.example.common.report.api.style.format.DateTimeFormat
import com.example.common.report.api.style.format.NumericFormat
import com.example.common.report.api.style.format.TextFormat
import com.example.common.report.api.table.ColumnDefinition
import com.example.common.report.api.table.TableDefinition
import com.example.common.report.format.pdf.PdfReportBuilder
import com.example.common.report.format.pdf.PdfReportOptions
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfReader
import com.itextpdf.kernel.pdf.canvas.parser.PdfTextExtractor
import org.springframework.core.io.DefaultResourceLoader
import spock.lang.Specification

import java.math.RoundingMode
import java.nio.file.Files
import java.nio.file.Path
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

class PdfReportEngineSpec extends Specification {

    def "generates a pdf report with a complex template"() {
        given:
        Path pdfPath = Files.createTempFile("pdf-report-engine", ".pdf")
        def engine = pdfReportEngine()
        def template = complexTemplate()
        def options = PdfReportOptions.builder()
                .includeHeader(true)
                .defaultFont(StandardFonts.SERIF)
                .defaultFontSize(11.5f)
                .build()
        def writer = engine.buildReport(template, options)
        def data = buildData(500)

        when:
        Files.newOutputStream(pdfPath).withCloseable { output ->
            writer.write(data, mapRowMapper(), output)
        }

        then:
        noExceptionThrown()
        Files.size(pdfPath) > 0

        and:
        validatePdf(pdfPath)

        cleanup:
        Files.deleteIfExists(pdfPath)
    }

    private static ReportEngine pdfReportEngine() {
        def builder = new PdfReportBuilder(new DefaultResourceLoader())
        new ReportEngine([builder], new ReportEngineOptions(new Locale("pt", "BR"), ZoneId.of("America/Sao_Paulo")))
    }

    private static ReportTemplate complexTemplate() {
        def table = TableDefinition.builder()
                .columns(buildColumns())
                .headerStyle(headerStyle())
                .rowStyle(rowStyle())
                .altRowStyle(altRowStyle())
                .build()

        ReportTemplate.builder()
                .id("pdf-spec-template")
                .page(customPageDefinition())
                .table(table)
                .pageHeader(buildSection("Page Header", PageRenderPolicy.FIRST_PAGE))
                .pageFooter(buildSection("Page Footer", PageRenderPolicy.LAST_PAGE))
                .contentHeader(buildSection("Content Header", PageRenderPolicy.FIRST_PAGE))
                .contentFooter(buildSection("Content Footer", PageRenderPolicy.LAST_PAGE))
                .build()
    }

    private static PageDefinition customPageDefinition() {
        PageDefinition.builder()
                .size(PageSizes.LETTER.landscape())
                .margins(PageMargins.builder()
                        .top(Measure.mm(12))
                        .bottom(Measure.mm(12))
                        .left(Measure.mm(15))
                        .right(Measure.mm(15))
                        .build())
                .build()
    }

    private static List<ColumnDefinition> buildColumns() {
        [
                column("orderId", "Order #", 7),
                column("customerName", "Customer", 10),
                column("region", "Region", 5),
                column("country", "Country", 6),
                column("segment", "Segment", 8),
                column("orderedOn", "Ordered On", 14, DateTimeFormat.localizedDateTime(), dateStyle()),
                column("deliveryDate", "Delivery Date", 10, DateTimeFormat.isoDate(), dateStyle()),
                column("quantity", "Qty", 4, integerFormat(), numericStyle()),
                column("unitPrice", "Unit Price", 6, currencyFormat(), numericStyle()),
                column("discount", "Discount", 6, percentageFormat(), numericStyle()),
                column("total", "Total", 8, currencyFormat(), boldNumericStyle())
        ]
    }

    private static ColumnDefinition column(String key, String header, int width, TextFormat format = null, CellStyle style = null) {
        ColumnDefinition.builder()
                .key(key)
                .header(header)
                .width(width)
                .cellStyle(style)
                .format(format)
                .build()
    }

    private static NumericFormat integerFormat() {
        NumericFormat.builder()
                .minFractionDigits(0)
                .maxFractionDigits(0)
                .groupDigits(true)
                .build()
    }

    private static NumericFormat currencyFormat() {
        NumericFormat.builder()
                .prefix("USD ")
                .minFractionDigits(2)
                .maxFractionDigits(2)
                .groupDigits(true)
                .build()
    }

    private static NumericFormat percentageFormat() {
        NumericFormat.builder()
                .suffix(" %")
                .minFractionDigits(2)
                .maxFractionDigits(2)
                .groupDigits(false)
                .build()
    }

    private static CellStyle headerStyle() {
        CellStyle.builder()
                .font(StandardFonts.SANS_SERIF)
                .fontSize(9.0f)
                .bold(true)
                .textColor(ColorValue.rgb(255, 255, 255))
                .backgroundColor(ColorValue.rgb(32, 64, 128))
                .horizontalAlignment(HorizontalAlignment.CENTER)
                .verticalAlignment(VerticalAlignment.BOTTOM)
                .build()
    }

    private static CellStyle rowStyle() {
        CellStyle.builder()
                .font(StandardFonts.SANS_SERIF)
                .fontSize(9.0f)
                .textColor(ColorValue.rgb(30, 30, 30))
                .horizontalAlignment(HorizontalAlignment.LEFT)
                .verticalAlignment(VerticalAlignment.CENTER)
                .build()
    }

    private static CellStyle altRowStyle() {
        CellStyle.builder()
                .backgroundColor(ColorValue.rgb(240, 245, 255))
                .build()
    }

    private static CellStyle sectionStyle() {
        CellStyle.builder()
                .font(StandardFonts.SERIF)
                .fontSize(9.0f)
                .italic(true)
                .textColor(ColorValue.rgb(60, 60, 60))
                .verticalAlignment(VerticalAlignment.CENTER)
                .border(true)
                .build()
    }

    private static CellStyle dateStyle() {
        CellStyle.builder()
                .horizontalAlignment(HorizontalAlignment.CENTER)
                .build()
    }

    private static CellStyle numericStyle() {
        CellStyle.builder()
                .horizontalAlignment(HorizontalAlignment.RIGHT)
                .build()
    }

    private static CellStyle boldNumericStyle() {
        CellStyle.builder()
                .bold(true)
                .textColor(ColorValue.rgb(255, 0, 0))
                .horizontalAlignment(HorizontalAlignment.RIGHT)
                .verticalAlignment(VerticalAlignment.CENTER)
                .build()
    }

    private static Section buildSection(String label, PageRenderPolicy secondaryPolicy = PageRenderPolicy.ALL_PAGES) {
        List<SectionRow> rows = [
                sectionRow("${label} All pages", PageRenderPolicy.ALL_PAGES),
                sectionRow("${label} Even pages", PageRenderPolicy.EVEN_PAGES),
                sectionRow("${label} Odd pages", PageRenderPolicy.ODD_PAGES),
                sectionRow("${label} First and last", secondaryPolicy)
        ]
        new Section(rows)
    }

    private static SectionRow sectionRow(String label, PageRenderPolicy renderPolicy) {
        SectionRow.builder()
                .height(Measure.mm(12))
                .pageRenderPolicy(renderPolicy)
                .content(sectionContent(label))
                .build()
    }

    private static Map<SectionSlot, SectionSlotDefinition> sectionContent(String label) {
        def content = new EnumMap<SectionSlot, SectionSlotDefinition>(SectionSlot)
        content.put(SectionSlot.LEFT, SectionSlotDefinition.builder()
                .style(sectionStyle())
                .components([
                        new SectionComponent.StaticTextContent(label, null),
                        new SectionComponent.StaticTextContent("Generated: ${LocalDate.now()}", null)
                ])
                .build())
        content.put(SectionSlot.CENTER, SectionSlotDefinition.builder()
                .style(sectionStyle())
                .components(List.of(
                        new SectionComponent.StaticTextContent("Quarterly Summary", null),
                        new SectionComponent.StaticTextContent("Page %s", null)
                ))
                .build())
        content.put(SectionSlot.RIGHT, SectionSlotDefinition.builder()
                .style(sectionStyle())
                .components([
                        new SectionComponent.StaticTextContent("Status: FINAL", null),
                        new SectionComponent.StaticTextContent("Version 1.0", null)
                ])
                .build())
        content
    }

    private static List<Map<String, Object>> buildData(int count) {
        (1..count).collect(({ Integer idx ->
            int quantity = 5 + (idx % 15)
            BigDecimal unitPrice = BigDecimal.valueOf(12.5 + (idx % 20) * 1.75).setScale(2, RoundingMode.HALF_UP)
            BigDecimal discount = BigDecimal.valueOf((idx % 10) * 0.005).setScale(4, RoundingMode.HALF_UP)
            BigDecimal gross = unitPrice * BigDecimal.valueOf(quantity)
            BigDecimal net = (gross * BigDecimal.ONE.subtract(discount)).setScale(2, RoundingMode.HALF_UP)
            [
                    orderId     : String.format(Locale.US, "PO-%04d", idx),
                    customerName: "First Last ${idx}",
                    region      : idx % 2 == 0 ? "North" : "South",
                    country     : idx % 3 == 0 ? "USA" : "Brazil",
                    segment     : ["Enterprise", "SMB", "Public"][idx % 3],
                    orderedOn   : Instant.now().plusSeconds(idx * 10),
                    deliveryDate: LocalDate.of(2024, 1, 10).plusDays(idx),
                    quantity    : quantity,
                    unitPrice   : unitPrice,
                    discount    : discount.movePointRight(2), // Convert to percentage for display
                    total       : net
            ]
        } as Closure<Map<String, Object>>))
    }

    private static RowMapper<Map<String, Object>> mapRowMapper() {
        { row, columnKey -> row[columnKey] } as RowMapper<Map<String, Object>>
    }

    private static boolean validatePdf(Path pdfPath) {
        // Opening the file with iText ensures the bytes form a readable PDF document
        new PdfReader(pdfPath.toFile()).withCloseable { reader ->
            new PdfDocument(reader).withCloseable { pdf ->
                // Basic structural validation
                int pages = pdf.getNumberOfPages()
                assert pages > 0

                int evenPages = (pages / 2).intValue()
                int oddPages = pages - evenPages

                // Page size & orientation validation
                pdf.getPage(1).with { page ->
                    def size = page.getPageSize()
                    assert size.getWidth() > size.getHeight() // landscape
                }

                // Extract all text once (cheap & useful)
                String fullText = (1..pages)
                        .collect { pageNum -> PdfTextExtractor.getTextFromPage(pdf.getPage(pageNum)) }
                        .join("\n")

                // Section presence validation
                assert fullText.count("Page Header All pages") == pages
                assert fullText.count("Page Footer All pages") == pages
                assert fullText.count("Content Header All pages") == pages
                assert fullText.count("Content Footer All pages") == pages
                assert fullText.count("Quarterly Summary") == pages * 8 + 4 // 8 sections per page + 4 on first/last page
                assert fullText.count("Status: FINAL") == pages * 8 + 4

                // Even/odd page section validation
                assert fullText.count("Page Header Odd pages") == oddPages
                assert fullText.count("Page Footer Odd pages") == oddPages
                assert fullText.count("Content Header Odd pages") == oddPages
                assert fullText.count("Content Footer Odd pages") == oddPages
                assert fullText.count("Page Header Even pages") == evenPages
                assert fullText.count("Page Footer Even pages") == evenPages
                assert fullText.count("Content Header Even pages") == evenPages
                assert fullText.count("Content Footer Even pages") == evenPages

                // First/last page section validation
                assert fullText.count("Page Header First and last") == 1
                assert fullText.count("Page Footer First and last") == 1
                assert fullText.count("Content Header First and last") == 1
                assert fullText.count("Content Footer First and last") == 1

                // Page number token resolution
                // TODO: Add page numbers
                //assert fullText.contains("Page 1")
                //assert fullText.contains("Page ${pages}")

                // Column headers repeat on each page (except last)
                [
                        "Order #",
                        "Customer",
                        "Region",
                        "Country",
                        "Segment",
                        "Ordered On",
                        "Delivery Date",
                        "Qty",
                        "Unit Price",
                        "Discount",
                        "Total"
                ].each { header ->
                    assert fullText.count(header) == pages - 1 // not on last page
                }

                // Data presence sanity checks
                assert fullText.contains("PO-0001")
                assert fullText.contains("PO-0500")
                assert fullText.contains("First Last 1")
                assert fullText.contains("First Last 500")

                return true
            }
        }
    }
}
