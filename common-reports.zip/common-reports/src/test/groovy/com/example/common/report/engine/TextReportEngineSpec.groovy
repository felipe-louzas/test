package com.example.common.report.engine

import com.example.common.report.api.ReportTemplate
import com.example.common.report.api.core.ReportEngineOptions
import com.example.common.report.api.core.RowMapper
import com.example.common.report.api.exception.ReportException
import com.example.common.report.api.style.format.DateTimeFormat
import com.example.common.report.api.style.format.NegativeNumberStyle
import com.example.common.report.api.style.format.NumericFormat
import com.example.common.report.api.style.format.TextFormat
import com.example.common.report.api.table.ColumnDefinition
import com.example.common.report.api.table.TableDefinition
import com.example.common.report.format.ReportFormats
import com.example.common.report.format.text.TextReportBuilder
import com.example.common.report.format.text.TextReportOptions
import com.univocity.parsers.csv.CsvParser
import com.univocity.parsers.csv.CsvParserSettings
import org.apache.commons.lang3.exception.ExceptionUtils
import spock.lang.Specification

import java.nio.charset.Charset
import java.nio.charset.StandardCharsets
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.FormatStyle
import java.time.temporal.TemporalAccessor
import java.time.temporal.TemporalField
import java.util.stream.Stream

class TextReportEngineSpec extends Specification {

    private static ReportEngine reportEngine() {
        new ReportEngine([new TextReportBuilder()], new ReportEngineOptions(Locale.US, ZoneId.of("UTC")))
    }

    private static ReportEngine reportEngine(ReportEngineOptions engineOptions) {
        new ReportEngine([new TextReportBuilder()], engineOptions)
    }

    private static ReportTemplate templateWithColumns(List<ColumnDefinition> columns) {
        ReportTemplate.builder()
                .id("text-template")
                .table(TableDefinition.builder().columns(columns).build())
                .build()
    }

    private static ColumnDefinition column(String key, String header, TextFormat format = null) {
        ColumnDefinition.builder()
                .key(key)
                .header(header)
                .width(10)
                .format(format)
                .build()
    }

    private static RowMapper<Map<String, Object>> mapRowMapper() {
        return (row, columnKey) -> row.get(columnKey)
    }

    private static String writeReport(ReportEngine engine,
                                      ReportTemplate template,
                                      TextReportOptions reportOptions,
                                      List<Map<String, Object>> data) {
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()
        writer.write(data.stream(), mapRowMapper(), outputStream)
        return outputStream.toString(reportOptions.charset() ?: StandardCharsets.UTF_8)
    }

    def "template.build() validates template table and columns"() {
        when:
        template.build()

        then:
        def ex = thrown(IllegalArgumentException)
        ex.message.contains(expectedMessage)

        where:
        template << [
                ReportTemplate.builder()
                        .id("missing-table")
                        .table(null),
                ReportTemplate.builder()
                        .id("empty-table")
                        .table(TableDefinition.builder()
                                .columns([])
                                .build())
        ]
        expectedMessage << [
                "Nenhuma configuração de tabela definida no template",
                "Nenhuma coluna definida na configuração de tabela do template"
        ]
    }

    def "writes header and rows using default text reportOptions"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name"),
                column("city", "City")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def writer = engine.buildReport(template, reportOptions)
        def data = [
                [name: "Ana", city: "Porto"],
                [name: "Bob", city: "Braga"]
        ]
        def outputStream = new ByteArrayOutputStream()

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        outputStream.toString(StandardCharsets.UTF_8) == "Name,City\nAna,Porto\nBob,Braga\n"
    }

    def "respects includeHeader option"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name"),
                column("city", "City")
        ])
        def reportOptions = TextReportOptions.builder()
                .includeHeader(false)
                .lineSeparator("\n")
                .build()
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()
        def data = [[name: "Ana", city: "Porto"]]

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        outputStream.toString(StandardCharsets.UTF_8) == "Ana,Porto\n"
    }

    def "applies custom delimiter, quote, escape, and line separator"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name"),
                column("note", "Note")
        ])
        def reportOptions = TextReportOptions.builder()
                .delimiter('|' as char)
                .quote('"' as char)
                .escape('\\' as char)
                .lineSeparator("\n")
                .build()
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()
        def data = [[name: "a|b", note: "He said \"hi\""]]

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        def parserSettings = new CsvParserSettings()
        parserSettings.getFormat().setDelimiter('|')
        parserSettings.getFormat().setQuote('"' as char)
        parserSettings.getFormat().setQuoteEscape('\\' as char)
        parserSettings.getFormat().setLineSeparator("\n")
        def parser = new CsvParser(parserSettings)
        def rows = parser.parseAll(new StringReader(outputStream.toString(StandardCharsets.UTF_8)))
        rows == [
                ["Name", "Note"].toArray(String[]::new),
                ["a|b", "He said \"hi\""].toArray(String[]::new)
        ]
    }

    def "formats numbers and dates using column styles"() {
        given:
        def engine = reportEngine()
        def numberFormat = NumericFormat.builder()
                .prefix("USD ")
                .negativeStyle(NegativeNumberStyle.PARENTHESES)
                .minFractionDigits(2)
                .maxFractionDigits(2)
                .groupDigits(true)
                .build()
        def dateFormat = DateTimeFormat.isoDate()
        def template = templateWithColumns([
                column("amount", "Amount", numberFormat),
                column("date", "Date", dateFormat)
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()
        def data = [[amount: -1234.5, date: LocalDate.of(2024, 1, 2)]]

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        outputStream.toString(StandardCharsets.UTF_8) == "Amount,Date\n\"USD (1,234.50)\",2024-01-02\n"
    }

    def "writes output using configured charset"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("label", "Label")
        ])
        def charset = Charset.forName("ISO-8859-1")
        def reportOptions = TextReportOptions.builder()
                .charset(charset)
                .includeHeader(false)
                .lineSeparator("\n")
                .build()
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()
        def data = [[label: "caf\u00E9"]]

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        def bytes = outputStream.toByteArray()
        bytes.length == 5
        bytes[3] == (byte) 0xE9
        new String(bytes, charset) == "caf\u00E9\n"
    }

    def "writes only header when data stream is empty"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name"),
                column("city", "City")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()

        when:
        def output = writeReport(engine, template, reportOptions, [])

        then:
        output == "Name,City\n"
    }

    def "renders null values as empty strings"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name"),
                column("amount", "Amount", NumericFormat.builder().minFractionDigits(2).build())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[name: null, amount: null]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "Name,Amount\n,\n"
    }

    def "non numeric values are passed through for numeric formats"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("amount", "Amount", NumericFormat.builder().minFractionDigits(2).build())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[amount: "N/A"]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "Amount\nN/A\n"
    }

    def "localized formatting uses locale-specific separators"() {
        given:
        def engineOptions = new ReportEngineOptions(locale, ZoneId.of("UTC"))
        def engine = reportEngine(engineOptions)
        def numberFormat = NumericFormat.builder()
                .prefix("CUR ")
                .minFractionDigits(2)
                .maxFractionDigits(2)
                .groupDigits(true)
                .build()
        def dateFormat = DateTimeFormat.localizedDate(FormatStyle.SHORT)
        def template = templateWithColumns([
                column("amount", "Amount", numberFormat),
                column("date", "Date", dateFormat)
        ])
        def reportOptions = TextReportOptions.builder()
                .delimiter(';' as char)
                .lineSeparator("\n")
                .build()
        def data = [[amount: 12345678.909234, date: LocalDate.of(2024, 1, 2)]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "Amount;Date\n${expectedAmount};${expectedDate}\n"

        where:
        locale                     | expectedAmount      | expectedDate
        Locale.US                  | "CUR 12,345,678.91" | "1/2/24"
        Locale.GERMANY             | "CUR 12.345.678,91" | "02.01.24"
        Locale.TRADITIONAL_CHINESE | "CUR 12,345,678.91" | "2024/1/2"
        // new Locale("hi", "IN")     | "CUR 1,23,45,678.91" | "2/1/24" // Known will not fix limitation - https://bugs.openjdk.org/browse/JDK-4738167
        new Locale("pt", "BR")     | "CUR 12.345.678,91" | "02/01/2024"
    }

    def "custom line separator is preserved"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\r\n").build()
        def data = [[name: "Ana"], [name: "Bob"]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "Name\r\nAna\r\nBob\r\n"
    }

    def "buildReport with format uses default text reportOptions"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("name", "Name")
        ])
        def writer = engine.buildReport(template, ReportFormats.TEXT)
        def outputStream = new ByteArrayOutputStream()
        def data = [[name: "Ana"], [name: "Bob"], [name: "Charley"]]

        when:
        writer.write(data.stream(), mapRowMapper(), outputStream)

        then:
        outputStream.toString(StandardCharsets.UTF_8) == "Name\r\nAna\r\nBob\r\nCharley\r\n"
    }

    def "duplicate column keys produce duplicated values"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("value", "A"),
                column("value", "B")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[value: "X"]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "A,B\nX,X\n"
    }

    def "null column header defaults to key"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("a", null),
                column("b", "B"),
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[a: 1, b: 2]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "a,B\n1,2\n"
    }

    def "null column key throws NullPointerException"() {
        when:
        def template = templateWithColumns([
                column("a", "A"),
                column(null, "B"),
        ])

        then:
        def ex = thrown(NullPointerException)
        ex.message.contains("key")
    }


    def "row mapper returning unexpected object types does not crash formatter"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("amount", "Amount", NumericFormat.builder().minFractionDigits(2).build())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def writer = engine.buildReport(template, reportOptions)
        def outputStream = new ByteArrayOutputStream()

        when:
        writer.write(
                Stream.of([amount: new Object()]),
                (row, key) -> row[key],
                outputStream
        )

        then:
        outputStream.toString(StandardCharsets.UTF_8)
                .startsWith("Amount\njava.lang.Object@")
    }

    def "missing keys in data rows render as empty cells"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("a", "A"),
                column("b", "B")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[a: 1]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "A,B\n1,\n"
    }

    def "cell containing delimiter quote newline and escape is correctly escaped"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("label", "Label"),
                column("text", "Text")
        ])
        def reportOptions = TextReportOptions.builder()
                .delimiter(',' as char)
                .quote('"' as char)
                .lineSeparator("\n")
                .build()
        def data = [[label: "case 1", text: 'a,b"c"\nd'], [label: "case 2", text: 'a,b"c\nd']]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == 'Label,Text\ncase 1,"a,b""c""\nd"\ncase 2,"a,b""c\nd"\n'
    }

    def "header values containing delimiter or quotes are escaped"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("a", 'A,B'),
                column("b", '"C.D"'),
                column("c", 'E\nF')
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[a: 1, b: 2, c: 3], [a: 4, b: 5, c: 6]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == '"A,B","""C.D""","E\nF"\n1,2,3\n4,5,6\n'
    }

    def "formats extremely large numbers without scientific notation"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("n", "N", NumericFormat.builder().groupDigits(true).build())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [[n: new BigDecimal("999999999999999999999")]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output.contains("999,999,999,999,999,999,999")
    }

    def "NaN and Infinity values are rendered safely"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("n", "N", NumericFormat.builder().build())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def data = [
                [n: Double.NaN],
                [n: Double.POSITIVE_INFINITY],
                [n: Double.NEGATIVE_INFINITY]
        ]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output == "N\nNaN\n∞\n-∞\n"
    }

    def "unsupported temporal types fall back to toString"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("t", "T", DateTimeFormat.isoDate())
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def customTemporal = new TemporalAccessor() {
            @Override
            boolean isSupported(TemporalField field) {
                return false
            }

            @Override
            long getLong(TemporalField field) {
                return 0
            }

            @Override
            String toString() {
                return "2024-01-01T00:00:00Z"
            }
        }
        def data = [[t: customTemporal]]

        when:
        def output = writeReport(engine, template, reportOptions, data)

        then:
        output.contains("2024-01-01T00:00:00Z")
    }

    def "exception during stream iteration propagates cleanly"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("a", "A")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def writer = engine.buildReport(template, reportOptions)

        def stream = Stream.generate({
            throw new RuntimeException("boom")
        }).limit(1)

        when:
        writer.write(stream, mapRowMapper(), new ByteArrayOutputStream())

        then:
        def ex = thrown(ReportException)
        ex.getCause().message == "boom"
    }

    def "partial output stream failure propagates exception"() {
        given:
        def engine = reportEngine()
        def template = templateWithColumns([
                column("a", "A")
        ])
        def reportOptions = TextReportOptions.builder().lineSeparator("\n").build()
        def writer = engine.buildReport(template, reportOptions)
        def data = [[a: Instant.parse("2024-01-01T00:00:00Z")]]
        def failingStream = new OutputStream() {
            @Override
            void write(int b) {
                throw new IOException("write failed")
            }
        }

        when:
        writer.write(data.stream(), mapRowMapper(), failingStream)

        then:
        def ex = thrown(ReportException)
        ExceptionUtils.getRootCause(ex).message == "write failed"
    }
}
