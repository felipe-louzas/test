package com.example.common.report.format.pdf.writer;

import com.example.common.report.format.pdf.section.PdfSection;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEvent;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEventHandler;
import com.itextpdf.kernel.pdf.event.PdfDocumentEvent;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@NullMarked
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
final class PdfPageEventHandler extends AbstractPdfDocumentEventHandler {

	PdfWriterContext context;

	PdfPageEventHandler(PdfWriterContext context) {
		this.context = context;
		addType(PdfDocumentEvent.START_PAGE);
		addType(PdfDocumentEvent.END_PAGE);
	}

	@Override
	protected void onAcceptedEvent(AbstractPdfDocumentEvent event) {
		if (!(event instanceof PdfDocumentEvent pdfEvent))
			return;

		val document = pdfEvent.getDocument();
		val page = pdfEvent.getPage();

		switch (event.getType()) {
			case PdfDocumentEvent.START_PAGE -> onStartPage(document, page);
			case PdfDocumentEvent.END_PAGE -> onEndPage(document, page);
		}
	}

	private void onStartPage(PdfDocument document, PdfPage page) {
		setMargins(document.getPageNumber(page));
	}

	private void onEndPage(PdfDocument document, PdfPage page) {
		val pageNumber = document.getPageNumber(page);
		val sections = context.getCompiledReport().sections();

		renderSection(sections.pageHeader(), pageNumber);
		renderSection(sections.pageFooter(), pageNumber);
		renderSection(sections.contentHeader(), pageNumber);
		renderSection(sections.contentFooter(), pageNumber);
	}

	private void setMargins(int pageNumber) {
		val document = context.getDocument();
		val metrics = context.getCompiledReport().pageMetrics();

		// At the start of the page we can only assume that it's not the last page
		val headerHeight = metrics.getHeaderHeight(pageNumber, false);
		val footerHeight = metrics.getFooterHeight(pageNumber, false);

		document.setMargins( // top, right, bottom, left
			metrics.marginTop() + headerHeight,
			metrics.marginRight(),
			metrics.marginBottom() + footerHeight,
			metrics.marginLeft()
		);
	}

	private void renderSection(@Nullable PdfSection pdfSection, int pageNumber) {
		if (pdfSection == null)
			return;
		pdfSection.render(context, pageNumber);
	}
}