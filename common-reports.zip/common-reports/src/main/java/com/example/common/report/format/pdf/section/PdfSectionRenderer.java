package com.example.common.report.format.pdf.section;

import com.example.common.report.format.pdf.writer.PdfWriterContext;

@FunctionalInterface
interface PdfSectionRenderer {
	PdfSectionRenderer EMPTY = (context, pageNumber) -> {};

	void render(PdfWriterContext context, int pageNumber);
}
