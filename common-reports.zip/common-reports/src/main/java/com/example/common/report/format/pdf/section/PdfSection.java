package com.example.common.report.format.pdf.section;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.common.report.api.section.PageRenderPolicy;
import com.example.common.report.api.section.PageRenderPolicyMask;
import com.example.common.report.format.pdf.writer.PdfPageMetrics;
import com.example.common.report.format.pdf.writer.PdfWriterContext;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.val;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfSection {
	Map<PageRenderPolicyMask, PdfSectionRenderer> renderers;

	public PdfSection(
		PdfSectionType type,
		List<PdfSectionRow> rows,
		PdfPageMetrics metrics
	) {
		this.renderers = PageRenderPolicyMask.ALL_MASKS.stream()
			.collect(Collectors.toMap(
				Function.identity(),
				mask -> buildRenderer(mask, type, metrics, rows)
			));
	}

	public void render(PdfWriterContext context, int pageNumber) {
		val policyMask = PageRenderPolicyMask.forPageNumber(pageNumber, context.isLastPage(pageNumber));
		val renderer = renderers.get(policyMask);
		if (renderer != null) {
			renderer.render(context, pageNumber);
		}
	}

	private PdfSectionRenderer buildRenderer(PageRenderPolicyMask mask, PdfSectionType type, PdfPageMetrics metrics, List<PdfSectionRow> rows) {
		final List<PdfSectionRow> rowsToRender = rows.stream()
			.filter(row -> mask.contains(row.getPageRenderPolicy()))
			.toList();

		if (rowsToRender.isEmpty())
			return PdfSectionRenderer.EMPTY;

		if (type == PdfSectionType.CONTENT_FOOTER && mask.contains(PageRenderPolicy.LAST_PAGE))
			return buildLastPageContentFooterRenderer(metrics, rowsToRender);

		val x = metrics.marginLeft();
		val width = metrics.contentWidth();
		val startY = computeStartY(mask, type, metrics);

		return (ctx, pageNumber) -> {
			float y = startY;
			for (PdfSectionRow row : rowsToRender) {
				float h = row.getHeight();
				row.render(ctx, pageNumber, x, y, width);
				y -= h;
			}
		};
	}

	private PdfSectionRenderer buildLastPageContentFooterRenderer(PdfPageMetrics metrics, List<PdfSectionRow> rowsToRender) {
		val x = metrics.marginLeft();
		val width = metrics.contentWidth();

		return (ctx, pageNumber) -> {
			val contentArea = ctx.getDocument()
				.getRenderer()
				.getCurrentArea()
				.getBBox();

			float y = contentArea.getY() + contentArea.getHeight();
			for (PdfSectionRow row : rowsToRender) {
				val h = row.getHeight();
				row.render(ctx, pageNumber, x, y, width);
				y -= h;
			}
		};
	}

	private float computeStartY(PageRenderPolicyMask mask, PdfSectionType type, PdfPageMetrics metrics) {
		val sectionMetrics = metrics.getSectionMetrics(mask);
		if (sectionMetrics == null)
			return 0f;

		val contentTop = metrics.pageHeight() - metrics.marginTop();
		val contentBottom = metrics.marginBottom();

		return switch (type) {
			case PAGE_HEADER -> contentTop;
			case CONTENT_HEADER -> contentTop - sectionMetrics.pageHeaderHeight();
			case CONTENT_FOOTER -> contentBottom + sectionMetrics.footerHeight();
			case PAGE_FOOTER -> contentBottom + sectionMetrics.pageFooterHeight();
		};
	}
}
