package com.example.common.report.format.pdf.table;

import java.util.ArrayList;
import java.util.List;

import com.example.common.report.api.exception.ReportException;
import com.example.common.report.api.table.ColumnDefinition;
import com.example.common.report.api.table.TableDefinition;
import com.example.common.report.format.pdf.style.PdfCellStyle;
import com.example.common.report.format.pdf.style.PdfStyleResolver;
import com.example.common.report.format.pdf.writer.PdfPageMetrics;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfTableCompiler {

	PdfStyleResolver styleResolver;

	/**
	 * ColumnDefinition.width is "width in characters". Treat it as relative weight.
	 */
	private static float[] resolveColumnWidths(List<ColumnDefinition> defs, float contentWidth) {
		val widths = new float[defs.size()];

		float total = 0f;
		for (int i = 0; i < defs.size(); i++) {
			int width = defs.get(i).width();
			widths[i] = width;
			total += width;
		}

		for (int i = 0; i < widths.length; i++) {
			widths[i] = widths[i] * contentWidth / total;
		}

		return widths;
	}

	public PdfTable compileColumns(TableDefinition table, PdfPageMetrics pageMetrics) throws ReportException {
		val colDefs = table.columns();
		val columns = new ArrayList<PdfColumn>(colDefs.size());

		// Base styles (table-level)
		val baseHeaderStyle = table.headerStyle();
		val baseRowStyle = table.rowStyle();
		val baseAltRowStyle = styleResolver.merge(table.altRowStyle(), baseRowStyle);

		// widths computed from char widths
		val columnWidths = resolveColumnWidths(colDefs, pageMetrics.contentWidth());

		for (val colDef : colDefs) {
			// Column-level merged styles
			val headerStyle = styleResolver.resolveStyle(colDef.headerStyle(), baseHeaderStyle);
			val rowStyle = styleResolver.resolveStyle(colDef.cellStyle(), baseRowStyle);
			val altStyle = styleResolver.resolveStyle(colDef.cellStyle(), baseAltRowStyle);

			// Converter based on format
			val converter = styleResolver.resolveConverter(colDef.format());

			// Build prototypes
			val headerCell = createHeaderCell(colDef, headerStyle);
			val rowProto = createDataCellPrototype(rowStyle);

			// If alt style equals row style, reuse the same prototype
			val altProto = (altStyle == rowStyle || altStyle.equals(rowStyle))
				? rowProto
				: createDataCellPrototype(altStyle);

			columns.add(PdfColumn.builder()
				.key(colDef.key())
				.header(colDef.header())
				.converter(converter)
				.headerCell(headerCell)
				.rowCellPrototype(rowProto)
				.altCellPrototype(altProto)
				.cellTextStyler((paragraph, alt) -> (alt ? altStyle : rowStyle)
					.applyTextStyle(paragraph))
				.build());
		}

		return PdfTable.builder()
			.columns(columns)
			.columnWidths(columnWidths)
			.contentWidth(pageMetrics.contentWidth())
			.build();
	}

	private Cell createHeaderCell(ColumnDefinition colDef, PdfCellStyle style) {
		val cell = new Cell();
		style.applyCellStyle(cell);

		val paragraph = new Paragraph(colDef.header());
		style.applyTextStyle(paragraph);
		cell.add(paragraph);

		return cell;
	}

	private Cell createDataCellPrototype(PdfCellStyle style) {
		val cell = new Cell();
		style.applyCellStyle(cell);
		return cell;
	}
}