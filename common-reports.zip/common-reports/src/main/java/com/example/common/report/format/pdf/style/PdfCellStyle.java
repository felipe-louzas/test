package com.example.common.report.format.pdf.style;

import java.util.Objects;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;
import lombok.Builder;
import org.jspecify.annotations.NullMarked;

@Builder
@NullMarked
public record PdfCellStyle(
	PdfFont font,
	Float fontSize,
	Color textColor,
	Color backgroundColor,
	TextAlignment textAlignment,
	VerticalAlignment verticalAlignment,
	Boolean border
) {
	private static final Border DEFAULT_BORDER = new SolidBorder(0.5f);

	public PdfCellStyle {
		Objects.requireNonNull(font, "font must not be null");
		Objects.requireNonNull(fontSize, "fontSize must not be null");
		Objects.requireNonNull(textColor, "textColor must not be null");
		Objects.requireNonNull(backgroundColor, "backgroundColor must not be null");
		Objects.requireNonNull(textAlignment, "textAlignment must not be null");
		Objects.requireNonNull(verticalAlignment, "verticalAlignment must not be null");
		Objects.requireNonNull(border, "border must not be null");
	}

	/**
	 * Apply cell-level properties that are stable per style (background, border, alignment). Keep this minimal and deterministic.
	 */
	public void applyCellStyle(Cell cell) {
		cell.setTextAlignment(textAlignment);
		cell.setVerticalAlignment(verticalAlignment);
		cell.setBackgroundColor(backgroundColor);
		cell.setBorder(border ? DEFAULT_BORDER : Border.NO_BORDER);
	}

	/**
	 * Apply text styling to the Paragraph created per cell (or header prototype).
	 */
	public void applyTextStyle(Paragraph paragraph) {
		paragraph.setFont(font);
		paragraph.setFontSize(fontSize);
		paragraph.setFontColor(textColor);
	}
}
