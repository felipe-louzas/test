package com.example.common.report.format.pdf.context;

import java.util.List;

import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.format.pdf.PdfReportOptions;
import lombok.Builder;

@Builder
public record PdfReportContext(
	PdfReportOptions options,
	ReportOptions reportOptions,
	PdfPageMetrics page,
	List<PdfColumn> columns,

	List<PdfBand> startBands,
	List<PdfBand> headerBands,
	List<PdfBand> footerBands,
	List<PdfBand> endBands
) {}
