package com.example.common.report.api.layout;

import com.example.common.report.api.style.CellStyle;
import lombok.Builder;

@Builder
public record BandComponent(
    BandSlot slot,       // LEFT, CENTER, RIGHT
    BandContent content,
    Alignment alignment,
    CellStyle style
) {}
