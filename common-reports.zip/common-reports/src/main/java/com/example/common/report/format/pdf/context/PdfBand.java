package com.example.common.report.format.pdf.context;

import java.util.Map;

import com.example.common.report.api.layout.BandSlot;

record PdfBand(
	float height,
	boolean repeatOnEachPage,
	Map<BandSlot, PdfBandCell> slots
) {}