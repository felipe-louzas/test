package com.example.common.report.format.pdf.section;

import lombok.Builder;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@NullMarked
@Builder
public record PdfReportSections(
	@Nullable PdfSection pageHeader,
	@Nullable PdfSection pageFooter,
	@Nullable PdfSection contentHeader,
	@Nullable PdfSection contentFooter
) {
}
