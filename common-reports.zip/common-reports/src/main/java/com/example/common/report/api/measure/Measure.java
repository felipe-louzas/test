package com.example.common.report.api.measure;

import lombok.val;

public record Measure(
	float value,
	Unit unit
) {
	// Convenience factories
	public static Measure pt(float v) {
		return new Measure(v, Unit.POINT);
	}

	public static Measure inch(float v) {
		return new Measure(v, Unit.INCH);
	}

	public static Measure cm(float v) {
		return new Measure(v, Unit.CM);
	}

	public static Measure mm(float v) {
		return new Measure(v, Unit.MM);
	}

	public static Measure px(float v) {
		return new Measure(v, Unit.PX);
	}

	public float points() {
		return unit.toPoints(value);
	}

	public float in(Unit target) {
		val pts = points();
		return target.fromPoints(pts);
	}
}
