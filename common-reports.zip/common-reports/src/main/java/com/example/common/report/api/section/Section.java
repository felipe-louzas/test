package com.example.common.report.api.section;

import java.util.List;

import lombok.Builder;
import lombok.Singular;
import org.apache.commons.lang3.ObjectUtils;
import org.jspecify.annotations.NullMarked;

@Builder
@NullMarked
public record Section(
	@Singular
	List<SectionRow> rows
) {
	public Section {
		if (ObjectUtils.isEmpty(rows)) {
			throw new IllegalArgumentException("Section must contain at least one row.");
		}
	}

	public List<SectionRow> filterRows(PageRenderPolicy policy) {
		return rows.stream()
			.filter(row -> row.pageRenderPolicy() == policy)
			.toList();
	}

	public List<SectionRow> filterRows(PageRenderPolicyMask policyMask) {
		return rows.stream()
			.filter(row -> policyMask.contains(row.pageRenderPolicy()))
			.toList();
	}
}
