package com.example.common.report.converter;

@FunctionalInterface
public interface ValueConverter<T> {
	T convert(Object value);
}
