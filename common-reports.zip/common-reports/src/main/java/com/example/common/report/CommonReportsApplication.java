package com.example.common.report;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CommonReportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(CommonReportsApplication.class, args);
	}

}
