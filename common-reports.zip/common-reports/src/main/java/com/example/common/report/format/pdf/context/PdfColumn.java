package com.example.common.report.format.pdf.context;

import com.example.common.report.converter.ValueConverter;

public record PdfColumn(
	String key,
	String header,
	float width,
	ValueConverter<String> converter,
	PdfCellStyle headerStyle,
	PdfCellStyle rowStyle,
	PdfCellStyle alternateRowStyle
) {}
