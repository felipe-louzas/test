package com.example.common.report.format.pdf.style;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.IdentityHashMap;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.example.common.report.api.exception.ReportException;
import com.example.common.report.api.style.FontFamily;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.io.font.constants.StandardFonts;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.function.Failable;
import org.jspecify.annotations.NullMarked;
import org.springframework.core.io.ResourceLoader;

import static com.example.common.report.api.style.StandardFonts.*;

@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfFontResolver {
	private static final Map<FontFamily, String> STANDARD_FONTS = new IdentityHashMap<>(Map.of(
		SERIF, StandardFonts.TIMES_ROMAN,
		SANS_SERIF, StandardFonts.HELVETICA,
		MONOSPACE, StandardFonts.COURIER
	));

	ResourceLoader resourceLoader;
	Map<String, PdfFont> resolvedFonts = new ConcurrentHashMap<>();

	public PdfFont resolve(FontFamily fontFamily, boolean bold, boolean italic) throws ReportException {
		try {
			return resolvedFonts.computeIfAbsent(fontKey(fontFamily, bold, italic), Failable.asFunction(key -> loadFont(fontFamily, bold, italic)));
		} catch (UncheckedIOException | UndeclaredThrowableException ex) {
			throw new ReportException("Error loading font for " + fontFamily.familyName() + " with bold=" + bold + " and italic=" + italic, ex.getCause());
		} catch (Exception ex) {
			throw new ReportException("Unexpected error loading font for " + fontFamily.familyName() + " with bold=" + bold + " and italic=" + italic, ex);
		}
	}

	private PdfFont loadFont(FontFamily fontFamily, boolean bold, boolean italic) throws IOException {
		if (STANDARD_FONTS.containsKey(fontFamily)) {
			val fontName = STANDARD_FONTS.get(fontFamily);
			return resolveStandardFont(fontName, bold, italic);
		}

		val fontResource = fontFamily.fonts().stream()
			.filter(res -> res.matchesStyle(bold, italic))
			.findFirst()
			.orElseThrow(() -> new IllegalArgumentException("No font resource found for " + fontFamily.familyName() + " with bold=" + bold + " and italic=" + italic));

		val resource = resourceLoader.getResource(fontResource.resourcePath());

		try (val stream = resource.getInputStream()) {
			return PdfFontFactory.createFont(stream.readAllBytes(), PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
		}
	}

	private String fontKey(FontFamily fontFamily, boolean bold, boolean italic) {
		return fontFamily.familyName() + "|" + bold + "|" + italic;
	}

	private PdfFont resolveStandardFont(String fontName, boolean bold, boolean italic) throws IOException {
		val derivedFontName = switch (fontName) {
			case StandardFonts.HELVETICA -> {
				if (bold && italic) yield StandardFonts.HELVETICA_BOLDOBLIQUE;
				if (bold) yield StandardFonts.HELVETICA_BOLD;
				if (italic) yield StandardFonts.HELVETICA_OBLIQUE;
				yield StandardFonts.HELVETICA;
			}
			case StandardFonts.TIMES_ROMAN -> {
				if (bold && italic) yield StandardFonts.TIMES_BOLDITALIC;
				if (bold) yield StandardFonts.TIMES_BOLD;
				if (italic) yield StandardFonts.TIMES_ITALIC;
				yield StandardFonts.TIMES_ROMAN;
			}
			case StandardFonts.COURIER -> {
				if (bold && italic) yield StandardFonts.COURIER_BOLDOBLIQUE;
				if (bold) yield StandardFonts.COURIER_BOLD;
				if (italic) yield StandardFonts.COURIER_OBLIQUE;
				yield StandardFonts.COURIER;
			}
			default -> throw new IllegalArgumentException("Unknown standard font: " + fontName);
		};

		return PdfFontFactory.createRegisteredFont(derivedFontName);
	}
}
