package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;

public record PageSize(
	Measure width,
	Measure height
) {
	public boolean isLandscape() {
		return width.points() > height.points();
	}

	public boolean isPortrait() {
		return height.points() >= width.points();
	}

	public PageSize landscape() {
		return isLandscape() ? this : new PageSize(height(), width());
	}

	public PageSize portrait() {
		return isPortrait() ? this : new PageSize(height(), width());
	}
}
