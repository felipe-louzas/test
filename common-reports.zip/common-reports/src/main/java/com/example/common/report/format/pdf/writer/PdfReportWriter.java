package com.example.common.report.format.pdf.writer;

import java.io.IOException;
import java.io.OutputStream;

import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.core.RowMapper;
import com.example.common.report.api.exception.ReportException;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.event.PdfDocumentEvent;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.AreaBreak;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;

@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class PdfReportWriter implements ReportWriter {

	CompiledPdfReport compiled;

	@Override
	public <T> void write(Iterable<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException {
		val metrics = compiled.pageMetrics();
		val pageSize = new PageSize(metrics.pageWidth(), metrics.pageHeight());

		try (val writer = new PdfWriter(output);
		     val pdf = new PdfDocument(writer);
		     val document = new Document(pdf, pageSize)) {

			val context = new PdfWriterContext(compiled, pdf, document);

			val eventHandler = new PdfPageEventHandler(context);
			pdf.addEventHandler(PdfDocumentEvent.START_PAGE, eventHandler);
			pdf.addEventHandler(PdfDocumentEvent.END_PAGE, eventHandler);

			val table = buildTable();
			writeDataRows(data, mapper, table);
			document.add(table);

			// Check to see if there is enough room for last page footer, if not add a new page
			val currentAreaBBox = document.getRenderer().getCurrentArea().getBBox();
			val remainingContentHeight = currentAreaBBox.getHeight();
			if (remainingContentHeight < metrics.getLastPageAdditionalFooterHeight(pdf.getNumberOfPages())) {
				document.add(new AreaBreak());
			}

			// Let the context trigger any end-of-report actions
			context.onReportEnd();

		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new ReportException("Erro ao gerar o relatório PDF: " + ex.getLocalizedMessage(), ex);
		}
	}

	private Table buildTable() {
		val pdfTable = compiled.table();
		val table = new Table(pdfTable.columnWidths());
		table.setWidth(pdfTable.contentWidth());
		table.setFixedLayout();

		if (compiled.reportOptions().includeHeader()) {
			for (val column : pdfTable.columns()) {
				table.addHeaderCell(column.headerCell().clone(true));
			}
		}

		return table;
	}

	private <T> void writeDataRows(Iterable<T> data, RowMapper<T> mapper, Table table) {
		val columns = compiled.table().columns();
		int rowIndex = 0;

		for (val row : data) {
			val alt = (rowIndex & 1) == 1;

			for (val column : columns) {
				val proto = alt ? column.altCellPrototype() : column.rowCellPrototype();
				val cell = proto.clone(false);
				val value = mapper.getValue(row, column.key());
				val text = column.converter().convert(value);
				val paragraph = new Paragraph(text);
				column.cellTextStyler().apply(paragraph, alt);
				cell.add(paragraph);
				table.addCell(cell);
			}

			rowIndex++;
		}
	}
}
