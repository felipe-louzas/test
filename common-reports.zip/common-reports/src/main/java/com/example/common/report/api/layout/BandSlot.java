package com.example.common.report.api.layout;

public enum BandSlot {
    LEFT,
    CENTER,
    RIGHT
}
