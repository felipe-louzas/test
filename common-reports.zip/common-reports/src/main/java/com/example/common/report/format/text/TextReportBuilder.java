package com.example.common.report.format.text;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.api.table.TableDefinition;
import com.example.common.report.converter.TextValueConverters;
import com.example.common.report.converter.ValueConverter;
import com.example.common.report.engine.ReportBuilder;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import lombok.Getter;
import lombok.val;
import org.apache.commons.lang3.ObjectUtils;
import org.jspecify.annotations.NullMarked;

@Getter
@NullMarked
public class TextReportBuilder implements ReportBuilder<TextReportOptions> {

	ReportFormat<TextReportOptions> format = ReportFormats.TEXT;
	TextReportOptions defaultOptions = TextReportOptions.csvDefaults();

	@Override
	public ReportWriter buildReport(ReportTemplate template, TextReportOptions options, ReportOptions reportOptions) {
		val table = template.table();

		val columns = compileColumns(table, reportOptions);

		val ctx = TextReportContext.builder()
			.columns(columns)
			.includeHeader(options.includeHeader())
			.writerFactory(outputStream -> new UnivocityRowWriter(outputStream, options))
			.build();

		return new TextReportWriter(ctx);
	}

	private List<TextReportColumn> compileColumns(TableDefinition table, ReportOptions reportOptions) {
		val formatterPool = new HashMap<CellStyle, ValueConverter<String>>();
		val columnList = new ArrayList<TextReportColumn>(table.columns().size());

		for (val columnDefinition : table.columns()) {
			val formatter = formatterPool.computeIfAbsent(
				columnDefinition.style(),
				style -> TextValueConverters.forStyle(style, reportOptions)
			);
			val textColumn = TextReportColumn.builder()
				.header(columnDefinition.header())
				.key(columnDefinition.key())
				.converter(formatter)
				.build();
			columnList.add(textColumn);
		}

		return columnList;
	}
}
