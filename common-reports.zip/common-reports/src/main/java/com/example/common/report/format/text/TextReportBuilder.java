package com.example.common.report.format.text;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.style.format.TextFormat;
import com.example.common.report.api.table.TableDefinition;
import com.example.common.report.converter.TextValueConverters;
import com.example.common.report.converter.ValueConverter;
import com.example.common.report.engine.ReportBuilder;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

@Getter
@NullMarked
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class TextReportBuilder implements ReportBuilder<TextReportOptions> {

    ReportFormat<TextReportOptions> format = ReportFormats.TEXT;
    TextReportOptions defaultOptions = TextReportOptions.csvDefaults();

    @Override
    public ReportWriter buildReport(ReportTemplate template, TextReportOptions reportOptions, ReportEngineOptions engineOptions) {
        val table = template.table();

        val columns = compileColumns(table, engineOptions);

        val ctx = CompiledTextReport.builder()
                .columns(columns)
                .includeHeader(reportOptions.includeHeader())
                .writerFactory(outputStream -> new UnivocityRowWriter(outputStream, reportOptions))
                .build();

        return new TextReportWriter(ctx);
    }

    private List<TextReportColumn> compileColumns(TableDefinition table, ReportEngineOptions reportEngineOptions) {
        val formatterPool = new HashMap<TextFormat, ValueConverter<String>>();
        val columnList = new ArrayList<TextReportColumn>(table.columns().size());

        for (val columnDefinition : table.columns()) {
            val formatter = formatterPool.computeIfAbsent(
                    columnDefinition.format(),
                    style -> TextValueConverters.forStyle(style, reportEngineOptions)
            );
            val textColumn = TextReportColumn.builder()
                    .header(columnDefinition.header())
                    .key(columnDefinition.key())
                    .converter(formatter)
                    .build();
            columnList.add(textColumn);
        }

        return columnList;
    }
}
