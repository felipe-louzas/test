package com.example.common.report.api.core;

import java.io.IOException;
import java.io.OutputStream;
import java.util.stream.Stream;

import com.example.common.report.api.exception.ReportException;

public interface ReportWriter {
	<T> void write(Stream<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException;
}
