package com.example.common.report.api.core;

import com.example.common.report.api.exception.ReportException;

import java.io.IOException;
import java.io.OutputStream;
import java.util.stream.Stream;

public interface ReportWriter {
    <T> void write(Iterable<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException;

    default <T> void write(Stream<T> stream, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException {
        write(stream::iterator, mapper, output);
    }
}
