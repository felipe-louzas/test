package com.example.common.report.format;

import com.example.common.report.format.pdf.PdfReportOptions;
import com.example.common.report.format.text.TextReportOptions;
import lombok.experimental.UtilityClass;

@UtilityClass
public class ReportFormats {
	public final ReportFormat<TextReportOptions> TEXT = ReportFormat.create("TEXT");
	public final ReportFormat<PdfReportOptions> PDF = ReportFormat.create("PDF");
	public final ReportFormat<TextReportOptions> XLSX = ReportFormat.create("XLSX");
}
