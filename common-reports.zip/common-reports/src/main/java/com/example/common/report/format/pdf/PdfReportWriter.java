package com.example.common.report.format.pdf;

import java.io.IOException;
import java.io.OutputStream;
import java.util.List;
import java.util.stream.Stream;

import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.core.RowMapper;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.format.pdf.context.PdfCellStyle;
import com.example.common.report.format.pdf.context.PdfReportContext;
import com.example.common.report.format.pdf.context.PdfReportContext.ImageComponentPlan;
import com.example.common.report.format.pdf.context.PdfReportContext.PageNumberComponentPlan;
import com.example.common.report.format.pdf.context.PdfReportContext.PdfBandPlan;
import com.example.common.report.format.pdf.context.PdfReportContext.PdfBandSlotPlan;
import com.example.common.report.format.pdf.context.PdfReportContext.PdfPageMetrics;
import com.example.common.report.format.pdf.context.PdfReportContext.TextComponentPlan;
import com.itextpdf.kernel.geom.PageSize;
import com.itextpdf.kernel.geom.Rectangle;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.kernel.pdf.PdfPage;
import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.canvas.PdfCanvas;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEvent;
import com.itextpdf.kernel.pdf.event.AbstractPdfDocumentEventHandler;
import com.itextpdf.kernel.pdf.event.PdfDocumentEvent;
import com.itextpdf.layout.Canvas;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.borders.Border;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.HorizontalAlignment;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.UnitValue;
import lombok.RequiredArgsConstructor;
import lombok.val;

@RequiredArgsConstructor
final class PdfReportWriter implements ReportWriter {

	private final PdfReportContext context;

	private static String nullSafe(String value) {
		return value == null ? "" : value;
	}

	private static void applyCellStyle(Cell cell, PdfCellStyle style) {
		if (style == null) return;
		if (style.font() != null) {
			cell.setFont(style.font());
		}
		if (style.fontSize() != null) {
			cell.setFontSize(style.fontSize());
		}
		if (style.textColor() != null) {
			cell.setFontColor(style.textColor());
		}
		if (style.backgroundColor() != null) {
			cell.setBackgroundColor(style.backgroundColor());
		}
		if (style.alignment() != null) {
			cell.setTextAlignment(style.alignment());
		}
		if (Boolean.FALSE.equals(style.border())) {
			cell.setBorder(Border.NO_BORDER);
		}
	}

	private static Table buildBandTable(PdfBandPlan band, float availableWidth, int pageNumber, int totalPages) {
		val table = new Table(UnitValue.createPercentArray(new float[]{1f, 1f, 1f}));
		table.setWidth(UnitValue.createPointValue(availableWidth));
		table.setFixedLayout();
		if (band.height() > 0f) {
			table.setHeight(band.height());
		}
		for (val slotPlan : band.slots()) {
			val defaultAlignment = switch (slotPlan.slot()) {
				case LEFT -> TextAlignment.LEFT;
				case CENTER -> TextAlignment.CENTER;
				case RIGHT -> TextAlignment.RIGHT;
			};
			table.addCell(buildBandCell(slotPlan, defaultAlignment, pageNumber, totalPages));
		}
		return table;
	}

	private static Cell buildBandCell(PdfBandSlotPlan slotPlan, TextAlignment defaultAlignment, int pageNumber, int totalPages) {
		val cell = new Cell();
		cell.setBorder(Border.NO_BORDER);
		cell.setTextAlignment(defaultAlignment);
		if (slotPlan.components().isEmpty()) {
			return cell;
		}

		applyCellStyle(cell, slotPlan.components().get(0).style());
		for (val component : slotPlan.components()) {
			val alignment = component.alignment() != null ? component.alignment() : defaultAlignment;
			if (component instanceof TextComponentPlan text) {
				val paragraph = new Paragraph(nullSafe(text.text()));
				paragraph.setTextAlignment(alignment);
				applyTextStyle(paragraph, text.style());
				cell.add(paragraph);
			} else if (component instanceof PageNumberComponentPlan number) {
				val paragraph = new Paragraph(formatPageNumber(number.pattern(), pageNumber, totalPages));
				paragraph.setTextAlignment(alignment);
				applyTextStyle(paragraph, number.style());
				cell.add(paragraph);
			} else if (component instanceof ImageComponentPlan imagePlan) {
				val image = new Image(imagePlan.imageData());
				if (imagePlan.width() > 0f) {
					image.setWidth(imagePlan.width());
				}
				if (imagePlan.height() > 0f) {
					image.setHeight(imagePlan.height());
				}
				image.setHorizontalAlignment(toHorizontalAlignment(alignment));
				cell.add(image);
			}
		}
		return cell;
	}

	private static void applyTextStyle(Paragraph paragraph, PdfCellStyle style) {
		if (style == null) return;
		if (style.font() != null) {
			paragraph.setFont(style.font());
		}
		if (style.fontSize() != null) {
			paragraph.setFontSize(style.fontSize());
		}
		if (style.textColor() != null) {
			paragraph.setFontColor(style.textColor());
		}
	}

	private static HorizontalAlignment toHorizontalAlignment(TextAlignment alignment) {
		return switch (alignment) {
			case LEFT -> HorizontalAlignment.LEFT;
			case CENTER -> HorizontalAlignment.CENTER;
			case RIGHT, JUSTIFIED, JUSTIFIED_ALL -> HorizontalAlignment.RIGHT;
		};
	}

	private static String formatPageNumber(String pattern, int pageNumber, int totalPages) {
		if (pattern == null || pattern.isBlank()) {
			return Integer.toString(pageNumber);
		}
		return pattern
			.replace("{page}", Integer.toString(pageNumber))
			.replace("{total}", Integer.toString(totalPages));
	}

	private static void renderRepeatingBands(
		PdfPage page,
		PdfDocument pdf,
		List<PdfBandPlan> bands,
		PdfPageMetrics metrics,
		boolean header,
		int pageNumber,
		int totalPages,
		Rectangle pageSize
	) {
		if (bands == null || bands.isEmpty()) return;
		val repeating = bands.stream().filter(PdfBandPlan::repeatOnEachPage).toList();
		if (repeating.isEmpty()) return;

		val canvas = new Canvas(new PdfCanvas(page.newContentStreamAfter(), page.getResources(), pdf), pageSize);
		val availableWidth = metrics.contentWidth();
		val left = metrics.marginLeft();

		if (header) {
			float y = pageSize.getHeight() - metrics.marginTop();
			for (val band : repeating) {
				y -= band.height();
				val table = buildBandTable(band, availableWidth, pageNumber, totalPages);
				table.setFixedPosition(left, y, availableWidth);
				canvas.add(table);
			}
		} else {
			float y = metrics.marginBottom() + totalHeight(repeating);
			for (val band : repeating) {
				y -= band.height();
				val table = buildBandTable(band, availableWidth, pageNumber, totalPages);
				table.setFixedPosition(left, y, availableWidth);
				canvas.add(table);
			}
		}
		canvas.close();
	}

	private static float totalHeight(List<PdfBandPlan> bands) {
		float total = 0f;
		for (val band : bands) {
			total += band.height();
		}
		return total;
	}

	@Override
	public <T> void write(Stream<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException {
		val metrics = context.page();
		val pageSize = new PageSize(metrics.pageWidth(), metrics.pageHeight());

		try (val writer = new PdfWriter(output);
		     val pdf = new PdfDocument(writer);
		     val document = new Document(pdf, pageSize)) {

			document.setMargins(
				metrics.marginTop() + context.repeatingHeaderHeight(),
				metrics.marginRight(),
				metrics.marginBottom() + context.repeatingFooterHeight(),
				metrics.marginLeft()
			);

			val handler = new HeaderFooterHandler(context.headerBands(), context.footerBands(), metrics);
			pdf.addEventHandler(PdfDocumentEvent.END_PAGE, handler);

			addStaticBands(document, context.headerBands(), metrics);
			val table = buildTable();
			writeDataRows(data, mapper, table);
			document.add(table);
			addStaticBands(document, context.footerBands(), metrics);
		} catch (IOException ex) {
			throw ex;
		} catch (Exception ex) {
			throw new ReportException("Erro ao gerar o relatorio PDF: " + ex.getLocalizedMessage(), ex);
		}
	}

	private void addStaticBands(Document document, List<PdfBandPlan> bands, PdfPageMetrics metrics) {
		if (bands == null || bands.isEmpty()) return;
		val staticBands = bands.stream().filter(band -> !band.repeatOnEachPage()).toList();
		if (staticBands.isEmpty()) return;
		for (val band : staticBands) {
			val table = buildBandTable(band, metrics.contentWidth(), 1, 1);
			table.setWidth(UnitValue.createPointValue(metrics.contentWidth()));
			document.add(table);
		}
	}

	private Table buildTable() {
		val table = new Table(UnitValue.createPercentArray(context.columnWeights()));
		table.setWidth(UnitValue.createPercentValue(100));
		table.setFixedLayout();

		if (context.options().includeHeader()) {
			for (val column : context.columns()) {
				val cell = new Cell();
				applyCellStyle(cell, column.headerStyle());
				cell.add(new Paragraph(nullSafe(column.header())));
				table.addHeaderCell(cell);
			}
		}

		return table;
	}

	private <T> void writeDataRows(Stream<T> data, RowMapper<T> mapper, Table table) {
		val iterator = data.iterator();
		int rowIndex = 0;
		while (iterator.hasNext()) {
			val row = iterator.next();
			for (val column : context.columns()) {
				val style = (rowIndex % 2 == 0) ? column.rowStyle() : column.alternateRowStyle();
				val cell = new Cell();
				applyCellStyle(cell, style);
				val value = column.converter().convert(mapper.getValue(row, column.key()));
				cell.add(new Paragraph(nullSafe(value)));
				table.addCell(cell);
			}
			rowIndex++;
		}
	}

	private static final class HeaderFooterHandler extends AbstractPdfDocumentEventHandler {
		private final List<PdfBandPlan> headerBands;
		private final List<PdfBandPlan> footerBands;
		private final PdfPageMetrics metrics;

		private HeaderFooterHandler(List<PdfBandPlan> headerBands, List<PdfBandPlan> footerBands, PdfPageMetrics metrics) {
			this.headerBands = headerBands;
			this.footerBands = footerBands;
			this.metrics = metrics;

			addType(PdfDocumentEvent.END_PAGE);
		}

		@Override
		protected void onAcceptedEvent(AbstractPdfDocumentEvent event) {
			val docEvent = (PdfDocumentEvent) event;
			val pdf = docEvent.getDocument();
			val page = docEvent.getPage();
			val pageSize = page.getPageSize();
			val pageNumber = pdf.getPageNumber(page);
			val totalPages = pdf.getNumberOfPages();

			renderRepeatingBands(page, pdf, headerBands, metrics, true, pageNumber, totalPages, pageSize);
			renderRepeatingBands(page, pdf, footerBands, metrics, false, pageNumber, totalPages, pageSize);
		}
	}
}
