package com.example.common.report.api.style.format;

import java.time.format.FormatStyle;

public record DateTimeFormat(
	DateTimeKind temporalKind,
	DateTimeStandard standard,
	FormatStyle dateStyle,
	FormatStyle timeStyle
) implements TextFormat {

	public static final DateTimeFormat DEFAULT_FORMAT = DateTimeFormat.localizedDateTime();

	public static DateTimeFormat isoDate() {
		return new DateTimeFormat(DateTimeKind.DATE, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat isoTime() {
		return new DateTimeFormat(DateTimeKind.TIME, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat isoDateTime() {
		return new DateTimeFormat(DateTimeKind.DATETIME, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat localizedDate() {
		return localizedDate(FormatStyle.SHORT);
	}

	public static DateTimeFormat localizedDate(FormatStyle dateStyle) {
		return new DateTimeFormat(DateTimeKind.DATE, DateTimeStandard.LOCALIZED, dateStyle, null);
	}

	public static DateTimeFormat localizedTime() {
		return localizedTime(FormatStyle.SHORT);
	}

	public static DateTimeFormat localizedTime(FormatStyle timeStyle) {
		return new DateTimeFormat(DateTimeKind.TIME, DateTimeStandard.LOCALIZED, null, timeStyle);
	}

	public static DateTimeFormat localizedDateTime() {
		return localizedDateTime(FormatStyle.SHORT, FormatStyle.MEDIUM);
	}

	public static DateTimeFormat localizedDateTime(FormatStyle dateStyle, FormatStyle timeStyle) {
		return new DateTimeFormat(DateTimeKind.DATETIME, DateTimeStandard.LOCALIZED, dateStyle, timeStyle);
	}
}