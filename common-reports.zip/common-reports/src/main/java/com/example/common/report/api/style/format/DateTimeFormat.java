package com.example.common.report.api.style.format;

import java.time.format.FormatStyle;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Value;

@Value
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class DateTimeFormat implements TextFormat {
	public static final DateTimeFormat DEFAULT_FORMAT = new DateTimeFormat(
		DateTimeKind.DATETIME,
		DateTimeStandard.LOCALIZED,
		FormatStyle.SHORT,
		FormatStyle.SHORT
	);

	DateTimeKind temporalKind;
	DateTimeStandard standard;
	FormatStyle dateStyle;
	FormatStyle timeStyle;

	public static DateTimeFormat isoDate() {
		return new DateTimeFormat(DateTimeKind.DATE, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat isoTime() {
		return new DateTimeFormat(DateTimeKind.TIME, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat isoDateTime() {
		return new DateTimeFormat(DateTimeKind.DATETIME, DateTimeStandard.ISO, null, null);
	}

	public static DateTimeFormat localizedDate(FormatStyle dateStyle) {
		return new DateTimeFormat(DateTimeKind.DATE, DateTimeStandard.LOCALIZED, dateStyle, null);
	}

	public static DateTimeFormat localizedTime(FormatStyle timeStyle) {
		return new DateTimeFormat(DateTimeKind.TIME, DateTimeStandard.LOCALIZED, null, timeStyle);
	}

	public static DateTimeFormat localizedDateTime(FormatStyle dateStyle, FormatStyle timeStyle) {
		return new DateTimeFormat(DateTimeKind.DATETIME, DateTimeStandard.LOCALIZED, dateStyle, timeStyle);
	}
}