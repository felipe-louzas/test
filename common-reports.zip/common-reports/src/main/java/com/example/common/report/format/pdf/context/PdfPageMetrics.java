package com.example.common.report.format.pdf.context;

import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.measure.Unit;

public record PdfPageMetrics(
	float pageWidth,
	float pageHeight,
	PageLayoutMetrics defaultPageMetrics,
	PageLayoutMetrics firstPageMetrics,
	PageLayoutMetrics lastPageMetrics
) {
	public static PdfPageMetrics of(PageDefinition pageDefinition, PdfBandMetrics bandMetrics) {
		return new PdfPageMetrics(
			pageDefinition.size().width().points(),
			pageDefinition.size().height().points(),

			pageDefinition.contentWidth(Unit.POINT),
			pageDefinition.contentHeight(Unit.POINT),
			pageDefinition.marginTop().points(),
			pageDefinition.marginRight().points(),
			pageDefinition.marginBottom().points(),
			pageDefinition.marginLeft().points()
		);
	}

	public record PageLayoutMetrics(
		float marginTop,
		float marginRight,
		float marginBottom,
		float marginLeft,
		float headerHeight,
		float footerHeight,
		float contentTop,
		float contentWidth,
		float contentHeight
	) {}
}