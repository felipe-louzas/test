package com.example.common.report.format.text;

public interface RowWriter extends AutoCloseable {
	void writeHeader(String[] values) throws Exception;

	void writeRow(String[] values) throws Exception;

	void close();

	void flush();
}
