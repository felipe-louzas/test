package com.example.common.report.format.pdf.table;

import java.util.List;

import lombok.Builder;

@Builder
public record PdfTable(
	List<PdfColumn> columns,
	float[] columnWidths,
	float contentWidth
) {
}
