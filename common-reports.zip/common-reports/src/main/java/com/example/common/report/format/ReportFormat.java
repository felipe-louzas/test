package com.example.common.report.format;

import com.example.common.report.api.core.FormatOptions;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.ToString;
import lombok.experimental.FieldDefaults;

@Getter
@ToString
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class ReportFormat<O extends FormatOptions<O>> {
	String name;

	static <O extends FormatOptions<O>> ReportFormat<O> create(String name) {
		return new ReportFormat<>(name);
	}
}
