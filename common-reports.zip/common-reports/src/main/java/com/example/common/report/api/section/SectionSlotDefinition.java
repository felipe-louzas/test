package com.example.common.report.api.section;

import java.util.List;

import com.example.common.report.api.style.CellStyle;
import lombok.Builder;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Builder
@NullMarked
public record SectionSlotDefinition(
	@Nullable CellStyle style,
	@Nullable List<SectionComponent> components
) {}