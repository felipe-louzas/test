package com.example.common.report.format.pdf.table;

import com.example.common.report.converter.ValueConverter;
import com.example.common.report.format.pdf.style.PdfCellTextStyler;
import com.itextpdf.layout.element.Cell;
import lombok.Builder;
import org.jspecify.annotations.NullMarked;

@Builder
@NullMarked
public record PdfColumn(
        String key,
        String header,
        ValueConverter<String> converter,
        Cell headerCell,
        Cell rowCellPrototype,
        Cell altCellPrototype,
        PdfCellTextStyler cellTextStyler
) {}
