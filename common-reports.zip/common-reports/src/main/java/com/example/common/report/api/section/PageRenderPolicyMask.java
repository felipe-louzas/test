package com.example.common.report.api.section;

import java.util.Set;

import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.Value;
import org.jspecify.annotations.NullMarked;

@Value
@NullMarked
@AllArgsConstructor(access = AccessLevel.PRIVATE)
public class PageRenderPolicyMask {
	public static final Set<PageRenderPolicyMask> ALL_MASKS = Set.of(
		PageRenderPolicyMask.of(PageRenderPolicy.ALL_PAGES, PageRenderPolicy.FIRST_PAGE, PageRenderPolicy.ODD_PAGES),
		PageRenderPolicyMask.of(PageRenderPolicy.ALL_PAGES, PageRenderPolicy.INNER_PAGES, PageRenderPolicy.EVEN_PAGES),
		PageRenderPolicyMask.of(PageRenderPolicy.ALL_PAGES, PageRenderPolicy.INNER_PAGES, PageRenderPolicy.ODD_PAGES),
		PageRenderPolicyMask.of(PageRenderPolicy.ALL_PAGES, PageRenderPolicy.LAST_PAGE, PageRenderPolicy.EVEN_PAGES),
		PageRenderPolicyMask.of(PageRenderPolicy.ALL_PAGES, PageRenderPolicy.LAST_PAGE, PageRenderPolicy.ODD_PAGES)
	);

	int mask;

	public static PageRenderPolicyMask of(PageRenderPolicy... policies) {
		int mask = 0;
		for (PageRenderPolicy policy : policies) {
			mask |= mask(policy);
		}
		return new PageRenderPolicyMask(mask);
	}

	private static int mask(PageRenderPolicy policy) {
		return 1 << policy.ordinal();
	}

	public static PageRenderPolicyMask forPageNumber(int pageNumber, boolean isLastPage) {
		int mask = mask(PageRenderPolicy.ALL_PAGES);

		if (pageNumber == 1)
			mask |= mask(PageRenderPolicy.FIRST_PAGE);
		else if (isLastPage)
			mask |= mask(PageRenderPolicy.LAST_PAGE);
		else
			mask |= mask(PageRenderPolicy.INNER_PAGES);

		if ((pageNumber & 1) == 0)
			mask |= mask(PageRenderPolicy.EVEN_PAGES);
		else
			mask |= mask(PageRenderPolicy.ODD_PAGES);

		return new PageRenderPolicyMask(mask);
	}

	public boolean contains(PageRenderPolicy policy) {
		return (mask & mask(policy)) != 0;
	}

	public boolean matches(PageRenderPolicyMask other) {
		return (this.mask & other.mask) != 0;
	}
}
