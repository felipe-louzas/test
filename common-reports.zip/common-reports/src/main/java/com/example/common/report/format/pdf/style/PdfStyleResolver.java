package com.example.common.report.format.pdf.style;

import java.io.InputStream;
import java.lang.reflect.UndeclaredThrowableException;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;

import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.api.layout.HorizontalAlignment;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.api.style.ColorValue;
import com.example.common.report.api.style.format.TextFormat;
import com.example.common.report.converter.TextValueConverters;
import com.example.common.report.converter.ValueConverter;
import com.example.common.report.format.pdf.PdfReportOptions;
import com.example.utils.objects.FallbackChain;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.function.Failable;
import org.apache.commons.lang3.function.FailableFunction;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;
import org.springframework.core.io.ResourceLoader;

@NullMarked
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class PdfStyleResolver {
	ReportEngineOptions engineOptions;
	ResourceLoader resourceLoader;
	CellStyle baseStyle;
	PdfFontResolver fontResolver;
	Map<CellStyle, PdfCellStyle> resolvedStyles = new HashMap<>();
	Map<TextFormat, ValueConverter<String>> resolvedConverters = new HashMap<>();

	public PdfStyleResolver(PdfReportOptions reportOptions, ReportEngineOptions engineOptions, ResourceLoader resourceLoader) {
		this.engineOptions = engineOptions;
		this.resourceLoader = resourceLoader;
		this.fontResolver = new PdfFontResolver(resourceLoader);

		val styleOverrides = CellStyle.builder()
			.font(reportOptions.defaultFont())
			.fontSize(reportOptions.defaultFontSize())
			.build();

		this.baseStyle = merge(styleOverrides, CellStyle.DEFAULT);
	}

	public CellStyle merge(@Nullable CellStyle @Nullable ... cellStyles) {
		if (cellStyles == null || cellStyles.length == 0) return CellStyle.builder().build();
		if (cellStyles.length == 1) return Objects.requireNonNullElseGet(cellStyles[0], () -> CellStyle.builder().build());

		val styles = FallbackChain.of(cellStyles);

		return CellStyle.builder()
			.font(styles.resolve(CellStyle::font))
			.fontSize(styles.resolve(CellStyle::fontSize))
			.bold(styles.resolve(CellStyle::bold))
			.italic(styles.resolve(CellStyle::italic))
			.textColor(styles.resolve(CellStyle::textColor))
			.backgroundColor(styles.resolve(CellStyle::backgroundColor))
			.border(styles.resolve(CellStyle::border))
			.horizontalAlignment(styles.resolve(CellStyle::horizontalAlignment))
			.verticalAlignment(styles.resolve(CellStyle::verticalAlignment))
			.build();
	}

	public PdfCellStyle resolveStyle(@Nullable CellStyle @Nullable ... cellStyles) throws ReportException {
		try {
			return resolvedStyles.computeIfAbsent(merge(merge(cellStyles), baseStyle), Failable.asFunction(this::toPdfStyle));

		} catch (UndeclaredThrowableException ex) {
			if (ex.getCause() instanceof ReportException reportException) throw reportException;
			throw new ReportException("Unexpected error resolving style", ex.getCause());
		}
	}

	public ValueConverter<String> resolveConverter(TextFormat format) {
		return resolvedConverters.computeIfAbsent(format, fmt -> TextValueConverters.forStyle(fmt, engineOptions));
	}

	public <R, E extends Exception> R withResource(String resourcePath, FailableFunction<InputStream, R, E> action) throws ReportException {
		try (val inputStream = resourceLoader.getResource(resourcePath).getInputStream()) {
			return action.apply(inputStream);
		} catch (Exception ex) {
			throw new ReportException("Failed to load resource: " + resourcePath, ex);
		}
	}

	private PdfCellStyle toPdfStyle(CellStyle cellStyle) throws ReportException {
		return PdfCellStyle.builder()
			.font(fontResolver.resolve(cellStyle.font(), cellStyle.bold(), cellStyle.italic()))
			.fontSize(cellStyle.fontSize())
			.textColor(toColor(cellStyle.textColor()))
			.backgroundColor(toColor(cellStyle.backgroundColor()))
			.textAlignment(toTextAlignment(cellStyle.horizontalAlignment()))
			.verticalAlignment(toVerticalAlignment(cellStyle.verticalAlignment()))
			.border(cellStyle.border())
			.build();
	}

	private Color toColor(ColorValue value) {
		return new DeviceRgb(value.red(), value.green(), value.blue());
	}

	private TextAlignment toTextAlignment(HorizontalAlignment horizontalAlignment) {
		return switch (horizontalAlignment) {
			case LEFT -> TextAlignment.LEFT;
			case CENTER -> TextAlignment.CENTER;
			case RIGHT -> TextAlignment.RIGHT;
		};
	}

	private VerticalAlignment toVerticalAlignment(com.example.common.report.api.layout.VerticalAlignment verticalAlignment) {
		return switch (verticalAlignment) {
			case TOP -> VerticalAlignment.TOP;
			case CENTER -> VerticalAlignment.MIDDLE;
			case BOTTOM -> VerticalAlignment.BOTTOM;
		};
	}

}
