package com.example.common.report.format.text;

import com.example.common.report.converter.ValueConverter;
import lombok.Builder;

@Builder
record TextReportColumn(
	String header,
	String key,
	ValueConverter<String> converter
) {}