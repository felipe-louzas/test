package com.example.common.report.api.style;

import java.util.Objects;

import lombok.Builder;

@Builder
public record FontResource(
	String name,
	String resourcePath,
	boolean bold,
	boolean italic
) {
	public FontResource {
		Objects.requireNonNull(name, "name must not be null");
		Objects.requireNonNull(resourcePath, "resourcePath must not be null");
	}

	public boolean matchesStyle(boolean bold, boolean italic) {
		return this.bold == bold && this.italic == italic;
	}
}
