package com.example.common.report.api.style;

import lombok.Builder;

@Builder
public record FontResource(
	String name,
	String resourcePath,
	boolean bold,
	boolean italic
) {}
