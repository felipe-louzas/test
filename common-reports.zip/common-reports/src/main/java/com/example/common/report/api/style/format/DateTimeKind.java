package com.example.common.report.api.style.format;

public enum DateTimeKind {
	DATE, TIME, DATETIME
}
