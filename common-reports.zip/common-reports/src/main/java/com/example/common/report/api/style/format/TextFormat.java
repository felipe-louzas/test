package com.example.common.report.api.style.format;

public sealed interface TextFormat
    permits NumericFormat, DateTimeFormat {
}