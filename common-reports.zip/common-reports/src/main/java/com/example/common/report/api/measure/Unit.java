package com.example.common.report.api.measure;

public enum Unit {
    POINT(1.0f),
    INCH(72.0f),
    CM(28.3464567f),     // 72 / 2.54
    MM(2.83464567f),
    PX(0.75f);           // 96 DPI → 72 / 96

    private final float toPoints;

    Unit(float toPoints) {
        this.toPoints = toPoints;
    }

    public float toPoints(float value) {
        return value * toPoints;
    }

    public float fromPoints(float points) {
        return points / toPoints;
    }
}
