package com.example.common.report.api.measure;

/**
 * Unidade de medida utilizada para conversão de dimensões.
 * <p>
 * Todas as unidades são convertidas internamente para <b>pontos (pt)</b>. A relação entre unidades físicas segue o padrão:
 *
 * <pre>
 * 1 polegada = 72 pt
 * </pre>
 *
 * <p>
 * A unidade {@link #PX} representa um <b>píxel lógico</b> definido com DPI fixo em <b>144 DPI</b>:
 *
 * <pre>
 * 1 px = 1 / 144 polegada
 * </pre>
 *
 * <p>
 * Este modelo garante consistência entre layout, imagens e espaçamentos.
 */
public enum Unit {

	/** Ponto (pt), unidade base do motor. */
	POINT(1f),

	/** Polegada (inch). */
	INCH(72f),

	/** Centímetro (cm). */
	CM(72f / 2.54f),

	/** Milímetro (mm). */
	MM(72f / 25.4f),

	/** Pixel lógico (px), baseado em 144 DPI. */
	PX(72f / 144f);

	private final float toPoints;

	Unit(float toPoints) {
		this.toPoints = toPoints;
	}

	/**
	 * Converte um valor desta unidade para pontos (pt).
	 */
	public float toPoints(float value) {
		return value * toPoints;
	}

	/**
	 * Converte um valor em pontos (pt) para esta unidade.
	 */
	public float fromPoints(float points) {
		return points / toPoints;
	}
}
