package com.example.common.report.api.core;

import com.example.common.report.format.ReportFormat;

public interface FormatOptions<O extends FormatOptions<O>> {
	ReportFormat<O> getFormat();
}
