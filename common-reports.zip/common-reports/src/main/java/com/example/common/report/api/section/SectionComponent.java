package com.example.common.report.api.section;

import java.util.Objects;

import com.example.common.report.api.measure.Measure;
import com.example.common.report.api.style.CellStyle;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

public sealed interface SectionComponent permits
	SectionComponent.StaticTextContent,
	SectionComponent.DynamicTextContext,
	SectionComponent.ImageContent {

	@NullMarked
	record StaticTextContent(
		String text,
		@Nullable CellStyle style
	) implements SectionComponent {
		public StaticTextContent {
			Objects.requireNonNull(text, "text must not be null");
		}
	}

	@NullMarked
	record DynamicTextContext(
		String pattern,
		@Nullable CellStyle style
	) implements SectionComponent {
		public DynamicTextContext {
			Objects.requireNonNull(pattern, "pattern must not be null");
		}
	}

	@NullMarked
	record ImageContent(
		String resourcePath,
		Measure width,
		Measure height
	) implements SectionComponent {
		public ImageContent {
			Objects.requireNonNull(resourcePath, "resourcePath must not be null");
			Objects.requireNonNull(width, "width must not be null");
			Objects.requireNonNull(height, "height must not be null");
		}
	}
}
