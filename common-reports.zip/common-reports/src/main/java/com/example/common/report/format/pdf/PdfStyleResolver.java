package com.example.common.report.format.pdf;

import com.example.common.report.api.layout.Alignment;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.api.style.ColorValue;
import com.example.common.report.api.style.FontResource;
import com.example.common.report.format.pdf.context.PdfCellStyle;
import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.colors.DeviceRgb;
import com.itextpdf.layout.properties.TextAlignment;
import lombok.val;

final class PdfStyleResolver {
	private final PdfFontResolver fontResolver = new PdfFontResolver();
	private final PdfReportOptions options;
	private final PdfCellStyle baseStyle;

	PdfStyleResolver(PdfReportOptions options) {
		this.options = options;
		this.baseStyle = new PdfCellStyle(
			fontResolver.resolve(null, options.defaultFontName(), false, false),
			options.defaultFontSize(),
			Boolean.FALSE,
			Boolean.FALSE,
			new DeviceRgb(0, 0, 0),
			null,
			TextAlignment.LEFT,
			Boolean.TRUE
		);
	}

	PdfCellStyle baseStyle() {
		return baseStyle;
	}

	PdfCellStyle resolve(CellStyle style) {
		if (style == null) return null;
		val fontResource = style.font();
		val bold = resolveBold(style, fontResource);
		val italic = resolveItalic(style, fontResource);
		val font = fontResolver.resolve(fontResource, options.defaultFontName(), bold, italic);

		return new PdfCellStyle(
			font,
			style.fontSize() != null ? style.fontSize() : options.defaultFontSize(),
			bold,
			italic,
			toColor(style.textColor()),
			toColor(style.backgroundColor()),
			toAlignment(style.alignment()),
			style.border()
		);
	}

	private static boolean resolveBold(CellStyle style, FontResource fontResource) {
		if (style.bold() != null) return style.bold();
		return fontResource != null && fontResource.bold();
	}

	private static boolean resolveItalic(CellStyle style, FontResource fontResource) {
		if (style.italic() != null) return style.italic();
		return fontResource != null && fontResource.italic();
	}

	private static Color toColor(ColorValue value) {
		if (value == null) return null;
		return new DeviceRgb(value.red(), value.green(), value.blue());
	}

	private static TextAlignment toAlignment(Alignment alignment) {
		if (alignment == null) return null;
		return switch (alignment) {
			case LEFT -> TextAlignment.LEFT;
			case CENTER -> TextAlignment.CENTER;
			case RIGHT -> TextAlignment.RIGHT;
		};
	}
}
