package com.example.common.report.format.pdf.section;

import java.util.List;

import com.example.common.report.format.pdf.section.components.PdfSectionComponent;
import com.example.common.report.format.pdf.style.PdfCellStyle;
import org.jspecify.annotations.NullMarked;

@NullMarked
public record PdfSectionSlot(
	PdfCellStyle slotStyle,
	List<PdfSectionComponent> components
) {
	private PdfSectionSlot(PdfCellStyle slotStyle) {
		this(slotStyle, List.of());
	}

	public static PdfSectionSlot empty(PdfCellStyle pdfCellStyle) { return new PdfSectionSlot(pdfCellStyle); }
}