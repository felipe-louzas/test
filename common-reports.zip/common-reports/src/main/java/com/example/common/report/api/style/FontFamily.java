package com.example.common.report.api.style;

import java.util.List;
import java.util.Objects;

import lombok.Builder;
import lombok.Singular;
import org.apache.commons.lang3.ObjectUtils;

public sealed interface FontFamily permits StandardFonts, FontFamily.CustomFontFamily {
	static CustomFontFamily.CustomFontFamilyBuilder builder() {
		return CustomFontFamily.builder();
	}

	String familyName();

	List<FontResource> fonts();

	@Builder
	record CustomFontFamily(
		String familyName,
		@Singular
		List<FontResource> fonts
	) implements FontFamily {
		public CustomFontFamily {
			Objects.requireNonNull(familyName, "Font name cannot be null");
			if (ObjectUtils.isEmpty(fonts))
				throw new IllegalArgumentException("Font resource list must not be empty");
		}
	}
}

