package com.example.common.report.format.pdf.writer;

import java.util.HashSet;
import java.util.Set;
import java.util.function.IntConsumer;

import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;

@Getter
@RequiredArgsConstructor(access = AccessLevel.PACKAGE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfWriterContext {
	CompiledPdfReport compiledReport;
	PdfDocument pdfDocument;
	Document document;

	@Getter(AccessLevel.NONE)
	Set<IntConsumer> reportEndCallbacks = new HashSet<>();

	@NonFinal
	int lastPage = -1; // Unknown

	public void registerReportEndCallback(IntConsumer callback) {
		if (callback == null)
			return;
		reportEndCallbacks.add(callback);
	}

	public void onReportEnd() {
		lastPage = pdfDocument.getNumberOfPages();
		reportEndCallbacks.forEach(cb -> cb.accept(lastPage));
	}

	public boolean isLastPage(int pageNumber) {
		if (lastPage < 0) {
			// Last page is not known yet, assume it's not the last page
			return false;
		}
		return pageNumber == lastPage;
	}
}
