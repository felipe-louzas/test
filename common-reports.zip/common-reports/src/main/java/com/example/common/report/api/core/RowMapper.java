package com.example.common.report.api.core;

@FunctionalInterface
public interface RowMapper<T> {
    Object getValue(T row, String columnKey);
}
