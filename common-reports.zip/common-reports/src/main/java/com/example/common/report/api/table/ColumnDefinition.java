package com.example.common.report.api.table;

import java.util.Objects;

import com.example.common.report.api.style.CellStyle;
import lombok.Builder;

@Builder
public record ColumnDefinition(
	String key,
	String header,
	int width,
	CellStyle style
) {
	public ColumnDefinition {
		Objects.requireNonNull(key, "key must not be null");
		header = Objects.requireNonNullElse(header, key);
		if (width < 0)
			throw new IllegalArgumentException("width must be non-negative");
	}
}
