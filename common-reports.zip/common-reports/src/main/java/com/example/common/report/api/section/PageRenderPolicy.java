package com.example.common.report.api.section;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.jspecify.annotations.NullMarked;

@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public enum PageRenderPolicy {
	ALL_PAGES,
	FIRST_PAGE,
	INNER_PAGES,
	LAST_PAGE,
	EVEN_PAGES,
	ODD_PAGES
}
