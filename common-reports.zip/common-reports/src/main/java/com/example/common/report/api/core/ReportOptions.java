package com.example.common.report.api.core;

import java.time.ZoneId;
import java.util.Locale;

public record ReportOptions(
	Locale locale,
	ZoneId zoneId
) {}
