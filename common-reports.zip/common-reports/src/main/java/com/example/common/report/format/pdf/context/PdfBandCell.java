package com.example.common.report.format.pdf.context;

import com.itextpdf.io.image.ImageData;
import com.itextpdf.layout.properties.TextAlignment;

public interface PdfBandCell {

	sealed interface PdfBandComponentPlan permits TextComponentPlan, PageNumberComponentPlan, ImageComponentPlan {
		PdfCellStyle style();

		TextAlignment alignment();
	}


	record TextComponentPlan(String text, PdfCellStyle style, TextAlignment alignment) implements PdfBandComponentPlan {}

	record PageNumberComponentPlan(String pattern, PdfCellStyle style, TextAlignment alignment) implements PdfBandComponentPlan {}

	record ImageComponentPlan(ImageData imageData, float width, float height, PdfCellStyle style,
	                          TextAlignment alignment) implements PdfBandComponentPlan {}

}
