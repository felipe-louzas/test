package com.example.common.report.format.pdf.section;

public enum PdfSectionType {
	PAGE_HEADER,
	PAGE_FOOTER,
	CONTENT_HEADER,
	CONTENT_FOOTER;

	public boolean isHeader() {
		return this == PAGE_HEADER || this == CONTENT_HEADER;
	}

	public boolean isFooter() {
		return this == PAGE_FOOTER || this == CONTENT_FOOTER;
	}

	public boolean isPageSection() {
		return this == PAGE_HEADER || this == PAGE_FOOTER;
	}

	public boolean isContentSection() {
		return this == CONTENT_HEADER || this == CONTENT_FOOTER;
	}
}
