package com.example.common.report.api.style.format;

public enum NegativeNumberStyle {
    MINUS,
    PARENTHESES
}