package com.example.common.report.format.pdf.section.components;

import java.util.Objects;

import com.example.common.report.format.pdf.writer.PdfWriterContext;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.kernel.colors.ColorConstants;
import com.itextpdf.layout.borders.SolidBorder;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Image;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.properties.TextAlignment;
import com.itextpdf.layout.properties.VerticalAlignment;
import lombok.Builder;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Builder
@NullMarked
public record PdfImageComponent(
	@Nullable ImageData imageData,
	@Nullable String altText,
	float width,
	float height
) implements PdfSectionComponent {

	@Override
	public void render(Cell cell, PdfWriterContext context) {
		if (imageData == null) {
			val placeholder = createPlaceholder();
			cell.add(placeholder);
			return;
		}

		val image = new Image(imageData);
		image.setWidth(width);
		image.setHeight(height);
		image.setAutoScale(false);
		cell.add(image);
	}

	private Cell createPlaceholder() {
		val placeholder = new Cell();
		placeholder.setBackgroundColor(ColorConstants.LIGHT_GRAY);
		placeholder.setBorder(new SolidBorder(ColorConstants.GRAY, 0.5f));
		placeholder.setWidth(width);
		placeholder.setHeight(height);

		val label = new Paragraph(Objects.requireNonNullElse(altText, "[Imagem]"))
			.setFontSize(8)
			.setFontColor(ColorConstants.DARK_GRAY)
			.setTextAlignment(TextAlignment.CENTER);
		placeholder.add(label);

		placeholder.setVerticalAlignment(VerticalAlignment.MIDDLE);
		placeholder.setTextAlignment(TextAlignment.CENTER);

		return placeholder;
	}

}