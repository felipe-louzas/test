package com.example.common.report.format.text;

import java.io.OutputStream;

import com.example.utils.fluent.Fluent;
import com.example.utils.strings.Strings;
import com.univocity.parsers.common.CommonSettings;
import com.univocity.parsers.csv.CsvWriter;
import com.univocity.parsers.csv.CsvWriterSettings;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import lombok.val;

@Slf4j
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class UnivocityRowWriter implements RowWriter {
	CsvWriter writer;

	public UnivocityRowWriter(OutputStream outputStream, TextReportOptions options) {
		val settings = new CsvWriterSettings();

		Fluent.of(settings)
			.apply(Strings.EMPTY, s -> s::setNullValue)
			.apply(Strings.EMPTY, s -> s::setEmptyValue)
			.apply(false, s -> s::setSkipEmptyLines)
			.map(CommonSettings::getFormat)
			.apply(options.delimiter(), f -> f::setDelimiter)
			.apply(options.quote(), f -> f::setQuote)
			.apply(options.escape(), f -> f::setQuoteEscape)
			.apply(options.lineSeparator(), f -> f::setLineSeparator);

		this.writer = new CsvWriter(outputStream, options.charset(), settings);
	}

	@Override
	public void writeHeader(String[] values) {
		writer.writeHeaders(values);
	}

	@Override
	public void writeRow(String[] values) {
		writer.writeRow(values);
	}

	@Override
	public void flush() {
		writer.flush();
	}

	@Override
	public void close() {
		try {
			writer.close();
		} catch (Exception ex) {
			log.warn("Failed to close UnivocityRowWriter: {}", ex.getMessage(), ex);
		}
	}
}
