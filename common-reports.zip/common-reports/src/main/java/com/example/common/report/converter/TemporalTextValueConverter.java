package com.example.common.report.converter;

import java.time.ZoneId;
import java.time.chrono.Chronology;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.TemporalAccessor;
import java.util.Locale;
import java.util.Objects;

import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.style.format.DateTimeFormat;
import com.example.common.report.api.style.format.DateTimeStandard;
import com.example.utils.datetime.TimeZones;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@NullMarked
@RequiredArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class TemporalTextValueConverter {
	DateTimeFormatter formatter;
	ZoneId zoneId;

	public static TemporalTextValueConverter of(DateTimeFormat format, ReportOptions reportOptions) {
		val locale = Objects.requireNonNullElse(reportOptions.locale(), Locale.getDefault());
		val zoneId = Objects.requireNonNullElse(reportOptions.zoneId(), ZoneId.systemDefault());

		final DateTimeFormatter formatter;
		if (format.getStandard() == DateTimeStandard.ISO) {
			formatter = buildIsoFormatter(format);
		} else {
			formatter = buildLocalizedFormatter(format, locale);
		}

		return new TemporalTextValueConverter(formatter, zoneId);
	}

	private static DateTimeFormatter buildIsoFormatter(DateTimeFormat format) {
		return switch (format.getTemporalKind()) {
			case DATE -> DateTimeFormatter.ISO_LOCAL_DATE;
			case TIME -> DateTimeFormatter.ISO_LOCAL_TIME;
			case DATETIME -> DateTimeFormatter.ISO_LOCAL_DATE_TIME;
		};
	}

	private static DateTimeFormatter buildLocalizedFormatter(DateTimeFormat format, Locale locale) {
		val pattern = DateTimeFormatterBuilder.getLocalizedDateTimePattern(
			format.getDateStyle(),
			format.getTimeStyle(),
			Chronology.ofLocale(locale),
			locale
		);

		return DateTimeFormatter.ofPattern(pattern, locale);
	}

	public String convert(TemporalAccessor temporal) {
		try {
			val atTimeZone = TimeZones.atTimeZone(temporal, zoneId);
			return formatter.format(atTimeZone);
		} catch (Exception ex) {
			return temporal.toString();
		}
	}
}
