package com.example.common.report.engine;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.format.ReportFormat;

public interface ReportBuilder<O extends FormatOptions<O>> {
	ReportWriter buildReport(ReportTemplate template, O reportOptions, ReportEngineOptions engineOptions) throws ReportException;

	ReportFormat<O> getFormat();

	O getDefaultOptions();
}