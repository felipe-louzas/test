package com.example.common.report.engine;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.format.ReportFormat;

public interface ReportBuilder<O extends FormatOptions<O>> {
	ReportWriter buildReport(ReportTemplate template, O options, ReportOptions reportOptions);

	ReportFormat<O> getFormat();

	O getDefaultOptions();
}