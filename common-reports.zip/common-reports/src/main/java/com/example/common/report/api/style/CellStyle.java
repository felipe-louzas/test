package com.example.common.report.api.style;

import com.example.common.report.api.layout.Alignment;
import com.example.common.report.api.style.format.TextFormat;
import lombok.Builder;

@Builder
public record CellStyle(
	FontResource font,
	Float fontSize,
	Boolean bold,
	Boolean italic,
	ColorValue textColor,
	ColorValue backgroundColor,
	Boolean border,
	Alignment alignment,
	TextFormat format
) {
}
