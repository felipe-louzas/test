package com.example.common.report.api.style;

import com.example.common.report.api.layout.HorizontalAlignment;
import com.example.common.report.api.layout.VerticalAlignment;
import lombok.Builder;

@Builder
public record CellStyle(
	FontFamily font,
	Float fontSize,
	Boolean bold,
	Boolean italic,
	ColorValue textColor,
	ColorValue backgroundColor,
	Boolean border,
	HorizontalAlignment horizontalAlignment,
	VerticalAlignment verticalAlignment
) {
	public static final CellStyle DEFAULT = CellStyle.builder()
		.font(StandardFonts.SANS_SERIF)
		.fontSize(10f)
		.bold(false)
		.italic(false)
		.textColor(ColorValue.BLACK)
		.backgroundColor(ColorValue.WHITE)
		.border(false)
		.horizontalAlignment(HorizontalAlignment.LEFT)
		.verticalAlignment(VerticalAlignment.CENTER)
		.build();
}
