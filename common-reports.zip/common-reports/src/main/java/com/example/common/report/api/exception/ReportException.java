package com.example.common.report.api.exception;

import lombok.experimental.StandardException;

@StandardException
public class ReportException extends Exception {}
