package com.example.common.report.api.style;

public record ColorValue(
	int red,
	int green,
	int blue
) {
	public static ColorValue BLACK = new ColorValue(0, 0, 0);
	public static ColorValue WHITE = new ColorValue(255, 255, 255);

	public static ColorValue hex(int hexValue) {
		return new ColorValue(
			(hexValue >> 16) & 0xFF,
			(hexValue >> 8) & 0xFF,
			hexValue & 0xFF
		);
	}

	public static ColorValue rgb(int r, int g, int b) {
		return new ColorValue(r, g, b);
	}
}
