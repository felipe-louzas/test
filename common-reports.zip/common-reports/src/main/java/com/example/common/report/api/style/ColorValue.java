package com.example.common.report.api.style;

public record ColorValue(
    int red,
    int green,
    int blue
) {
    public static ColorValue rgb(int r, int g, int b) {
        return new ColorValue(r, g, b);
    }
}
