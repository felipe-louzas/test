package com.example.common.report.format.pdf.style;

import com.itextpdf.layout.element.Paragraph;

@FunctionalInterface
public interface PdfCellTextStyler {
	void apply(Paragraph paragraph, boolean alternate);
}
