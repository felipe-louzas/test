package com.example.common.report.format.pdf;

import java.util.Objects;

import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.layout.PageSizes;
import com.example.common.report.api.measure.Measure;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import lombok.Builder;

@Builder
public record PdfReportOptions(
	Boolean includeHeader,
	Float defaultFontSize,
	String defaultFontName,
	PageDefinition defaultPage
) implements FormatOptions<PdfReportOptions> {
	public PdfReportOptions {
		includeHeader = Objects.requireNonNullElse(includeHeader, Boolean.TRUE);
		defaultFontSize = Objects.requireNonNullElse(defaultFontSize, 10.0f);
		defaultFontName = Objects.requireNonNullElse(defaultFontName, "Helvetica");
		defaultPage = Objects.requireNonNullElseGet(defaultPage, PdfReportOptions::defaultPageDefinition);
	}

	public static PdfReportOptions defaultOptions() {
		return PdfReportOptions.builder().build();
	}

	@Override
	public ReportFormat<PdfReportOptions> getFormat() {
		return ReportFormats.PDF;
	}

	private static PageDefinition defaultPageDefinition() {
		return PageDefinition.builder()
			.size(PageSizes.A4.portrait())
			.marginTop(Measure.mm(15))
			.marginRight(Measure.mm(15))
			.marginBottom(Measure.mm(15))
			.marginLeft(Measure.mm(15))
			.build();
	}
}
