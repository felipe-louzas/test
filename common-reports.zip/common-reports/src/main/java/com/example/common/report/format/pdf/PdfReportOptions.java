package com.example.common.report.format.pdf;

import java.util.Objects;

import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.style.FontFamily;
import com.example.common.report.api.style.StandardFonts;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import lombok.Builder;

@Builder
public record PdfReportOptions(
	Boolean includeHeader,
	FontFamily defaultFont,
	Float defaultFontSize
) implements FormatOptions<PdfReportOptions> {
	public PdfReportOptions {
		includeHeader = Objects.requireNonNullElse(includeHeader, Boolean.TRUE);
		defaultFont = Objects.requireNonNullElse(defaultFont, StandardFonts.SANS_SERIF);
		defaultFontSize = Objects.requireNonNullElse(defaultFontSize, 10.0f);
	}

	public static PdfReportOptions defaultOptions() {
		return PdfReportOptions.builder().build();
	}

	@Override
	public ReportFormat<PdfReportOptions> getFormat() {
		return ReportFormats.PDF;
	}
}
