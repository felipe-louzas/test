package com.example.common.report.api.layout;

public enum VerticalAlignment {
    TOP, CENTER, BOTTOM
}