package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;
import com.example.common.report.api.measure.Unit;
import lombok.Builder;

@Builder
public record PageDefinition(
	PageSize size,
	PageMargins margins
) {
	public static final PageDefinition DEFAULT_PAGE_DEFINITION = PageDefinition.builder()
		.size(PageSizes.A4.portrait())
		.margins(PageMargins.builder()
			.top(Measure.mm(15))
			.bottom(Measure.mm(15))
			.right(Measure.mm(15))
			.left(Measure.mm(15))
			.build())
		.build();

	public float contentHeight(Unit unit) {
		return size.height().in(unit) - margins.top().in(unit) - margins.bottom().in(unit);
	}

	public float contentWidth(Unit unit) {
		return size.width().in(unit) - margins.left().in(unit) - margins.right().in(unit);
	}
}
