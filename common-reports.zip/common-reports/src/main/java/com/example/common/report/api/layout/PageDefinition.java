package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;
import com.example.common.report.api.measure.Unit;
import lombok.Builder;

@Builder
public record PageDefinition(
	PageSize size,
	Measure marginTop,
	Measure marginRight,
	Measure marginBottom,
	Measure marginLeft
) {
	public float contentWidth(Unit unit) {
		return size.width().in(unit) - marginLeft.in(unit) - marginRight.in(unit);
	}

	public float contentHeight(Unit unit) {
		return size.height().in(unit) - marginTop.in(unit) - marginBottom.in(unit);
	}
}
