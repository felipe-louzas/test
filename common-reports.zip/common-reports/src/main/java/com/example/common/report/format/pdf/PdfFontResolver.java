package com.example.common.report.format.pdf;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.example.common.report.api.style.FontResource;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;
import com.itextpdf.kernel.font.PdfFontFactory.EmbeddingStrategy;
import com.itextpdf.io.font.constants.StandardFonts;
import lombok.val;

final class PdfFontResolver {
	private final Map<String, PdfFont> cache = new ConcurrentHashMap<>();

	PdfFont resolve(FontResource fontResource, String defaultFontName, boolean bold, boolean italic) {
		if (fontResource != null) {
			val resourcePath = fontResource.resourcePath();
			if (resourcePath != null && !resourcePath.isBlank()) {
				return cache.computeIfAbsent("res:" + resourcePath, key -> loadResourceFont(resourcePath));
			}
			val named = fontResource.name();
			if (named != null && !named.isBlank()) {
				return cache.computeIfAbsent(fontKey(named, bold, italic), key -> loadNamedFont(named, bold, italic));
			}
		}

		return cache.computeIfAbsent(fontKey(defaultFontName, bold, italic), key -> loadNamedFont(defaultFontName, bold, italic));
	}

	private static String fontKey(String name, boolean bold, boolean italic) {
		return name + "|" + bold + "|" + italic;
	}

	private PdfFont loadNamedFont(String name, boolean bold, boolean italic) {
		try {
			val standard = resolveStandardFont(name, bold, italic);
			if (standard != null)
				return PdfFontFactory.createFont(standard);
			return PdfFontFactory.createFont(name, PdfEncodings.IDENTITY_H, EmbeddingStrategy.PREFER_EMBEDDED);
		} catch (IOException ex) {
			throw new IllegalArgumentException("Erro ao carregar fonte: " + name, ex);
		}
	}

	private PdfFont loadResourceFont(String resourcePath) {
		try (InputStream stream = PdfFontResolver.class.getResourceAsStream(resourcePath)) {
			if (stream == null) {
				throw new IllegalArgumentException("Fonte nao encontrada no recurso: " + resourcePath);
			}
			val bytes = stream.readAllBytes();
			return PdfFontFactory.createFont(bytes, PdfEncodings.IDENTITY_H, EmbeddingStrategy.PREFER_EMBEDDED);
		} catch (IOException ex) {
			throw new IllegalArgumentException("Erro ao carregar fonte do recurso: " + resourcePath, ex);
		}
	}

	private static String resolveStandardFont(String name, boolean bold, boolean italic) {
		val normalized = name == null ? "" : name.trim();
		if (normalized.equalsIgnoreCase(StandardFonts.HELVETICA) || normalized.equalsIgnoreCase("Helvetica")) {
			if (bold && italic) return StandardFonts.HELVETICA_BOLDOBLIQUE;
			if (bold) return StandardFonts.HELVETICA_BOLD;
			if (italic) return StandardFonts.HELVETICA_OBLIQUE;
			return StandardFonts.HELVETICA;
		}
		if (normalized.equalsIgnoreCase(StandardFonts.TIMES_ROMAN) || normalized.equalsIgnoreCase("Times-Roman") || normalized.equalsIgnoreCase("Times")) {
			if (bold && italic) return StandardFonts.TIMES_BOLDITALIC;
			if (bold) return StandardFonts.TIMES_BOLD;
			if (italic) return StandardFonts.TIMES_ITALIC;
			return StandardFonts.TIMES_ROMAN;
		}
		if (normalized.equalsIgnoreCase(StandardFonts.COURIER) || normalized.equalsIgnoreCase("Courier")) {
			if (bold && italic) return StandardFonts.COURIER_BOLDOBLIQUE;
			if (bold) return StandardFonts.COURIER_BOLD;
			if (italic) return StandardFonts.COURIER_OBLIQUE;
			return StandardFonts.COURIER;
		}
		return null;
	}
}
