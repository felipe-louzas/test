package com.example.common.report.api.core;

import java.time.ZoneId;
import java.util.Locale;

public record ReportEngineOptions(
	Locale locale,
	ZoneId zoneId
) {}
