package com.example.common.report.api.style;

import java.util.List;

import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.Accessors;
import lombok.experimental.FieldDefaults;

@Getter
@Accessors(fluent = true)
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public enum StandardFonts implements FontFamily {
	SANS_SERIF("SansSerif"),
	SERIF("Serif"),
	MONOSPACE("Monospace");

	String familyName;
	List<FontResource> fonts = null;
}
