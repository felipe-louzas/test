package com.example.common.report.api.style.format;

public enum DateTimeStandard {
    LOCALIZED,
    ISO
}