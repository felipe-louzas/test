package com.example.common.report.format.pdf.writer;

import com.example.common.report.format.pdf.PdfReportOptions;
import com.example.common.report.format.pdf.section.PdfReportSections;
import com.example.common.report.format.pdf.table.PdfTable;
import lombok.Builder;

@Builder
public record CompiledPdfReport(
	PdfReportOptions reportOptions,
	PdfPageMetrics pageMetrics,
	PdfTable table,
	PdfReportSections sections
) {}
