package com.example.common.report.api.table;

import com.example.common.report.api.style.CellStyle;
import lombok.Builder;

import java.util.List;

@Builder
public record TableDefinition(
    List<ColumnDefinition> columns,
    CellStyle headerStyle,
    CellStyle rowStyle,
    CellStyle alternateRowStyle
) {
    public int columnCount() {
        return columns.size();
    }
}
