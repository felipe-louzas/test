package com.example.common.report.api.table;

import java.util.List;

import com.example.common.report.api.style.CellStyle;
import lombok.Builder;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@NullMarked
@Builder
public record TableDefinition(
	List<ColumnDefinition> columns,
	@Nullable CellStyle headerStyle,
	@Nullable CellStyle rowStyle,
	@Nullable CellStyle altRowStyle
) {
	public int columnCount() {
		return columns.size();
	}
}
