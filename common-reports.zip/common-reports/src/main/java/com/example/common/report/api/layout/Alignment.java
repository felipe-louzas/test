package com.example.common.report.api.layout;

public enum Alignment {
    LEFT,
    CENTER,
    RIGHT
}