package com.example.common.report.api.section;

import java.util.Map;
import java.util.Objects;

import com.example.common.report.api.measure.Measure;
import lombok.Builder;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Builder
@NullMarked
public record SectionRow(
	Measure height,
	PageRenderPolicy pageRenderPolicy,
	@Nullable Map<SectionSlot, @Nullable SectionSlotDefinition> content
) {
	public SectionRow {
		Objects.requireNonNull(height, "height must not be null");
	}
}
