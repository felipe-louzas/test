package com.example.common.report.format.pdf.section;

import java.util.ArrayList;
import java.util.EnumMap;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.api.layout.HorizontalAlignment;
import com.example.common.report.api.section.Section;
import com.example.common.report.api.section.SectionComponent;
import com.example.common.report.api.section.SectionRow;
import com.example.common.report.api.section.SectionSlot;
import com.example.common.report.api.section.SectionSlotDefinition;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.format.pdf.section.components.PdfImageLoader;
import com.example.common.report.format.pdf.section.components.PdfSectionComponent;
import com.example.common.report.format.pdf.style.PdfStyleResolver;
import com.example.common.report.format.pdf.writer.PdfPageMetrics;
import com.itextpdf.layout.element.Paragraph;
import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.ObjectUtils;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Slf4j
@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfSectionCompiler {
	PdfStyleResolver styleResolver;
	PdfPageMetrics pageMetrics;

	public PdfReportSections compile(ReportTemplate template) throws ReportException {
		return PdfReportSections.builder()
			.pageHeader(compileSection(PdfSectionType.PAGE_HEADER, template.pageHeader()))
			.pageFooter(compileSection(PdfSectionType.PAGE_FOOTER, template.pageFooter()))
			.contentHeader(compileSection(PdfSectionType.CONTENT_HEADER, template.contentHeader()))
			.contentFooter(compileSection(PdfSectionType.CONTENT_FOOTER, template.contentFooter()))
			.build();
	}

	private @Nullable PdfSection compileSection(PdfSectionType sectionType, @Nullable Section section) throws ReportException {
		if (section == null || ObjectUtils.isEmpty(section.rows())) {
			return null;
		}

		val rows = new ArrayList<PdfSectionRow>(section.rows().size());
		for (val row : section.rows()) {
			rows.add(compileRow(row));
		}

		return new PdfSection(sectionType, rows, pageMetrics);
	}

	private PdfSectionRow compileRow(SectionRow row) throws ReportException {
		val slots = new EnumMap<SectionSlot, @Nullable PdfSectionSlot>(SectionSlot.class);

		val content = row.content();
		if (content != null) {
			for (val slot : SectionSlot.values()) {
				val slotDefinition = row.content().get(slot);
				if (slotDefinition != null) {
					slots.put(slot, compileSlot(slot, slotDefinition));
				}
			}
		}

		return PdfSectionRow.builder()
			.height(row.height().points())
			.pageRenderPolicy(row.pageRenderPolicy())
			.left(slots.get(SectionSlot.LEFT))
			.center(slots.get(SectionSlot.CENTER))
			.right(slots.get(SectionSlot.RIGHT))
			.build();
	}

	private PdfSectionSlot compileSlot(SectionSlot slot, SectionSlotDefinition slotDef) throws ReportException {
		val slotStyle = styleResolver.resolveStyle(slotDef.style(), getDefaultSlotStyle(slot));

		if (ObjectUtils.isEmpty(slotDef.components()))
			return PdfSectionSlot.empty(slotStyle);

		val components = new ArrayList<PdfSectionComponent>(slotDef.components().size());
		for (val component : slotDef.components()) {
			val compiled = compileComponent(component, slotDef.style());
			if (compiled == null) continue;
			components.add(compiled);
		}

		return new PdfSectionSlot(slotStyle, components);
	}

	private CellStyle getDefaultSlotStyle(SectionSlot slot) {
		return switch (slot) {
			case LEFT -> CellStyle.builder().horizontalAlignment(HorizontalAlignment.LEFT).build();
			case CENTER -> CellStyle.builder().horizontalAlignment(HorizontalAlignment.CENTER).build();
			case RIGHT -> CellStyle.builder().horizontalAlignment(HorizontalAlignment.RIGHT).build();
		};
	}

	@Nullable
	private PdfSectionComponent compileComponent(SectionComponent component, @Nullable CellStyle baseStyle) throws ReportException {
		if (component instanceof SectionComponent.ImageContent image) {
			return compileImage(image, baseStyle);

		} else if (component instanceof SectionComponent.StaticTextContent text) {
			return compileText(text, baseStyle);

		} /*else if (component instanceof SectionComponent.DynamicTextContext dynamic) {
			return PdfDynamicTextComponent.of(dynamic.pattern(), styleResolver.resolveStyle(dynamic.style(), baseStyle));
		} */

		log.warn("Unsupported section component type: {}", component.getClass().getName());
		return null;
	}

	private PdfSectionComponent compileImage(SectionComponent.ImageContent content, @Nullable CellStyle baseStyle) throws ReportException {
		val resourcePath = content.resourcePath();
		return styleResolver.withResource(resourcePath, inputStream -> PdfImageLoader.loadImageData(
			resourcePath,
			inputStream,
			content.width(),
			content.height(),
			baseStyle
		));
	}

	private PdfSectionComponent compileText(SectionComponent.StaticTextContent content, @Nullable CellStyle baseStyle) throws ReportException {
		val resolvedStyle = styleResolver.resolveStyle(content.style(), baseStyle);

		return (cell, context) -> {
			val paragraph = new Paragraph(content.text());
			resolvedStyle.applyTextStyle(paragraph);
			cell.add(paragraph);
		};
	}
}
