package com.example.common.report.converter;

import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.style.format.DateTimeFormat;
import com.example.common.report.api.style.format.NumericFormat;
import com.example.common.report.api.style.format.TextFormat;
import com.example.utils.strings.Strings;
import lombok.experimental.UtilityClass;
import lombok.val;

import java.time.temporal.TemporalAccessor;

@UtilityClass
public class TextValueConverters {
    public ValueConverter<String> forStyle(TextFormat format, ReportEngineOptions reportEngineOptions) {
        if (format instanceof NumericFormat nf)
            return numberConverter(nf, reportEngineOptions);

        if (format instanceof DateTimeFormat df)
            return dateTimeConverter(df, reportEngineOptions);

        return defaultConverter(reportEngineOptions);
    }

    private ValueConverter<String> defaultConverter(ReportEngineOptions reportEngineOptions) {
        val defaultNumberConverter = numberConverter(NumericFormat.DEFAULT_FORMAT, reportEngineOptions);
        val defaultDateTimeConverter = dateTimeConverter(DateTimeFormat.DEFAULT_FORMAT, reportEngineOptions);

        return value -> {
            if (value == null) return Strings.EMPTY;

            if (value instanceof Number number)
                return defaultNumberConverter.convert(number);

            val temporal = normalizeTemporal(value);

            return temporal != null ?
                    defaultDateTimeConverter.convert(temporal) :
                    value.toString();
        };
    }

    private ValueConverter<String> numberConverter(NumericFormat format, ReportEngineOptions reportEngineOptions) {
        val converter = NumericTextValueConverter.of(format, reportEngineOptions);

        return value -> {
            if (value == null) return Strings.EMPTY;
            if (value instanceof Number number)
                return converter.convert(number);
            return value.toString();
        };
    }

    private ValueConverter<String> dateTimeConverter(DateTimeFormat format, ReportEngineOptions reportEngineOptions) {
        val converter = TemporalTextValueConverter.of(format, reportEngineOptions);

        return value -> {
            if (value == null) return Strings.EMPTY;
            val temporal = normalizeTemporal(value);
            if (temporal != null) {
                return converter.convert(temporal);
            }
            return value.toString();
        };
    }

    private static TemporalAccessor normalizeTemporal(Object value) {
        if (value == null) return null;
        else if (value instanceof TemporalAccessor temporal) return temporal;
        else if (value instanceof java.sql.Date date) return date.toLocalDate();
        else if (value instanceof java.sql.Time time) return time.toLocalTime();
        else if (value instanceof java.util.Date date) return date.toInstant();
        else if (value instanceof java.util.Calendar calendar) return calendar.toInstant();
        else return null;
    }

}
