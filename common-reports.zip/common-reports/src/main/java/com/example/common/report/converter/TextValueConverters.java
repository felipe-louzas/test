package com.example.common.report.converter;

import java.time.temporal.TemporalAccessor;

import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.api.style.format.DateTimeFormat;
import com.example.common.report.api.style.format.NumericFormat;
import com.example.utils.fluent.Fluent;
import com.example.utils.strings.Strings;
import lombok.experimental.UtilityClass;
import lombok.val;

@UtilityClass
public class TextValueConverters {
	public ValueConverter<String> forStyle(CellStyle style, ReportOptions reportOptions) {
		val format = Fluent.of(style)
			.map(CellStyle::format)
			.orElse(null);

		if (format instanceof NumericFormat nf)
			return numberConverter(nf, reportOptions);

		if (format instanceof DateTimeFormat df)
			return dateTimeConverter(df, reportOptions);

		return defaultConverter(reportOptions);
	}

	private ValueConverter<String> defaultConverter(ReportOptions reportOptions) {
		val defaultNumberConverter = numberConverter(NumericFormat.DEFAULT_FORMAT, reportOptions);
		val defaultDateTimeConverter = dateTimeConverter(DateTimeFormat.DEFAULT_FORMAT, reportOptions);

		return value -> {
			if (value == null) return Strings.EMPTY;

			if (value instanceof Number number)
				return defaultNumberConverter.convert(number);

			val temporal = normalizeTemporal(value);

			return temporal != null ?
				defaultDateTimeConverter.convert(temporal) :
				value.toString();
		};
	}

	private ValueConverter<String> numberConverter(NumericFormat format, ReportOptions reportOptions) {
		val converter = NumericTextValueConverter.of(format, reportOptions);

		return value -> {
			if (value == null) return Strings.EMPTY;
			if (value instanceof Number number)
				return converter.convert(number);
			return value.toString();
		};
	}

	private ValueConverter<String> dateTimeConverter(DateTimeFormat format, ReportOptions reportOptions) {
		val converter = TemporalTextValueConverter.of(format, reportOptions);

		return value -> {
			if (value == null) return Strings.EMPTY;
			val temporal = normalizeTemporal(value);
			if (temporal != null) {
				return converter.convert(temporal);
			}
			return value.toString();
		};
	}

	private static TemporalAccessor normalizeTemporal(Object value) {
		if (value == null) return null;
		else if (value instanceof TemporalAccessor temporal) return temporal;
		else if (value instanceof java.sql.Date date) return date.toLocalDate();
		else if (value instanceof java.sql.Time time) return time.toLocalTime();
		else if (value instanceof java.util.Date date) return date.toInstant();
		else if (value instanceof java.util.Calendar calendar) return calendar.toInstant();
		else return null;
	}

}
