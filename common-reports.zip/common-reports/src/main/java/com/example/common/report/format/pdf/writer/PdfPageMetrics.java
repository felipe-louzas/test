package com.example.common.report.format.pdf.writer;

import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.measure.Unit;
import com.example.common.report.api.section.PageRenderPolicyMask;
import com.example.common.report.api.section.Section;
import com.example.common.report.api.section.SectionRow;
import lombok.Builder;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Builder
@NullMarked
public record PdfPageMetrics(
	float pageHeight,
	float pageWidth,

	float marginTop,
	float marginBottom,
	float marginLeft,
	float marginRight,

	float contentWidth,

	Map<PageRenderPolicyMask, PdfSectionMetrics> sectionMetricsMap
) {

	public static PdfPageMetrics of(PageDefinition pageDefinition, ReportTemplate template) {
		val margins = pageDefinition.margins();

		return PdfPageMetrics.builder()
			.pageHeight(pageDefinition.size().height().points())
			.pageWidth(pageDefinition.size().width().points())

			.marginTop(margins.top().points())
			.marginBottom(margins.bottom().points())
			.marginLeft(margins.left().points())
			.marginRight(margins.right().points())

			.contentWidth(pageDefinition.contentWidth(Unit.POINT))

			.sectionMetricsMap(PageRenderPolicyMask.ALL_MASKS.stream()
				.collect(Collectors.toMap(Function.identity(), mask -> getSectionMetrics(mask, template))))

			.build();
	}

	private static PdfSectionMetrics getSectionMetrics(PageRenderPolicyMask policyMask, ReportTemplate template) {
		return PdfSectionMetrics.builder()
			.pageHeaderHeight(measureSectionHeight(policyMask, template.pageHeader()))
			.pageFooterHeight(measureSectionHeight(policyMask, template.pageFooter()))
			.contentHeaderHeight(measureSectionHeight(policyMask, template.contentHeader()))
			.contentFooterHeight(measureSectionHeight(policyMask, template.contentFooter()))
			.build();
	}

	private static float measureSectionHeight(PageRenderPolicyMask policyMask, @Nullable Section section) {
		float sum = 0f;
		if (section == null) return sum;

		for (SectionRow row : section.filterRows(policyMask)) {
			sum += row.height().points();
		}
		return sum;
	}

	@Nullable
	public PdfSectionMetrics getSectionMetrics(int pageNumber, boolean isLastPage) {
		val policyMask = PageRenderPolicyMask.forPageNumber(pageNumber, isLastPage);
		return sectionMetricsMap.get(policyMask);
	}

	@Nullable
	public PdfSectionMetrics getSectionMetrics(PageRenderPolicyMask mask) {
		return sectionMetricsMap.get(mask);
	}

	public float getHeaderHeight(int pageNumber, boolean isLastPage) {
		val sectionMetrics = getSectionMetrics(pageNumber, isLastPage);
		if (sectionMetrics == null) return 0f;
		return sectionMetrics.headerHeight();
	}

	public float getFooterHeight(int pageNumber, boolean isLastPage) {
		val sectionMetrics = getSectionMetrics(pageNumber, isLastPage);
		if (sectionMetrics == null) return 0f;
		return sectionMetrics.footerHeight();
	}

	public float getLastPageAdditionalFooterHeight(int pageNumber) {
		val nonLastPageMetrics = getSectionMetrics(pageNumber, false);
		val lastPageMetrics = getSectionMetrics(pageNumber, true);
		if (nonLastPageMetrics == null || lastPageMetrics == null) return 0f;
		return lastPageMetrics.footerHeight() - nonLastPageMetrics.footerHeight();
	}

	@Builder
	public record PdfSectionMetrics(
		float pageHeaderHeight,
		float pageFooterHeight,
		float contentHeaderHeight,
		float contentFooterHeight
	) {
		public float headerHeight() {
			return pageHeaderHeight + contentHeaderHeight;
		}

		public float footerHeight() {
			return pageFooterHeight + contentFooterHeight;
		}
	}
}
