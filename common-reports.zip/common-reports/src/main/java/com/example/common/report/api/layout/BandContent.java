package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;

public sealed interface BandContent
	permits BandContent.TextContent, BandContent.PageNumberContent, BandContent.ImageContent {

	record TextContent(String text) implements BandContent {}

	record PageNumberContent(String pattern) implements BandContent {}

	record ImageContent(
		String resourcePath,
		Measure width,
		Measure height
	) implements BandContent {}
}
