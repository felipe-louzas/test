package com.example.common.report.engine;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.format.ReportFormat;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@NullMarked
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class ReportEngine {

	ReportEngineOptions defaultReportEngineOptions;
	Map<ReportFormat<?>, ReportBuilder<?>> builderMap;

	public ReportEngine(List<ReportBuilder<?>> compilers, ReportEngineOptions defaultReportEngineOptions) {
		this.defaultReportEngineOptions = defaultReportEngineOptions;
		this.builderMap = compilers.stream()
			.collect(Collectors.toUnmodifiableMap(ReportBuilder::getFormat, Function.identity()));
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, ReportFormat<O> format) throws ReportException {
		return buildReport(template, format, defaultReportEngineOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, ReportFormat<O> format, ReportEngineOptions reportEngineOptions) throws ReportException {
		val compiler = getBuilder(format);
		return compiler.buildReport(template, compiler.getDefaultOptions(), reportEngineOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, O formatOptions) throws ReportException {
		return buildReport(template, formatOptions, defaultReportEngineOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, O formatOptions, ReportEngineOptions reportEngineOptions) throws ReportException {
		val compiler = getBuilder(formatOptions.getFormat());
		return compiler.buildReport(template, formatOptions, reportEngineOptions);
	}

	@SuppressWarnings("unchecked")
	private <O extends FormatOptions<O>> ReportBuilder<O> getBuilder(ReportFormat<O> format) {
		val builder = (ReportBuilder<O>) builderMap.get(format);
		if (builder == null) {
			throw new IllegalArgumentException("Nenhum builder de relatório registrado para o formato " + format.getName());
		}
		return builder;
	}
}
