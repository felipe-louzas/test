package com.example.common.report.engine;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.format.ReportFormat;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@NullMarked
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class ReportEngine {

	ReportOptions defaultReportOptions;
	Map<ReportFormat<?>, ReportBuilder<?>> builderMap;

	public ReportEngine(List<ReportBuilder<?>> compilers, ReportOptions defaultReportOptions) {
		this.defaultReportOptions = defaultReportOptions;
		this.builderMap = compilers.stream()
			.collect(Collectors.toUnmodifiableMap(ReportBuilder::getFormat, Function.identity()));
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, ReportFormat<O> format) {
		return buildReport(template, format, defaultReportOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, ReportFormat<O> format, ReportOptions reportOptions) {
		val compiler = getBuilder(format);
		return compiler.buildReport(template, compiler.getDefaultOptions(), reportOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, O formatOptions) {
		return buildReport(template, formatOptions, defaultReportOptions);
	}

	public <O extends FormatOptions<O>> ReportWriter buildReport(ReportTemplate template, O formatOptions, ReportOptions reportOptions) {
		val compiler = getBuilder(formatOptions.getFormat());
		return compiler.buildReport(template, formatOptions, reportOptions);
	}

	@SuppressWarnings("unchecked")
	private <O extends FormatOptions<O>> ReportBuilder<O> getBuilder(ReportFormat<O> format) {
		val builder = (ReportBuilder<O>) builderMap.get(format);
		if (builder == null) {
			throw new IllegalArgumentException("Nenhum builder de relatório registrado para o formato " + format.getName());
		}
		return builder;
	}
}
