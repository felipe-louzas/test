package com.example.common.report.converter;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;

import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.style.format.NegativeNumberStyle;
import com.example.common.report.api.style.format.NumericFormat;
import com.example.utils.fluent.Fluent;
import com.example.utils.strings.Strings;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@NullMarked
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class NumericTextValueConverter {
	@Nullable String prefix;
	NumberFormat decimalFormat;

	public static NumericTextValueConverter of(NumericFormat nf, ReportOptions reportOptions) {
		val locale = Objects.requireNonNullElse(reportOptions.locale(), Locale.getDefault());
		val format = NumberFormat.getNumberInstance(locale);

		if (format instanceof DecimalFormat decimalFormat) {
			Fluent.of(decimalFormat)
				.apply(nf.minFractionDigits(), f -> f::setMinimumFractionDigits)
				.apply(nf.maxFractionDigits(), f -> f::setMaximumFractionDigits)
				.apply(nf.groupDigits(), f -> f::setGroupingUsed);

			if (nf.negativeStyle() == NegativeNumberStyle.PARENTHESES) {
				decimalFormat.setNegativePrefix("(");
				decimalFormat.setNegativeSuffix(")");
			}
		}

		return new NumericTextValueConverter(
			StringUtils.trimToNull(nf.prefix()),
			format
		);
	}

	public String convert(Number number) {
		val formatted = decimalFormat.format(number);

		return prefix == null ?
			formatted :
			prefix + Strings.SPACE + formatted;
	}
}
