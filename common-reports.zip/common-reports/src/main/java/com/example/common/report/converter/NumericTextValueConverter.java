package com.example.common.report.converter;

import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import java.util.Objects;
import java.util.function.Function;

import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.style.format.NegativeNumberStyle;
import com.example.common.report.api.style.format.NumericFormat;
import com.example.utils.fluent.Fluent;
import lombok.AccessLevel;
import lombok.AllArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.StringUtils;
import org.jspecify.annotations.NullMarked;

@NullMarked
@AllArgsConstructor(access = AccessLevel.PRIVATE)
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class NumericTextValueConverter {
	Function<Number, String> formatter;

	public static NumericTextValueConverter of(NumericFormat nf, ReportEngineOptions reportEngineOptions) {
		val locale = Objects.requireNonNullElse(reportEngineOptions.locale(), Locale.getDefault());
		val format = NumberFormat.getNumberInstance(locale);

		if (format instanceof DecimalFormat decimalFormat) {
			Fluent.of(decimalFormat)
				.apply(nf.minFractionDigits(), f -> f::setMinimumFractionDigits)
				.apply(nf.maxFractionDigits(), f -> f::setMaximumFractionDigits)
				.apply(nf.groupDigits(), f -> f::setGroupingUsed);

			if (nf.negativeStyle() == NegativeNumberStyle.PARENTHESES) {
				decimalFormat.setNegativePrefix("(");
				decimalFormat.setNegativeSuffix(")");
			}
		}

		final Function<Number, String> baseFormatter = format::format;
		val noPrefix = StringUtils.isBlank(nf.prefix());
		val noSuffix = StringUtils.isBlank(nf.suffix());

		if (noPrefix && noSuffix)
			return new NumericTextValueConverter(baseFormatter);

		final Function<String, String> addPrefixAndSuffix =
			noPrefix ?
				str -> str + nf.suffix() :
				noSuffix ?
					str -> nf.prefix() + str :
					str -> nf.prefix() + str + nf.suffix();

		return new NumericTextValueConverter(baseFormatter.andThen(addPrefixAndSuffix));
	}

	public String convert(Number number) {
		return formatter.apply(number);
	}
}
