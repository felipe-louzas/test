package com.example.common.report.format.pdf.section.components;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.io.InputStream;

import javax.imageio.ImageIO;

import com.example.common.report.api.measure.Measure;
import com.example.common.report.api.measure.Unit;
import com.example.common.report.api.style.CellStyle;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Slf4j
@NullMarked
@UtilityClass
public class PdfImageLoader {
	private static final String IMAGE_NOT_LOADED = "Erro ao carregar imagem";
	private static final String IMAGE_NOT_CREATED = "Erro ao criar imagem";
	private static final String IMAGE_COMPONENT_ERROR = "Erro ao criar componente";

	public PdfImageComponent loadImageData(
		String imagePath,
		InputStream inputStream,
		Measure maxWidth,
		Measure maxHeight,
		@Nullable CellStyle style
	) {
		try {
			// Load image
			val image = loadImage(imagePath, inputStream);
			if (image == null) return errorComponent(IMAGE_NOT_LOADED, maxWidth, maxHeight);

			// Calculate size to fit within max dimensions
			val fitSizePx = getSizeToFit(image.getWidth(), image.getHeight(), (int) maxWidth.in(Unit.PX), (int) maxHeight.in(Unit.PX));
			val fitWidth = Measure.px(fitSizePx.width);
			val fitHeight = Measure.px(fitSizePx.height);

			// Resample image
			val resampledImage = resample(image, fitSizePx.width, fitSizePx.height);

			// Create image data with background color
			val backgroundColor = getBackgroundColor(style);
			val imageData = getImageData(imagePath, resampledImage, backgroundColor);
			if (imageData == null) errorComponent(IMAGE_NOT_CREATED, fitWidth, fitHeight);

			// Return image component with resampled image data and fit dimensions
			return PdfImageComponent.builder()
				.imageData(imageData)
				.width(fitWidth.points())
				.height(fitHeight.points())
				.build();

		} catch (Exception ex) {
			log.error("{} creating image component: {}", ex.getClass().getSimpleName(), imagePath, ex);
			return errorComponent(IMAGE_COMPONENT_ERROR, maxWidth, maxHeight);
		}
	}

	@Nullable
	private ImageData getImageData(String imagePath, BufferedImage resampledImage, Color backgroundColor) {
		try {
			return ImageDataFactory.create(resampledImage, backgroundColor);
		} catch (Exception ex) {
			log.error("{} creating image data: {}", ex.getClass().getSimpleName(), imagePath, ex);
			return null;
		}
	}

	private Dimension getSizeToFit(int width, int height, int maxWidth, int maxHeight) {
		double scale = Math.min((double) maxWidth / width, (double) maxHeight / height);
		scale = Math.min(scale, 1.0); // Prevent upscaling

		val newWidth = Math.max(1, (int) Math.round(width * scale));
		val newHeight = Math.max(1, (int) Math.round(height * scale));

		return new Dimension(newWidth, newHeight);
	}

	@Nullable
	private BufferedImage loadImage(String imagePath, InputStream inputStream) {
		try {
			val image = ImageIO.read(inputStream);
			if (image != null)
				return image;
			log.error("Unsupported image format: {}", imagePath);
		} catch (Exception ex) {
			log.error("{} reading image input stream: {}", ex.getClass().getSimpleName(), imagePath, ex);
		}
		return null;
	}

	private BufferedImage resample(BufferedImage source, int width, int height) {
		val imageType = source.getColorModel().hasAlpha()
			? BufferedImage.TYPE_INT_ARGB
			: BufferedImage.TYPE_INT_RGB;

		val scaled = new BufferedImage(width, height, imageType);

		val graphics = scaled.createGraphics();

		graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
		graphics.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
		graphics.setRenderingHint(RenderingHints.KEY_COLOR_RENDERING, RenderingHints.VALUE_COLOR_RENDER_QUALITY);
		graphics.setRenderingHint(RenderingHints.KEY_ALPHA_INTERPOLATION, RenderingHints.VALUE_ALPHA_INTERPOLATION_QUALITY);

		graphics.drawImage(source, 0, 0, width, height, null);
		graphics.dispose();
		return scaled;
	}

	private Color getBackgroundColor(@Nullable CellStyle cellStyle) {
		if (cellStyle == null || cellStyle.backgroundColor() == null) return Color.WHITE;
		val colorValue = cellStyle.backgroundColor();
		return new Color(colorValue.red(), colorValue.green(), colorValue.blue());
	}

	private PdfImageComponent errorComponent(String errorMessage, Measure width, Measure height) {
		return PdfImageComponent.builder()
			.altText(errorMessage)
			.width(width.points())
			.height(height.points())
			.build();
	}
}
