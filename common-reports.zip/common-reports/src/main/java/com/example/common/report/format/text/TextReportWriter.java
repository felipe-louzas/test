package com.example.common.report.format.text;

import java.io.IOException;
import java.io.OutputStream;

import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.core.RowMapper;
import com.example.common.report.api.exception.ReportException;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;

@RequiredArgsConstructor
@FieldDefaults(makeFinal = true, level = lombok.AccessLevel.PRIVATE)
final class TextReportWriter implements ReportWriter {

	CompiledTextReport compiled;

	@Override
	public <T> void write(Iterable<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException {
		try (val writer = compiled.writerFactory().apply(output)) {
			if (compiled.includeHeader())
				writeHeader(writer);

			for (val row : data) {
				writer.writeRow(getRowValues(row, mapper));
			}

			writer.flush();
		} catch (IOException ex) {
			throw ex;

		} catch (Exception ex) {
			throw new ReportException("Erro ao gerar o relatório de texto: " + ex.getLocalizedMessage(), ex);
		}
	}

	private void writeHeader(RowWriter writer) throws Exception {
		val values = compiled.columns().stream()
			.map(TextReportColumn::header)
			.toArray(String[]::new);
		writer.writeHeader(values);
	}

	private <T> String[] getRowValues(T row, RowMapper<T> mapper) {
		return compiled.columns().stream()
			.map(column -> column.converter().convert(mapper.getValue(row, column.key())))
			.toArray(String[]::new);
	}
}
