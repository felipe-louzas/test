package com.example.common.report.format.text;

import java.io.IOException;
import java.io.OutputStream;
import java.util.stream.Stream;

import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.core.RowMapper;
import com.example.common.report.api.exception.ReportException;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.function.Failable;

@RequiredArgsConstructor
@FieldDefaults(makeFinal = true, level = lombok.AccessLevel.PRIVATE)
final class TextReportWriter implements ReportWriter {

	TextReportContext context;

	@Override
	public <T> void write(Stream<T> data, RowMapper<T> mapper, OutputStream output) throws IOException, ReportException {
		try (val writer = context.writerFactory().apply(output)) {
			if (context.includeHeader())
				writeHeader(writer);

			data.map(row -> getRowValues(row, mapper))
				.forEach(Failable.asConsumer(writer::writeRow));

			writer.flush();
		} catch (IOException ex) {
			throw ex;

		} catch (Exception ex) {
			throw new ReportException("Erro ao gerar o relatório de texto: " + ex.getLocalizedMessage(), ex);
		}
	}

	private void writeHeader(RowWriter writer) throws Exception {
		val values = context.columns().stream()
			.map(TextReportColumn::header)
			.toArray(String[]::new);
		writer.writeHeader(values);
	}

	private <T> String[] getRowValues(T row, RowMapper<T> mapper) {
		return context.columns().stream()
			.map(column -> column.converter().convert(mapper.getValue(row, column.key())))
			.toArray(String[]::new);
	}
}
