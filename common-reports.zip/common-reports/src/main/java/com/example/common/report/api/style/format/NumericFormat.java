package com.example.common.report.api.style.format;

import lombok.Builder;

@Builder
public record NumericFormat(
	String prefix,
	String suffix,
	NegativeNumberStyle negativeStyle,
	Integer minFractionDigits,
	Integer maxFractionDigits,
	Boolean groupDigits
) implements TextFormat {
	public static final NumericFormat DEFAULT_FORMAT = NumericFormat.builder()
		.negativeStyle(NegativeNumberStyle.MINUS)
		.minFractionDigits(0)
		.maxFractionDigits(4)
		.groupDigits(true)
		.build();
}