package com.example.common.report.api.style.format;

import lombok.Builder;

@Builder
public record NumericFormat(
	String prefix,
	NegativeNumberStyle negativeStyle,
	Integer minFractionDigits,
	Integer maxFractionDigits,
	Boolean groupDigits
) implements TextFormat {
	public static final NumericFormat DEFAULT_FORMAT = new NumericFormat(null, NegativeNumberStyle.MINUS, 0, 4, true);
}