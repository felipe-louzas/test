package com.example.common.report.format.pdf.section.components;

import com.example.common.report.format.pdf.writer.PdfWriterContext;
import com.itextpdf.layout.element.Cell;

@FunctionalInterface
public interface PdfSectionComponent {
	void render(Cell cell, PdfWriterContext context);
}
