package com.example.common.report.format.text;

import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.Objects;

import com.example.common.report.api.core.FormatOptions;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import lombok.Builder;

@Builder
public record TextReportOptions(
	Character delimiter,
	Character quote,
	Character escape,
	String lineSeparator,
	Boolean includeHeader,
	Charset charset
) implements FormatOptions<TextReportOptions> {
	public TextReportOptions {
		includeHeader = Objects.requireNonNullElse(includeHeader, Boolean.TRUE);
		charset = Objects.requireNonNullElse(charset, StandardCharsets.UTF_8);
	}

	public static TextReportOptions csvDefaults() {
		return TextReportOptions.builder().build();
	}

	@Override
	public ReportFormat<TextReportOptions> getFormat() {
		return ReportFormats.TEXT;
	}
}