package com.example.common.report.format.pdf.section;

import com.example.common.report.api.section.PageRenderPolicy;
import com.example.common.report.format.pdf.section.components.PdfSectionComponent;
import com.example.common.report.format.pdf.writer.PdfWriterContext;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.properties.UnitValue;
import lombok.AccessLevel;
import lombok.Builder;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@Builder
@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class PdfSectionRow {
	@Getter
	float height;

	@Getter
	PageRenderPolicy pageRenderPolicy;

	@Nullable PdfSectionSlot left;
	@Nullable PdfSectionSlot center;
	@Nullable PdfSectionSlot right;

	public void render(PdfWriterContext context, int pageNumber, float rowLeft, float rowTopY, float width) {
		if (height <= 0f)
			return;
		val document = context.getDocument();
		val rowBottomY = rowTopY - height;

		val table = new Table(UnitValue.createPercentArray(new float[]{1, 1, 1}));
		table.setWidth(width);
		table.setFixedLayout();
		table.setPaddingBottom(0);
		table.setPaddingTop(0);
		//table.setHeight(height);

		val leftCell = createCell(left, context);
		val centerCell = createCell(center, context);
		val rightCell = createCell(right, context);

		table.addCell(leftCell);
		table.addCell(centerCell);
		table.addCell(rightCell);

		table.setFixedPosition(pageNumber, rowLeft, rowBottomY, width);

		document.add(table);
	}

	private Cell createCell(@Nullable PdfSectionSlot slot, PdfWriterContext context) {
		val cell = new Cell();
		cell.setHeight(height);
		cell.setPaddingBottom(0);
		cell.setPaddingTop(0);

		if (slot == null)
			return cell;

		// Apply style
		slot.slotStyle().applyCellStyle(cell);

		// Render components vertically inside cell
		for (PdfSectionComponent component : slot.components()) {
			component.render(cell, context);
		}

		return cell;
	}
}
