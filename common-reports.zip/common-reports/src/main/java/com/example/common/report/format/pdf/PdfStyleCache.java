package com.example.common.report.format.pdf;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import com.example.common.report.format.pdf.context.PdfCellStyle;

final class PdfStyleCache {
	private final Map<PdfCellStyle, PdfCellStyle> cache = new ConcurrentHashMap<>();

	PdfCellStyle intern(PdfCellStyle style) {
		if (style == null) return null;
		return cache.computeIfAbsent(style, key -> style);
	}
}
