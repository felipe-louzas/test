package com.example.common.report.format.pdf.context;

import com.itextpdf.kernel.colors.Color;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.layout.properties.TextAlignment;

public record PdfCellStyle(
	PdfFont font,
	Float fontSize,
	Boolean bold,
	Boolean italic,
	Color textColor,
	Color backgroundColor,
	TextAlignment alignment,
	Boolean border
) {
	public static PdfCellStyle merge(PdfCellStyle base, PdfCellStyle override) {
		if (base == null) return override;
		if (override == null) return base;

		return new PdfCellStyle(
			override.font() != null ? override.font() : base.font(),
			override.fontSize() != null ? override.fontSize() : base.fontSize(),
			override.bold() != null ? override.bold() : base.bold(),
			override.italic() != null ? override.italic() : base.italic(),
			override.textColor() != null ? override.textColor() : base.textColor(),
			override.backgroundColor() != null ? override.backgroundColor() : base.backgroundColor(),
			override.alignment() != null ? override.alignment() : base.alignment(),
			override.border() != null ? override.border() : base.border()
		);
	}
}
