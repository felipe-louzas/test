package com.example.common.report.format.pdf;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.List;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.ReportOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.layout.Alignment;
import com.example.common.report.api.layout.BandComponent;
import com.example.common.report.api.layout.BandContent;
import com.example.common.report.api.layout.BandDefinition;
import com.example.common.report.api.layout.BandSlot;
import com.example.common.report.api.layout.HeaderFooterDefinition;
import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.style.CellStyle;
import com.example.common.report.api.table.TableDefinition;
import com.example.common.report.converter.TextValueConverters;
import com.example.common.report.converter.ValueConverter;
import com.example.common.report.engine.ReportBuilder;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import com.example.common.report.format.pdf.context.PdfCellStyle;
import com.example.common.report.format.pdf.context.PdfPageMetrics;
import com.example.common.report.format.pdf.context.PdfColumn;
import com.example.common.report.format.pdf.context.PdfReportContext;
import com.itextpdf.io.image.ImageData;
import com.itextpdf.io.image.ImageDataFactory;
import com.itextpdf.layout.properties.TextAlignment;
import lombok.Getter;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@Getter
@NullMarked
public final class PdfReportBuilder implements ReportBuilder<PdfReportOptions> {

	ReportFormat<PdfReportOptions> format = ReportFormats.PDF;
	PdfReportOptions defaultOptions = PdfReportOptions.defaultOptions();

	@Override
	public ReportWriter buildReport(ReportTemplate template, PdfReportOptions options, ReportOptions reportOptions) {
		val table = template.table();
		val pageDefinition = resolvePageDefinition(template, options);
		val styleCache = new PdfStyleCache();
		val styleResolver = new PdfStyleResolver(options);
		val baseStyle = styleCache.intern(styleResolver.baseStyle());
		val columns = compileColumns(table, reportOptions, styleResolver, styleCache, baseStyle);
		val weights = resolveColumnWeights(columns);
		val pageMetrics = PdfPageMetrics.of(pageDefinition);
		val headerBands = compileBands(template.header(), styleResolver, styleCache);
		val footerBands = compileBands(template.footer(), styleResolver, styleCache);

		val ctx = PdfReportContext.builder()
			.options(options)
			.reportOptions(reportOptions)
			.page(pageMetrics)
			.columns(columns)
			.columnWeights(weights)
			.headerBands(headerBands)
			.footerBands(footerBands)
			.repeatingHeaderHeight(repeatingHeight(headerBands))
			.repeatingFooterHeight(repeatingHeight(footerBands))
			.build();

		return new PdfReportWriter(ctx);
	}

	private PageDefinition resolvePageDefinition(ReportTemplate template, PdfReportOptions options) {
		if (template.page() != null) {
			return template.page();
		}
		return options.defaultPage();
	}

	private List<PdfColumn> compileColumns(TableDefinition table, ReportOptions reportOptions, PdfStyleResolver resolver, PdfStyleCache cache, PdfCellStyle baseStyle) {
		val converterPool = new HashMap<CellStyle, ValueConverter<String>>();
		val columns = new ArrayList<PdfColumn>(table.columns().size());

		val tableHeaderStyle = cache.intern(PdfCellStyle.merge(baseStyle, resolver.resolve(table.headerStyle())));
		val tableRowStyle = cache.intern(PdfCellStyle.merge(baseStyle, resolver.resolve(table.rowStyle())));
		val tableAlternateStyle = cache.intern(PdfCellStyle.merge(tableRowStyle, resolver.resolve(table.alternateRowStyle())));

		for (val column : table.columns()) {
			val converterKey = column.style() != null ? column.style() : table.rowStyle();
			val converter = converterPool.computeIfAbsent(
				converterKey,
				style -> TextValueConverters.forStyle(style, reportOptions)
			);

			val columnRowStyle = cache.intern(PdfCellStyle.merge(tableRowStyle, resolver.resolve(column.style())));
			val columnAlternateStyle = cache.intern(PdfCellStyle.merge(columnRowStyle, tableAlternateStyle));

			columns.add(new PdfColumn(
				column.key(),
				column.header(),
				converter,
				tableHeaderStyle,
				columnRowStyle,
				columnAlternateStyle,
				Math.max(0f, column.width())
			));
		}

		return columns;
	}

	private float[] resolveColumnWeights(List<PdfColumn> columns) {
		float total = 0f;
		val weights = new float[columns.size()];
		for (int i = 0; i < columns.size(); i++) {
			val weight = columns.get(i).width() > 0 ? columns.get(i).width() : 1f;
			weights[i] = weight;
			total += weight;
		}
		if (total <= 0f) {
			for (int i = 0; i < weights.length; i++) {
				weights[i] = 1f;
			}
		}
		return weights;
	}

	private List<PdfReportContext.PdfBandPlan> compileBands(HeaderFooterDefinition definition, PdfStyleResolver resolver, PdfStyleCache cache) {
		if (definition == null || definition.bands() == null || definition.bands().isEmpty()) {
			return List.of();
		}
		return definition.bands().stream()
			.map(band -> compileBand(band, resolver, cache))
			.toList();
	}

	private PdfReportContext.PdfBandPlan compileBand(BandDefinition band, PdfStyleResolver resolver, PdfStyleCache cache) {
		val components = band.components() == null ? List.<BandComponent>of() : band.components();
		val slots = new EnumMap<BandSlot, List<PdfReportContext.PdfBandComponentPlan>>(BandSlot.class);
		for (val slot : BandSlot.values()) {
			slots.put(slot, new ArrayList<>());
		}
		for (val component : components) {
			val plans = slots.get(component.slot());
			plans.add(compileComponent(component, resolver, cache));
		}

		return new PdfReportContext.PdfBandPlan(
			Math.max(0f, band.height()),
			band.repeatOnEachPage(),
			List.of(
				new PdfReportContext.PdfBandSlotPlan(BandSlot.LEFT, List.copyOf(slots.get(BandSlot.LEFT))),
				new PdfReportContext.PdfBandSlotPlan(BandSlot.CENTER, List.copyOf(slots.get(BandSlot.CENTER))),
				new PdfReportContext.PdfBandSlotPlan(BandSlot.RIGHT, List.copyOf(slots.get(BandSlot.RIGHT)))
			)
		);
	}

	private PdfReportContext.PdfBandComponentPlan compileComponent(BandComponent component, PdfStyleResolver resolver, PdfStyleCache cache) {
		val resolvedStyle = cache.intern(PdfCellStyle.merge(resolver.baseStyle(), resolver.resolve(component.style())));
		val alignment = toAlignment(component.alignment());
		val content = component.content();
		if (content instanceof BandContent.TextContent text) {
			return new PdfReportContext.TextComponentPlan(text.text(), resolvedStyle, alignment);
		}
		if (content instanceof BandContent.PageNumberContent number) {
			return new PdfReportContext.PageNumberComponentPlan(number.pattern(), resolvedStyle, alignment);
		}
		if (content instanceof BandContent.ImageContent image) {
			return new PdfReportContext.ImageComponentPlan(loadImageData(image.resourcePath()), image.width(), image.height(), resolvedStyle, alignment);
		}
		return new PdfReportContext.TextComponentPlan("", resolvedStyle, alignment);
	}

	private ImageData loadImageData(String resourcePath) {
		try (InputStream stream = PdfReportContext.class.getResourceAsStream(resourcePath)) {
			if (stream == null) {
				throw new IllegalArgumentException("Imagem nao encontrada: " + resourcePath);
			}
			return ImageDataFactory.create(stream.readAllBytes());
		} catch (IOException ex) {
			throw new IllegalArgumentException("Erro ao carregar imagem: " + resourcePath, ex);
		}
	}

	private TextAlignment toAlignment(Alignment alignment) {
		if (alignment == null) return null;
		return switch (alignment) {
			case LEFT -> TextAlignment.LEFT;
			case CENTER -> TextAlignment.CENTER;
			case RIGHT -> TextAlignment.RIGHT;
		};
	}

	private float repeatingHeight(List<PdfBandPlan> bands) {
		return (float) bands.stream()
			.filter(PdfBandPlan::repeatOnEachPage)
			.mapToDouble(PdfBandPlan::height)
			.sum();
	}
}
