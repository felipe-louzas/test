package com.example.common.report.format.pdf;

import com.example.common.report.api.ReportTemplate;
import com.example.common.report.api.core.ReportEngineOptions;
import com.example.common.report.api.core.ReportWriter;
import com.example.common.report.api.exception.ReportException;
import com.example.common.report.engine.ReportBuilder;
import com.example.common.report.format.ReportFormat;
import com.example.common.report.format.ReportFormats;
import com.example.common.report.format.pdf.section.PdfSectionCompiler;
import com.example.common.report.format.pdf.style.PdfStyleResolver;
import com.example.common.report.format.pdf.table.PdfTableCompiler;
import com.example.common.report.format.pdf.writer.CompiledPdfReport;
import com.example.common.report.format.pdf.writer.PdfPageMetrics;
import com.example.common.report.format.pdf.writer.PdfReportWriter;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.springframework.core.io.ResourceLoader;

@Getter
@NullMarked
@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class PdfReportBuilder implements ReportBuilder<PdfReportOptions> {

	ResourceLoader resourceLoader;
	ReportFormat<PdfReportOptions> format = ReportFormats.PDF;
	PdfReportOptions defaultOptions = PdfReportOptions.defaultOptions();

	@Override
	public ReportWriter buildReport(ReportTemplate template, PdfReportOptions reportOptions, ReportEngineOptions engineOptions) throws ReportException {
		val tableDefinition = template.table();
		val pageDefinition = template.page();

		val styleResolver = new PdfStyleResolver(reportOptions, engineOptions, resourceLoader);
		val pageMetrics = PdfPageMetrics.of(pageDefinition, template);

		val sectionCompiler = new PdfSectionCompiler(styleResolver, pageMetrics);
		val sections = sectionCompiler.compile(template);

		val tableCompiler = new PdfTableCompiler(styleResolver);
		val table = tableCompiler.compileColumns(tableDefinition, pageMetrics);

		val ctx = CompiledPdfReport.builder()
			.reportOptions(reportOptions)
			.pageMetrics(pageMetrics)
			.table(table)
			.sections(sections)
			.build();

		return new PdfReportWriter(ctx);
	}
}
