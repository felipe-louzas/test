package com.example.common.report.api.layout;

import java.util.List;

import lombok.Builder;

@Builder
public record HeaderFooterDefinition(
	List<BandDefinition> bands
) {}
