package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;
import lombok.Builder;

@Builder
public record PageMargins(
	Measure top,
	Measure bottom,
	Measure left,
	Measure right
) {
}
