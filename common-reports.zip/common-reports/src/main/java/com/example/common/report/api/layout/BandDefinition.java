package com.example.common.report.api.layout;

import lombok.Builder;

import java.util.List;

@Builder
public record BandDefinition(
    float height,
    boolean repeatOnEachPage,
    List<BandComponent> components
) {}
