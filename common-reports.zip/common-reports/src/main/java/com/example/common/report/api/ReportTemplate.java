package com.example.common.report.api;

import com.example.common.report.api.layout.HeaderFooterDefinition;
import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.table.TableDefinition;
import lombok.Builder;
import org.apache.commons.lang3.ObjectUtils;

@Builder
public record ReportTemplate(
	String id,
	PageDefinition page,
	HeaderFooterDefinition header,
	HeaderFooterDefinition footer,
	TableDefinition table
) {
	public ReportTemplate {
		if (table == null)
			throw new IllegalArgumentException("Nenhuma configuração de tabela definida no template");
		if (ObjectUtils.isEmpty(table.columns()))
			throw new IllegalArgumentException("Nenhuma coluna definida na configuração de tabela do template");
	}
}
