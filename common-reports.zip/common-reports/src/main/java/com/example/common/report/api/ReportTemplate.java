package com.example.common.report.api;

import java.util.Objects;

import com.example.common.report.api.layout.PageDefinition;
import com.example.common.report.api.section.PageRenderPolicy;
import com.example.common.report.api.section.Section;
import com.example.common.report.api.table.TableDefinition;
import lombok.Builder;
import org.apache.commons.lang3.ObjectUtils;
import org.jspecify.annotations.Nullable;

@Builder
public record ReportTemplate(
	String id,
	PageDefinition page,
	TableDefinition table,
	@Nullable Section pageHeader,
	@Nullable Section pageFooter,
	@Nullable Section contentHeader,
	@Nullable Section contentFooter
) {
	public ReportTemplate {
		Objects.requireNonNull(id, "O id do template é obrigatório");
		page = Objects.requireNonNullElse(page, PageDefinition.DEFAULT_PAGE_DEFINITION);
		if (table == null)
			throw new IllegalArgumentException("Nenhuma configuração de tabela definida no template");
		if (ObjectUtils.isEmpty(table.columns()))
			throw new IllegalArgumentException("Nenhuma coluna definida na configuração de tabela do template");
		if (pageHeader != null) {
			if (!pageHeader.filterRows(PageRenderPolicy.LAST_PAGE).isEmpty())
				throw new IllegalArgumentException("O pageHeader não pode conter linhas com a política de renderização LAST_PAGE");
		}
		if (contentHeader != null) {
			if (!contentHeader.filterRows(PageRenderPolicy.LAST_PAGE).isEmpty())
				throw new IllegalArgumentException("O contentHeader não pode conter linhas com a política de renderização LAST_PAGE");
		}
	}
}
