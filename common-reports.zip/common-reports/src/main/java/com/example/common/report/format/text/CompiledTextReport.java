package com.example.common.report.format.text;

import java.io.OutputStream;
import java.util.List;
import java.util.function.Function;

import lombok.Builder;

@Builder
record CompiledTextReport(
	List<TextReportColumn> columns,
	boolean includeHeader,
	Function<OutputStream, RowWriter> writerFactory
) {}