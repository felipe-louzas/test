package com.example.common.report.api.layout;

public enum HorizontalAlignment {
    LEFT,
    CENTER,
    RIGHT
}