package com.example.common.report.api.layout;

import com.example.common.report.api.measure.Measure;
import lombok.AccessLevel;
import lombok.experimental.FieldDefaults;

@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public enum PageSizes {
	A3(Measure.mm(297), Measure.mm(420)),
	A4(Measure.mm(210), Measure.mm(297)),
	LETTER(Measure.inch(8.5f), Measure.inch(11));

	PageSize portraitSize;

	PageSizes(Measure portraitWidth, Measure portraitHeight) {
		portraitSize = new PageSize(portraitWidth, portraitHeight);
		if (!portraitSize.isPortrait())
			throw new IllegalArgumentException("Portrait dimensions must have height greater than or equal to width");
	}

	public PageSize portrait() {
		return portraitSize;
	}

	public PageSize landscape() {
		return portraitSize.landscape();
	}
}

