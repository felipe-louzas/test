package com.example.common.report.api.section;

public enum SectionSlot {
    LEFT,
    CENTER,
    RIGHT
}
