package com.example.utils.strings;

import lombok.experimental.UtilityClass;
import lombok.val;
import org.apache.commons.lang3.ObjectUtils;
import org.apache.commons.lang3.StringUtils;

import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.Collection;
import java.util.Objects;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@UtilityClass
public class Strings {
    public final String EMPTY = "";
    public final String SPACE = " ";
    public final String PROPERTY_SEPARATOR = ".";
    public final String LIST_SEPARATOR = ",";

	private final char CHAR_PRINTABLE_MIN = 0x20; // SPACE
    private final char CHAR_PRINTABLE_MAX = 0x7D; // '}' (desconsidera '~' (0x7E) para utilização como separador)
    private final char CHAR_PRINTABLE_SEPARATOR = CHAR_PRINTABLE_MAX + 1;
    private final Base64.Encoder ENCODER_B64_URL_NOPAD = Base64.getUrlEncoder().withoutPadding();

    /* ---- truncateOrLeftPad ---- */

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à esquerda com espaços.
     *
     * @param string A string original.
     * @param length O tamanho desejado da string final.
     * @return A string truncada ou preenchida à esquerda com espaços.
     */
    public String truncateOrLeftPad(String string, int length) {
        return StringUtils.leftPad(StringUtils.truncate(string, length), length);
    }

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à esquerda com o caractere informado.
     *
     * @param string  A string original.
     * @param length  O tamanho desejado da string final.
     * @param padChar O caractere usado para preenchimento à esquerda.
     * @return A string truncada ou preenchida à esquerda com o caractere informado.
     */
    public String truncateOrLeftPad(String string, int length, char padChar) {
        return StringUtils.leftPad(StringUtils.truncate(string, length), length, padChar);
    }

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à esquerda com a sequência informada.
     *
     * @param string A string original.
     * @param length O tamanho desejado da string final.
     * @param padStr A sequência usada para preenchimento à esquerda.
     * @return A string truncada ou preenchida à esquerda com a sequência informada.
     */
    public String truncateOrLeftPad(String string, int length, String padStr) {
        return StringUtils.leftPad(StringUtils.truncate(string, length), length, padStr);
    }

    /* ---- truncateOrRightPad ---- */

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à direita com espaços.
     *
     * @param string A string original.
     * @param length O tamanho desejado da string final.
     * @return A string truncada ou preenchida à direita com espaços.
     */
    public String truncateOrRightPad(String string, int length) {
        return StringUtils.rightPad(StringUtils.truncate(string, length), length);
    }

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à direita com o caractere informado.
     *
     * @param string  A string original.
     * @param length  O tamanho desejado da string final.
     * @param padChar O caractere usado para preenchimento à direita.
     * @return A string truncada ou preenchida à direita com o caractere informado.
     */
    public String truncateOrRightPad(String string, int length, char padChar) {
        return StringUtils.rightPad(StringUtils.truncate(string, length), length, padChar);
    }

    /**
     * Trunca a string para o tamanho especificado e, caso seja menor, completa à direita com a sequência informada.
     *
     * @param string A string original.
     * @param length O tamanho desejado da string final.
     * @param padStr A sequência usada para preenchimento à direita.
     * @return A string truncada ou preenchida à direita com a sequência informada.
     */
    public String truncateOrRightPad(String string, int length, String padStr) {
        return StringUtils.rightPad(StringUtils.truncate(string, length), length, padStr);
    }

    /* ---- joinNonBlank ---- */

    public String joinNonBlank(String delimiter, String... parts) {
        if (parts == null || parts.length == 0) return EMPTY;
        return joinNonBlank(delimiter, Stream.of(parts));
    }

    public String joinNonBlank(String delimiter, Collection<String> parts) {
        if (parts == null || parts.isEmpty()) return EMPTY;
        return joinNonBlank(delimiter, parts.stream());
    }

    public String joinNonBlank(String delimiter, Stream<String> stream) {
        if (stream == null) return EMPTY;
        return stream
                .map(StringUtils::trimToNull)
                .filter(Objects::nonNull)
                .collect(Collectors.joining(delimiter));
    }

    /* ---- toPrintableString ---- */

    public String toPrintableString(String value) {
        if (StringUtils.isBlank(value)) return null;
        return toPrintableString(value.getBytes(StandardCharsets.UTF_8));
    }

    public String toPrintableString(byte[] bytes) {
        if (ObjectUtils.isEmpty(bytes)) return null;

        // mantém caracteres legíveis iniciais
        int i = 0;
        while (i < bytes.length) {
            int b = bytes[i] & 0xFF; // unsigned
            if (b < CHAR_PRINTABLE_MIN || b > CHAR_PRINTABLE_MAX) break;
            i++;
        }

        val prefix = new String(bytes, 0, i, StandardCharsets.US_ASCII);
        if (i == bytes.length) return prefix;

        val encoded = ENCODER_B64_URL_NOPAD.encode(ByteBuffer.wrap(bytes, i, bytes.length - i));
        val tail = StandardCharsets.US_ASCII.decode(encoded);

        return prefix + CHAR_PRINTABLE_SEPARATOR + tail;
    }
}