package com.example.utils.datetime;

import java.time.DateTimeException;
import java.time.Instant;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.OffsetDateTime;
import java.time.OffsetTime;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.temporal.TemporalAccessor;
import java.time.temporal.TemporalQueries;

import lombok.experimental.UtilityClass;
import lombok.val;
import org.jspecify.annotations.NullMarked;

@NullMarked
@UtilityClass
public class TimeZones {

	/**
	 * Converts any TemporalAccessor to a ZonedDateTime in the given zone.
	 * <p>
	 * Local date-times are interpreted as already being in the given zone. Instant/offset-based temporals preserve the instant.
	 */
	public static ZonedDateTime atTimeZone(TemporalAccessor temporal, ZoneId targetZone) {
		if (temporal instanceof ZonedDateTime zdt) return zdt.withZoneSameInstant(targetZone);
		else if (temporal instanceof OffsetDateTime odt) return odt.atZoneSameInstant(targetZone);
		else if (temporal instanceof Instant instant) return instant.atZone(targetZone);
		else if (temporal instanceof OffsetTime ot) return ot.atDate(LocalDate.now(targetZone)).atZoneSameInstant(targetZone);
		else if (temporal instanceof LocalDateTime ldt) return ldt.atZone(targetZone);
		else if (temporal instanceof LocalDate ld) return ld.atStartOfDay(targetZone);
		else if (temporal instanceof LocalTime lt) return lt.atDate(LocalDate.now(targetZone)).atZone(targetZone);
		else return extractZonedDateTime(temporal, targetZone);
	}

	private static ZonedDateTime extractZonedDateTime(TemporalAccessor temporal, ZoneId targetZone) {
		val offset = temporal.query(TemporalQueries.offset());
		if (offset != null) {
			try {
				val instant = Instant.from(temporal);
				return instant.atZone(targetZone);
			} catch (DateTimeException ignored) {
				// fall through
			}
		}

		// Try to extract local date and time
		val date = temporal.query(TemporalQueries.localDate());
		val time = temporal.query(TemporalQueries.localTime());
		if (date != null && time != null)
			return time.atDate(LocalDate.now(targetZone)).atZone(targetZone);
		if (date != null)
			return date.atStartOfDay(targetZone);
		if (time != null)
			return time.atDate(LocalDate.now(targetZone)).atZone(targetZone);

		throw new DateTimeException("Unsupported TemporalAccessor type: " + temporal.getClass());
	}
}
