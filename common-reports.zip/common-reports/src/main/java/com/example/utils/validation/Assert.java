package com.example.utils.validation;

import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.StringUtils;

import java.util.Objects;
import java.util.function.Supplier;

@UtilityClass
public class Assert {
    public void isPositive(Integer value, Supplier<String> message) {
        if (Objects.requireNonNullElse(value, 0) <= 0)
            throw new IllegalArgumentException(message.get());
    }

    public void isPositiveOrNull(Integer value, Supplier<String> message) {
        if (value != null && value <= 0)
            throw new IllegalArgumentException(message.get());
    }

    public void isNotNegative(Integer value, Supplier<String> message) {
        if (Objects.requireNonNullElse(value, 0) < 0)
            throw new IllegalArgumentException(message.get());
    }

    public static void isGreaterOrEqual(Integer value, Integer limit, Supplier<String> message) {
        if (value != null && limit != null && limit > value)
            throw new IllegalArgumentException(message.get());
    }

    public static void notBlank(CharSequence value, Supplier<String> message) {
        if (StringUtils.isBlank(value))
            throw new IllegalArgumentException(message.get());
    }

    public static void isTrue(Boolean condition, Supplier<String> message) {
        if (!Objects.equals(condition, Boolean.TRUE))
            throw new IllegalArgumentException(message.get());
    }

    public static void isFalse(Boolean condition, Supplier<String> message) {
        if (condition != null && !Objects.equals(condition, Boolean.FALSE))
            throw new IllegalArgumentException(message.get());
    }

    public static void isEqualOrNull(Object a, Object b, Supplier<String> message) {
        if (a != null && b != null && !Objects.equals(a, b))
            throw new IllegalArgumentException(message.get());
    }
}
