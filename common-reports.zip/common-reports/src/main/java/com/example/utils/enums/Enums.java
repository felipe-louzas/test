package com.example.utils.enums;

import lombok.NonNull;
import lombok.experimental.UtilityClass;
import lombok.val;

import java.io.Serializable;
import java.util.Arrays;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

/**
 * <p>
 * Utilitário para conversão de valores em constantes {@code enum}. Suporta:
 * </p>
 *
 * <ul>
 *   <li>Busca por {@code toString()} da constante do enum (ver {@link #fromString(Class, String)});</li>
 *   <li>Busca por um <em>valor associado</em> (pattern “enum com valor”), informando uma função extratora
 *       (ver {@link #fromValue(Class, Function, Serializable)} e {@link #fromValueOrThrow(Class, Function, Serializable)});</li>
 *   <li>Atalho para enums que implementam uma interface do tipo {@code EnumValue<E, T>}, permitindo buscar diretamente pelo valor
 *       (ver {@link #fromValue(Class, Serializable)} e {@link #fromValueOrThrow(Class, Serializable)}).</li>
 * </ul>
 *
 * <p>
 * Os métodos que retornam {@link Optional} não disparam exceção quando não há correspondência —
 * retornam {@link Optional#empty()}. Já os métodos {@code fromValueOrThrow(...)} lançam
 * {@code EnumValueNotFoundException} com a lista de valores aceitos.
 * </p>
 *
 * <b>Exemplos</b>
 *
 * <pre>{@code
 * enum Status {
 *   ATIVO, INATIVO;
 * }
 *
 * // Pelo toString() (por padrão, o nome da constante)
 * Optional<Status> s1 = Enums.fromString(Status.class, "ATIVO"); // Optional.of(ATIVO)
 * Optional<Status> s2 = Enums.fromString(Status.class, "DESCONHECIDO"); // Optional.empty()
 *
 * // Padrão "enum com valor"
 * enum TipoDocumento implements EnumValue<TipoDocumento, Integer> {
 *   RG(1), CPF(2);
 *   private final Integer codigo;
 *   TipoDocumento(Integer c) { this.codigo = c; }
 *   @Override public Integer getValue() { return codigo; }
 *   @Override public TipoDocumento getSelf() { return this; }
 * }
 *
 * Optional<TipoDocumento> t1 = Enums.fromValue(TipoDocumento.class, 2); // Optional.of(CPF)
 * TipoDocumento t2 = Enums.fromValueOrThrow(TipoDocumento.class, 3);    // lança EnumValueNotFoundException
 * }</pre>
 */
@UtilityClass
public class Enums {

    private static final String MESSAGE_NO_ENUM_CONSTANTS = "A classe informada não é um enum ou não possui valores definidos: ";

    /**
     * Recupera uma constante do {@code enum} cujo {@code toString()} corresponda à {@code string} informada.
     *
     * <p>Se nenhuma constante corresponder, retorna {@link Optional#empty()}.</p>
     *
     * @param <E>       tipo do enum
     * @param enumClass classe do enum
     * @param string    texto a ser comparado com {@code toString()} das constantes
     * @return {@link Optional} contendo a constante encontrada ou vazio se não houver correspondência
     * @throws IllegalArgumentException se {@code enumClass} não representar um {@code enum}
     */
    public <E extends Enum<E>> Optional<E> fromString(@NonNull Class<E> enumClass, String string) {
        return fromValue(enumClass, Enum::toString, string);
    }

    /**
     * Recupera uma constante de um {@code enum} que implementa {@code EnumValue<E, T>} a partir do
     * <em>valor associado</em>.
     *
     * <p>Se nenhuma constante corresponder, retorna {@link Optional#empty()}.</p>
     *
     * @param <E>            tipo do enum
     * @param <T>            tipo do valor associado (serializável)
     * @param <V>            tipo concreto do enum que implementa {@code EnumValue<E, T>}
     * @param enumValueClass classe do enum que implementa {@code EnumValue}
     * @param value          valor a ser localizado entre as constantes
     * @return {@link Optional} contendo a constante encontrada ou vazio se não houver correspondência
     * @throws IllegalArgumentException se {@code enumValueClass} não for um enum ou não possuir constantes
     */
    public <E extends Enum<E>, T extends Serializable, V extends EnumValue<E, T>> Optional<E> fromValue(
            @NonNull Class<V> enumValueClass,
            T value
    ) {
        val constants = enumValueClass.getEnumConstants();
        if (constants == null || constants.length == 0) {
            throw new IllegalArgumentException(MESSAGE_NO_ENUM_CONSTANTS + enumValueClass.getName()
                    + enumValueClass.getName());
        }
        // Obtém a classe do enum "real" a partir da primeira constante
        val enumClass = constants[0].getSelf().getDeclaringClass();

        // Constrói função que converte E -> V -> valor
        Function<E, T> getter = e -> enumValueClass.cast(e).getValue();
        return fromValue(enumClass, getter, value);
    }

    /**
     * Recupera uma constante do {@code enum} com base em um extrator de valor customizado.
     *
     * <p>Se nenhuma constante corresponder, retorna {@link Optional#empty()}.</p>
     *
     * @param <T>         tipo do valor associado (serializável)
     * @param <E>         tipo do enum
     * @param enumClass   classe do enum
     * @param valueGetter função que extrai o valor de cada constante
     * @param value       valor a ser localizado
     * @return {@link Optional} contendo a constante encontrada ou vazio se não houver correspondência
     * @throws IllegalArgumentException se {@code enumClass} não representar um {@code enum}
     */
    public <T extends Serializable, E extends Enum<E>> Optional<E> fromValue(
            @NonNull Class<E> enumClass,
            @NonNull Function<E, T> valueGetter,
            T value
    ) {
        if (Objects.isNull(value)) return Optional.empty();

        val enumValues = enumClass.getEnumConstants();
        if (enumValues == null || enumValues.length == 0) {
            throw new IllegalArgumentException(MESSAGE_NO_ENUM_CONSTANTS + enumClass.getName());
        }

        return Arrays.stream(enumValues)
                .filter(e -> Objects.equals(valueGetter.apply(e), value))
                .findFirst();
    }

    /**
     * Versão que lança {@code EnumValueNotFoundException} quando o valor não é encontrado. Atalho para enums que
     * implementam {@code EnumValue<E, T>}.
     *
     * @param <E>            tipo do enum
     * @param <T>            tipo do valor associado (serializável)
     * @param <V>            tipo concreto do enum que implementa {@code EnumValue<E, T>}
     * @param enumValueClass classe do enum que implementa {@code EnumValue}
     * @param value          valor a ser localizado
     * @return constante correspondente
     * @throws IllegalArgumentException   se {@code enumValueClass} não for um enum ou não possuir constantes
     * @throws EnumValueNotFoundException se o valor não existir entre as constantes do enum
     */
    public <E extends Enum<E>, T extends Serializable, V extends EnumValue<E, T>> E fromValueOrThrow(
            @NonNull Class<V> enumValueClass,
            T value
    ) {
        val constants = enumValueClass.getEnumConstants();
        if (constants == null || constants.length == 0) {
            throw new IllegalArgumentException(MESSAGE_NO_ENUM_CONSTANTS + enumValueClass.getName());
        }
        val enumClass = constants[0].getSelf().getDeclaringClass();
        return fromValueOrThrow(enumClass, e -> enumValueClass.cast(e).getValue(), value);
    }

    /**
     * Versão que lança {@code EnumValueNotFoundException} quando o valor não é encontrado, utilizando um extrator de
     * valor customizado.
     *
     * @param <T>         tipo do valor associado (serializável)
     * @param <E>         tipo do enum
     * @param enumClass   classe do enum
     * @param valueGetter função que extrai o valor de cada constante
     * @param value       valor a ser localizado
     * @return constante correspondente
     * @throws EnumValueNotFoundException se o valor não existir entre as constantes do enum
     */
    public <T extends Serializable, E extends Enum<E>> E fromValueOrThrow(
            @NonNull Class<E> enumClass,
            @NonNull Function<E, T> valueGetter,
            T value
    ) {
        return fromValue(enumClass, valueGetter, value)
                .orElseThrow(() -> {
                    val allowedValues = Arrays.stream(enumClass.getEnumConstants())
                            .map(valueGetter)
                            .map(Objects::toString)
                            .toArray(String[]::new);
                    return new EnumValueNotFoundException(enumClass, Objects.toString(value), allowedValues);
                });
    }
}
