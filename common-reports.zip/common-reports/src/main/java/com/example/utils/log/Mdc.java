package com.example.utils.log;

import lombok.experimental.UtilityClass;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;
import org.slf4j.MDC;

@UtilityClass
public class Mdc {
    public static final String EXECUTION_ID_KEY = "executionId";
    public static final int EXECUTION_ID_LENGTH = 8;

    public String get() {
        return MDC.get(EXECUTION_ID_KEY);
    }

    public void set() {
        if (StringUtils.isBlank(MDC.get(EXECUTION_ID_KEY))) {
            MDC.put(EXECUTION_ID_KEY, generate());
        }
    }

    public void clear() {
        MDC.remove(EXECUTION_ID_KEY);
    }

    public <E extends Throwable> void execute(FailableRunnable<E> runnable) throws E {
        set();
        try {
            runnable.run();
        } finally {
            clear();
        }
    }

    public <R, E extends Throwable> R execute(FailableSupplier<R, E> supplier) throws E {
        set();
        try {
            return supplier.get();
        } finally {
            clear();
        }
    }

    private String generate() {
        return RandomStringUtils.secure().nextAlphanumeric(EXECUTION_ID_LENGTH);
    }
}
