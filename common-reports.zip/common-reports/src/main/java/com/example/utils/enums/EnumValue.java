package com.example.utils.enums;

import com.example.utils.strings.Strings;
import lombok.NonNull;
import lombok.val;
import org.springframework.context.MessageSourceResolvable;

import java.io.Serializable;

public interface EnumValue<E extends Enum<E>, T extends Serializable> extends MessageSourceResolvable {
    String KEY_PREFIX = "enum";
    String KEY_DESCRIPTION = "description";
    String KEY_TITLE = "title";

    @NonNull
    String name();

    @NonNull
    T getValue();

    @NonNull
    E getSelf();

    default String getDescriptionKey() {
        val className = this.getClass().getSimpleName();
        val memberName = this.name();
        return String.join(Strings.PROPERTY_SEPARATOR, KEY_PREFIX, className, memberName, KEY_DESCRIPTION);
    }

    @Override
    default String[] getCodes() {
        val className = this.getClass().getSimpleName();
        val memberName = this.name();
        val messageKey = String.join(Strings.PROPERTY_SEPARATOR, KEY_PREFIX, className, memberName, KEY_TITLE);
        return new String[]{messageKey};
    }
}
