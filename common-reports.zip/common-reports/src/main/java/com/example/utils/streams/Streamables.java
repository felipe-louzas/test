package com.example.utils.streams;

import lombok.experimental.UtilityClass;
import lombok.val;
import org.apache.commons.lang3.stream.Streams;

import java.lang.reflect.Array;
import java.util.*;
import java.util.stream.*;

/**
 * Utilities to test if an object is streamable and to convert it to Stream.
 * <p>
 * Uses Apache Commons Lang3 Streams.of(...) whenever possible:
 * - Streams.of(Collection)
 * - Streams.of(Iterable)
 * - Streams.of(Iterator)
 * - Streams.of(Enumeration)
 * <p>
 * See org.apache.commons.lang3.stream.Streams API.
 * [1](https://commons.apache.org/proper/commons-lang/apidocs/org/apache/commons/lang3/stream/Streams.html)
 */
@UtilityClass
public class Streamables {

    /**
     * Returns true if {@code value} can be reasonably converted to a {@link Stream}.
     * <p>
     * "Reasonably" means it is one of:
     * - a Stream / BaseStream
     * - Iterable / Iterator / Spliterator / Enumeration
     * - Optional
     * - Map (stream of entries)
     * - arrays (Object[] or primitive arrays)
     * - CharSequence (stream of Characters)
     * - Stream builders (Stream.Builder / IntStream.Builder / LongStream.Builder / DoubleStream.Builder)
     * <p>
     * Does NOT return true for arbitrary scalar objects (because Stream.of(x) would trivialize the method).
     */
    public boolean isStreamable(Object value) {
        if (value == null) return false;

        return (value instanceof BaseStream<?, ?>
                || value instanceof Iterable<?>
                || value instanceof Iterator<?>
                || value instanceof Spliterator<?>
                || value instanceof Enumeration<?>
                || value instanceof Optional<?>
                || value instanceof Map<?, ?>
                || value instanceof Stream.Builder<?>
                || value instanceof IntStream.Builder
                || value instanceof LongStream.Builder
                || value instanceof DoubleStream.Builder
                || value.getClass().isArray());
    }

    /**
     * Convert a streamable object to a {@link Stream}.
     *
     * @throws IllegalArgumentException if {@code value} isn't streamable according to {@link #isStreamable(Object)}
     */
    public Stream<?> toStream(Object value) {
        if (value == null) return Stream.empty();

        // Already a Stream?
        else if (value instanceof Stream<?> s) return s;

        // Primitive streams -> box to Stream<?>
        else if (value instanceof IntStream s) return s.boxed();
        else if (value instanceof LongStream s) return s.boxed();
        else if (value instanceof DoubleStream s) return s.boxed();

        // Stream builders
        else if (value instanceof Stream.Builder<?> b) return b.build();
        else if (value instanceof IntStream.Builder b) return b.build().boxed();
        else if (value instanceof LongStream.Builder b) return b.build().boxed();
        else if (value instanceof DoubleStream.Builder b) return b.build().boxed();

        // Optional -> Stream (Java 9+)
        else if (value instanceof Optional<?> opt) return opt.stream();

        // Map -> stream entries (most general)
        else if (value instanceof Map<?, ?> map) return map.entrySet().stream();

        else if (value instanceof Collection<?> c) return c.stream();
        else if (value instanceof Iterable<?> it) return Streams.of(it);
        else if (value instanceof Iterator<?> it) return Streams.of(it);
        else if (value instanceof Enumeration<?> en) return Streams.of(en);

        // Spliterator -> StreamSupport
        else if (value instanceof Spliterator<?> sp) return StreamSupport.stream(sp, false);

        // Arrays (Object[] and all primitive arrays)
        else if (value.getClass().isArray()) return arrayToStream(value);

        // Any other BaseStream type (rare): attempt best-effort
        else if (value instanceof BaseStream<?, ?> bs) {
            val parallel = bs.isParallel();
            return StreamSupport.stream(bs.spliterator(), parallel);
        }

        throw new IllegalArgumentException("Value is not streamable: " + value.getClass().getName());
    }

    /**
     * If value is streamable, return its stream; otherwise returns Stream.of(value) (singleton).
     * Useful when you want to treat scalars as 1-element streams.
     */
    public Stream<?> toStreamOrSingleton(Object value) {
        if (value == null) return Stream.empty();
        return isStreamable(value) ? toStream(value) : Stream.of(value);
    }

    /**
     * If value is streamable, return its stream; otherwise returns Stream.empty().
     */
    public Stream<?> toStreamOrEmpty(Object value) {
        return isStreamable(value) ? toStream(value) : Stream.empty();
    }

    /**
     * Convert any Java array (Object[] or primitive arrays) to Stream<?>.
     */
    private Stream<?> arrayToStream(Object array) {
        // Object array
        if (array instanceof Object[] objArray) {
            return Arrays.stream(objArray);
        }

        // Primitive arrays: use specialized streams where available
        if (array instanceof int[] a) return Arrays.stream(a).boxed();
        if (array instanceof long[] a) return Arrays.stream(a).boxed();
        if (array instanceof double[] a) return Arrays.stream(a).boxed();

        // For other primitive arrays use index access
        int len = Array.getLength(array);
        return IntStream.range(0, len).mapToObj(i -> Array.get(array, i));
    }
}
