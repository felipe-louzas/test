package com.example.utils.fluent;

import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.function.Supplier;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.apache.commons.lang3.function.FailableBiConsumer;
import org.apache.commons.lang3.function.FailableConsumer;
import org.apache.commons.lang3.function.FailableFunction;
import org.apache.commons.lang3.function.FailableRunnable;
import org.apache.commons.lang3.function.FailableSupplier;

/**
 * Wrapper fluente e null-safe para configuração de objetos e execução condicional.
 *
 * <p>
 * Conceitos centrais:
 * <ul>
 *   <li><b>T</b>: objeto (target) sendo configurado</li>
 *   <li><b>V</b>: sujeito da condição (valor avaliado)</li>
 * </ul>
 *
 * <p>
 * Características:
 * <ul>
 *   <li>DSL interna para lógica condicional legível e composável</li>
 *   <li>Propagação explícita de exceções checadas via {@code Failable*}</li>
 *   <li>Semântica monádica para transformações</li>
 * </ul>
 *
 * @param <T> Tipo do objeto
 */
@RequiredArgsConstructor(staticName = "of")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public final class Fluent<T> {

	T target;

	static <T> Fluent<T> empty() {
		return new Fluent<>(null);
	}

	/* ============================================================
	 * 1. EXTRAÇÃO TERMINAL
	 * ============================================================ */

	/** Retorna o valor bruto do objeto (pode ser null). */
	public T get() {
		return target;
	}

	/** Retorna o objeto encapsulado em {@link Optional}. */
	public Optional<T> toOptional() {
		return Optional.ofNullable(target);
	}

	/** Retorna o objeto se não for null; caso contrário, retorna {@code other}. */
	public T orElse(T other) {
		return target != null ? target : other;
	}

	/** Retorna o objeto se não for null; caso contrário, avalia o fornecedor. */
	public <E extends Exception> T orElseGet(FailableSupplier<? extends T, E> supplier) throws E {
		return target != null ? target : supplier.get();
	}

	/** Retorna o objeto se não for null; caso contrário, lança a exceção fornecida. */
	public <X extends Throwable> T orElseThrow(Supplier<? extends X> exceptionSupplier) throws X {
		if (target != null) return target;
		throw exceptionSupplier.get();
	}

	/* ============================================================
	 * 2. MUTAÇÃO E TRANSFORMAÇÃO
	 * ============================================================ */

	/**
	 * Executa a ação apenas se o objeto não for null. Usado para mutação direta do objeto. Ex:
	 * {@code Fluent.of(obj).accept(o -> o.setX(10));}
	 */
	public <E extends Exception> Fluent<T> accept(FailableConsumer<? super T, E> action) throws E {
		if (target != null && action != null) {
			action.accept(target);
		}
		return this;
	}

	/**
	 * Executa a ação se o objeto e valor não for null. Usado para mutação direta do objeto. Ex:
	 * {@code Fluent.of(obj).apply(value, obj::setX);}
	 */
	public <E extends Exception, V> Fluent<T> apply(V value, FailableConsumer<? super V, E> action) throws E {
		if (target != null && action != null && value != null) {
			action.accept(value);
		}
		return this;
	}

	/**
	 * Executa a ação apenas se o objeto e valor não for null. Usado para mutação direta do objeto. Ex:
	 * {@code Fluent.of(obj).apply(value, Obj::setX);}
	 */
	public <E extends Exception, V> Fluent<T> apply(V value, FailableBiConsumer<? super T, ? super V, E> action) throws E {
		if (target != null && action != null && value != null) {
			action.accept(target, value);
		}
		return this;
	}

	/**
	 * Executa a ação apenas se o objeto e valor não for null. Usado para mutação direta do objeto. Ex:
	 * {@code Fluent.of(obj).apply(value, o -> o::setX);}
	 */
	public <E extends Exception, V> Fluent<T> apply(V value, Function<? super T, FailableConsumer<? super V, E>> action) throws E {
		if (target != null && action != null && value != null) {
			val consumer = action.apply(target);
			if (consumer != null)
				consumer.accept(value);
		}
		return this;
	}

	/**
	 * Transforma o objeto em outro valor.
	 *
	 * <p>
	 * Se o objeto for null, o mapper não é executado e {@code Fluent.of(null)} é retornado.
	 */
	public <U, E extends Exception> Fluent<U> map(FailableFunction<? super T, ? extends U, E> mapper) throws E {
		if (target == null || mapper == null) return Fluent.empty();
		final U mapped = mapper.apply(target);
		return Fluent.of(mapped);
	}

	/* ============================================================
	 * 3. ATALHOS DE CONTROLE DE FLUXO
	 * ============================================================ */

	/**
	 * Executa a ação se o objeto não for null.
	 *
	 * <p>
	 * Atalho semântico para controle de fluxo (não para mutação).
	 */
	public <E extends Exception> Fluent<T> ifNotNull(FailableRunnable<E> action) throws E {
		if (target != null && action != null)
			action.run();
		return this;
	}

	/**
	 * Executa a ação se o objeto for null.
	 */
	public <E extends Exception> Fluent<T> ifNull(FailableRunnable<E> action) throws E {
		if (target == null && action != null)
			action.run();
		return this;
	}

	/* ============================================================
	 * 4. ENTRADAS DO DSL CONDICIONAL
	 * ============================================================ */

	/**
	 * Inicia um bloco condicional avaliando o próprio objeto.
	 */
	public Condition<T, T> when(Predicate<? super T> predicate) {
		return new Condition<>(this, target).when(predicate);
	}

	/**
	 * Inicia um bloco condicional baseado em um valor booleano direto.
	 */
	public Condition<T, T> when(boolean condition) {
		return new Condition<>(this, target).when(condition);
	}

	/**
	 * Inicia um bloco condicional avaliando um valor externo.
	 */
	public <V> Condition<T, V> with(V value) {
		return new Condition<>(this, value);
	}

	/* ============================================================
	 * DSL INTERNO: CONDITION
	 * ============================================================ */

	@FieldDefaults(level = AccessLevel.PRIVATE)
	public static final class Condition<T, V> {

		final Fluent<T> parent;
		final V value;
		Predicate<V> predicate;

		Condition(Fluent<T> parent, V value) {
			this.parent = parent;
			this.value = value;
			this.predicate = Objects::nonNull;
		}

		/* ---------------- Construção da lógica ---------------- */

		public Condition<T, V> when(Predicate<? super V> p) {
			this.predicate = p == null ? v -> false : p::test;
			return this;
		}

		public Condition<T, V> when(boolean condition) {
			this.predicate = v -> condition;
			return this;
		}

		public Condition<T, V> and(Predicate<? super V> p) {
			if (p != null) {
				val current = this.predicate;
				this.predicate = v -> current.test(v) && p.test(v);
			}
			return this;
		}

		public Condition<T, V> and(boolean condition) {
			return and(v -> condition);
		}

		public Condition<T, V> or(Predicate<? super V> p) {
			if (p != null) {
				val current = this.predicate;
				this.predicate = v -> current.test(v) || p.test(v);
			}
			return this;
		}

		public Condition<T, V> or(boolean condition) {
			return or(v -> condition);
		}

		/* ---------------- Execução terminal ---------------- */

		private boolean test() {
			return predicate != null && predicate.test(value);
		}

		/**
		 * Executa a ação se a condição for satisfeita. Recebe o valor avaliado (V).
		 */
		public <E extends Exception> Fluent<T> accept(FailableConsumer<? super V, E> action) throws E {
			if (action != null && test()) {
				action.accept(value);
			}
			return parent;
		}

		/**
		 * Executa a ação se a condição for satisfeita. Recebe o objeto (T) e o valor avaliado (V).
		 */
		public <E extends Exception> Fluent<T> apply(FailableBiConsumer<? super T, ? super V, E> action) throws E {
			if (parent.target != null && action != null && test()) {
				action.accept(parent.target, value);
			}
			return parent;
		}

		/**
		 * Executa a ação se a condição for satisfeita.
		 */
		public <E extends Exception> Fluent<T> run(FailableRunnable<E> action) throws E {
			if (action != null && test()) {
				action.run();
			}
			return parent;
		}

		public <U, E extends Exception> Fluent<U> map(FailableFunction<? super V, ? extends U, E> mapper) throws E {
			if (mapper == null || !test()) return Fluent.empty();
			final U mapped = mapper.apply(value);
			return Fluent.of(mapped);
		}
	}
}
