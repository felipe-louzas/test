package com.example.utils.enums;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import org.springframework.beans.TypeMismatchException;
import org.springframework.context.MessageSourceResolvable;

@RequiredArgsConstructor
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class EnumValueNotFoundException extends IllegalArgumentException implements MessageSourceResolvable {

    private static final String DEFAULT_MESSAGE_CODE = TypeMismatchException.ERROR_CODE + ".enum";

    Class<? extends Enum<?>> enumClass;
    String value;
    String[] allowedValues;

    /**
     * Retorna os argumentos que podem ser referenciados no texto da mensagem de erro.
     * <p>
     * Esses valores são utilizados para interpolar variáveis em mensagens utilizando placeholders como {0}, {1}, {2}
     * para representar os elementos retornados aqui.
     * <p>
     * Exemplo de mensagem: "O valor '{2}' não é válido para o tipo '{0}'. Valores permitidos: {1}."
     * <p>
     * O resultado será: "O valor 'PENDENTE' não é válido para o tipo 'StatusEnum'. Valores permitidos: ATIVO,
     * INATIVO."
     *
     * @return um array de objetos contendo:
     * <ul>
     *      <li>[0] - o nome simples da classe enum
     *      <li>[1] - os valores permitidos como string separada por vírgula
     *      <li>[2] - o valor inválido informado
     * </ul>
     */
    @Override
    public Object[] getArguments() {
        return new Object[]{
                enumClass.getSimpleName(),
                String.join(", ", allowedValues),
                value
        };
    }

    @Override
    public String getMessage() {
        return String.format("O valor %s não é uma das opções esperadas: %s", value, String.join(", ", allowedValues));
    }

    @Override
    public String getDefaultMessage() {
        return getMessage();
    }

    @Override
    public String[] getCodes() {
        return new String[]{DEFAULT_MESSAGE_CODE};
    }
}
