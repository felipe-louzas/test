package com.example.utils.records;

import com.example.utils.streams.Streamables;
import lombok.experimental.UtilityClass;
import lombok.extern.slf4j.Slf4j;
import lombok.val;
import org.apache.commons.lang3.ObjectUtils;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.RecordComponent;
import java.util.IdentityHashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;

@Slf4j
@UtilityClass
public class Records {
    /**
     * Convert a record to a Map<String, Object>, recursively converting nested records.
     */
    public <T extends Record> Map<String, Object> toMap(T rec) {
        if (rec == null) return Map.of();
        return toMapInternal(rec, new IdentityHashMap<>());
    }

    private static Map<String, Object> toMapInternal(Record rec, IdentityHashMap<Object, Boolean> visited) {
        if (visited.containsKey(rec)) {
            return Map.of();
        }
        visited.put(rec, Boolean.TRUE);

        val result = new LinkedHashMap<String, Object>();

        val components = rec.getClass().getRecordComponents();
        if (components == null) return Map.of();

        for (val component : components) {
            val name = component.getName();
            val value = readComponentValue(rec, component);
            val converted = convertValue(value, visited);
            if (!ObjectUtils.isEmpty(converted))
                result.put(name, converted);
        }

        return result;
    }

    private static Object readComponentValue(Record rec, RecordComponent component) {
        try {
            return component.getAccessor().invoke(rec);
        } catch (IllegalAccessException | InvocationTargetException e) {
            log.atWarn()
                    .addKeyValue("componentName", component.getName())
                    .addKeyValue("recordClassName", rec.getClass().getSimpleName())
                    .log("Não foi possível ler o valor do component");
            return null;
        }
    }

    private static Object convertValue(Object value, IdentityHashMap<Object, Boolean> visited) {
        if (value == null) return null;

        // Records -> nested map
        if (value instanceof Record rec) {
            return toMapInternal(rec, visited);
        }

        // Optional -> unwrap then convert
        if (value instanceof Optional<?> opt) {
            return opt.map(optValue -> convertValue(optValue, visited)).orElse(null);
        }

        // Map -> Map (converting values)
        if (value instanceof Map<?, ?> map) {
            val converted = new LinkedHashMap<String, Object>();
            for (Map.Entry<?, ?> e : map.entrySet()) {
                val key = ObjectUtils.toString(e.getKey());
                val entryValue = convertValue(e.getValue(), visited);
                converted.put(key, entryValue);
            }
            return converted;
        }

        if (Streamables.isStreamable(value)) {
            return Streamables.toStream(value)
                    .map(v -> convertValue(v, visited))
                    .toList();
        }

        // Anything else: keep as-is
        return value;
    }
}
