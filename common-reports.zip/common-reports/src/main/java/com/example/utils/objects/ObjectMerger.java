package com.example.utils.objects;

import lombok.*;
import lombok.experimental.Accessors;
import lombok.experimental.FieldDefaults;
import lombok.experimental.NonFinal;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.Function;

@Getter
@Setter
@Accessors(fluent = true)
@RequiredArgsConstructor(staticName = "of")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class ObjectMerger<T> {

    T target;
    T base;

    @NonFinal
    boolean ignoreNulls = true;

    public <R> ObjectMerger<T> replaceIfNull(Function<T, R> getter, BiConsumer<T, R> setter) {
        final R targetValue = getter.apply(target);
        if (targetValue == null) {
            final R baseValue = getter.apply(base);
            if (!ignoreNulls || baseValue != null) {
                setter.accept(target, baseValue);
            }
        }
        return this;
    }

    public <R> ObjectMerger<T> mergeList(Function<T, List<R>> getter, BiConsumer<T, List<R>> setter) {
        val baseList = getter.apply(base);
        val targetList = getter.apply(target);

        val mergedSet = new LinkedHashSet<>(baseList);
        mergedSet.addAll(targetList);

        setter.accept(target, mergedSet.stream().toList());
        return this;
    }

    public <K, V> ObjectMerger<T> mergeMap(Function<T, Map<K, V>> getter, BiConsumer<T, Map<K, V>> setter) {
        val baseMap = getter.apply(base);
        val targetMap = getter.apply(target);

        val mergedMap = new HashMap<>(baseMap);
        mergedMap.putAll(targetMap);

        setter.accept(target, mergedMap);
        return this;
    }
}
