package com.example.utils.objects;

import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;

import lombok.AccessLevel;
import lombok.RequiredArgsConstructor;
import lombok.experimental.FieldDefaults;
import lombok.val;
import org.jspecify.annotations.NullMarked;
import org.jspecify.annotations.Nullable;

@NullMarked
@RequiredArgsConstructor(staticName = "of")
@FieldDefaults(level = AccessLevel.PRIVATE, makeFinal = true)
public class FallbackChain<T> {
	List<T> layers;

	@SafeVarargs
	public static <T> FallbackChain<T> of(@Nullable T @Nullable ... layers) {
		if (layers == null)
			return new FallbackChain<>(List.of());
		val nonNull = Arrays.stream(layers)
			.filter(Objects::nonNull)
			.toList();
		return new FallbackChain<>(nonNull);
	}

	@Nullable
	public <R> R resolve(Function<T, @Nullable R> getter) {
		for (T layer : layers) {
			R value = getter.apply(layer);
			if (value != null)
				return value;
		}
		return null;
	}

	public <R> Optional<R> resolveOptional(Function<T, R> getter) {
		return Optional.ofNullable(resolve(getter));
	}

	public <R> R resolveNonNull(Function<T, R> getter) {
		return Objects.requireNonNull(resolve(getter), "No non-null value found for the provided getter");
	}
}
